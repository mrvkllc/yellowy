import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';

export type UserProfileData = {
  uid: string;
  email: string | null;
  displayName: string | null;

  appLanguage?: 'tr' | 'en' | 'es';
  nativeLang?: 'tr' | 'en' | 'es';
  targetLang?: 'tr' | 'en' | 'es';
  languagePair?: string;

  placementLevel?: 'A1' | 'A2' | 'B1' | 'B2';
  placementScore?: number;
};

export const createUserProfile = async (profile: UserProfileData) => {
  const ref = doc(db, 'users', profile.uid);

  await setDoc(ref, {
    ...profile,
    placementCompletedAt: serverTimestamp(),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
};
