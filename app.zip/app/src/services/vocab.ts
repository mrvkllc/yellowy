// src/services/vocab.ts
import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from './firebase';

export type LessonVocab = {
  id: string;
  lessonId: string;
  order: number;
  es: string;
  tr?: string;
  en?: string;
  exampleEs?: string;
  exampleTr?: string;
  exampleEn?: string;
};

export async function getLessonVocab(lessonId: string): Promise<LessonVocab[]> {
  const ref = collection(db, 'vocab');

  // lessonId eşleşsin ve order’a göre sıralayalım
  const q = query(
    ref,
    where('lessonId', '==', lessonId),
    orderBy('order', 'asc')
  );

  const snap = await getDocs(q);

  console.log('VOCAB: Firestore snapshot size =', snap.size);

  return snap.docs.map((doc) => {
    const d = doc.data() as any;
    return {
      id: doc.id,
      lessonId: d.lessonId,
      order: d.order ?? 0,
      es: d.es,
      tr: d.tr,
      en: d.en,
      exampleEs: d.exampleEs,
      exampleTr: d.exampleTr,
      exampleEn: d.exampleEn,
    };
  });
}
