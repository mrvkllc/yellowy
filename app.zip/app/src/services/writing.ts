import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from './firebase';

export type WritingExercise = {
  id: string;
  lessonId: string;
  languagePair: string;
  prompt: string;
  sampleAnswer?: string;
  order?: number;
};

export const getWritingExercises = async (
  lessonId: string,
  languagePair: string
): Promise<WritingExercise[]> => {
  const q = query(
    collection(db, 'writing_exercises'),
    where('lessonId', '==', lessonId),
    where('languagePair', '==', languagePair),
    where('active', '==', true),
    orderBy('order', 'asc')
  );

  const snap = await getDocs(q);

  return snap.docs.map((doc) => ({
    id: doc.id,
    ...(doc.data() as any),
  }));
};
