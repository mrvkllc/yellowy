// src/services/vocabProgress.ts
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  setDoc,
  Timestamp,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from './firebase';
import { LessonVocab } from './vocab';

export type ReviewQuality = 'again' | 'hard' | 'good';

export type UserWordProgress = {
  lessonId: string;
  vocabId: string;
  ease: number;
  repetitions: number;
  interval: number; // gün
  lastReviewedAt?: Timestamp;
  nextReviewAt?: Timestamp;
  lastResult?: ReviewQuality;
};

const DEFAULT_EASE = 2.5;

export function addDays(date: Date, days: number) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

/**
 * Belirli bir ders için kullanıcının kelime ilerlemelerini map döner
 * key = vocabId
 */
export async function getUserWordProgressMap(
  uid: string,
  lessonId: string
): Promise<Record<string, UserWordProgress>> {
  const colRef = collection(db, 'users', uid, 'userWords');
  const q = query(colRef, where('lessonId', '==', lessonId));
  const snap = await getDocs(q);

  const map: Record<string, UserWordProgress> = {};

  snap.forEach((docSnap) => {
    const data = docSnap.data() as any;
    if (!data.vocabId) return;

    map[data.vocabId] = {
      lessonId: data.lessonId,
      vocabId: data.vocabId,
      ease: data.ease ?? DEFAULT_EASE,
      repetitions: data.repetitions ?? 0,
      interval: data.interval ?? 0,
      lastReviewedAt: data.lastReviewedAt,
      nextReviewAt: data.nextReviewAt,
      lastResult: data.lastResult,
    };
  });

  return map;
}

/**
 * SRS mantığına göre tek bir kelimenin review kaydını günceller.
 * SM-2 simplified:
 *  - again  => reset'e yakın
 *  - hard   => ease biraz düşer
 *  - good   => ease artar
 */
export async function updateWordReview(
  uid: string,
  vocab: LessonVocab,
  quality: ReviewQuality
): Promise<UserWordProgress> {
  const docRef = doc(db, 'users', uid, 'userWords', vocab.id);

  const prevSnap = await getDoc(docRef);
  const prev = prevSnap.exists() ? (prevSnap.data() as any) : null;

  let ease: number = prev?.ease ?? DEFAULT_EASE;
  let repetitions: number = prev?.repetitions ?? 0;
  let interval: number = prev?.interval ?? 0;

  if (quality === 'again') {
    ease = Math.max(1.3, ease - 0.3);
    repetitions = 0;
    interval = 1;
  } else {
    if (quality === 'hard') {
      ease = Math.max(1.3, ease - 0.15);
    } else if (quality === 'good') {
      ease = ease + 0.1;
    }

    repetitions = repetitions + 1;

    if (repetitions === 1) {
      interval = 1;
    } else if (repetitions === 2) {
      interval = 3;
    } else {
      interval = Math.max(1, Math.round(interval * ease));
    }
  }

  const now = new Date();
  const nextDate = addDays(now, interval);
  const nextTs = Timestamp.fromDate(nextDate);

  const payload: UserWordProgress = {
    lessonId: vocab.lessonId,
    vocabId: vocab.id,
    ease,
    repetitions,
    interval,
    lastReviewedAt: Timestamp.fromDate(now),
    nextReviewAt: nextTs,
    lastResult: quality,
  };

  await setDoc(
    docRef,
    {
      ...payload,
      lastReviewedAt: serverTimestamp(), // Firestore tarafında gerçek zaman
    },
    { merge: true }
  );

  return payload;
}
