// src/services/progress.ts
import { db } from './firebase';
import {
  doc,
  runTransaction,
  serverTimestamp,
  Timestamp,
  arrayUnion,
  updateDoc,
  increment,
  getDoc,
  setDoc,
} from 'firebase/firestore';

const LESSON_XP = 10;
const LESSON_MINUTES = 5;

// 🔹 Haftalık leaderboard için kullanılacak key -> 2025-W49 gibi
const getCurrentWeekKey = () => {
  const now = new Date();
  const year = now.getUTCFullYear();
  const oneJan = new Date(Date.UTC(year, 0, 1));
  const dayOfYear =
    Math.floor(
      (Number(now) - Number(oneJan)) / (1000 * 60 * 60 * 24)
    ) + 1;

  const week = Math.ceil(dayOfYear / 7); // kaba ama iş görür
  return `${year}-W${week.toString().padStart(2, '0')}`;
};

// YYYY-MM-DD
const toDateKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate()
  ).padStart(2, '0')}`;

// ISO week (yıl + hafta numarası) -> 2025-W48 gibi
// ⚠️ Bu, lesson istatistikleri için; practice ayrı key kullanıyor.
const toWeekKey = (d: Date) => {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const year = date.getUTCFullYear();
  const yearStart = new Date(Date.UTC(year, 0, 1));
  const weekNo = Math.ceil(((+date - +yearStart) / 86400000 + 1) / 7);
  return `${year}-W${String(weekNo).padStart(2, '0')}`;
};

// Month key -> 2025-11 gibi
const toMonthKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;

// Ekranda göstereceğimiz sonuç tipi (LESSON için)
export type LessonCompleteResult = {
  gainedXp: number;
  todayXP: number;
  dailyGoalXP: number;
  currentStreak: number;
  totalLessonsCompleted: number;
  alreadyCompleted: boolean;
};

// 🔹 PRACTICE MODES -> leaderboard’ı bunlara göre breakdown edebiliriz
export type PracticeMode = 'listening' | 'vocab' | 'grammar' | 'writing';

/**
 * Practice sorularında doğru cevap geldiğinde:
 * - lifetime practiceScore
 * - weekly practiceWeeklyScore
 * - mode bazlı lifetime + weekly sayaçlar
 * - lastPracticeAt
 *
 * Haftalık leaderboard:
 *   users orderBy('practiceWeeklyScore', 'desc')
 */
export const awardPracticeScore = async (
  userId: string,
  mode: PracticeMode,
  amount: number
) => {
  if (!userId || amount <= 0) return;

  try {
    const ref = doc(db, 'users', userId);
    const snap = await getDoc(ref);
    const currentWeekKey = getCurrentWeekKey();

    const modeFieldMap: Record<PracticeMode, string> = {
      listening: 'practiceListeningCorrect',
      vocab: 'practiceVocabCorrect',
      grammar: 'practiceGrammarCorrect',
    };

    const modeField = modeFieldMap[mode];              // örn: practiceListeningCorrect
    const weeklyModeField = `${modeField}Weekly`;      // örn: practiceListeningCorrectWeekly

    // 🔹 Kullanıcının hiç dokümanı yoksa (ilk practice)
    if (!snap.exists()) {
      await setDoc(
        ref,
        {
          practiceScore: amount,               // lifetime toplam
          practiceWeeklyScore: amount,         // bu haftanın toplamı
          practiceWeeklyKey: currentWeekKey,   // hangi haftaya ait
          [modeField]: amount,                 // lifetime doğru sayısı
          [weeklyModeField]: amount,           // haftalık doğru sayısı
          lastPracticeAt: serverTimestamp(),
        },
        { merge: true }
      );
      return;
    }

    const data = snap.data() as any;
    const sameWeek = data.practiceWeeklyKey === currentWeekKey;

    const update: any = {
      practiceScore: increment(amount),
      lastPracticeAt: serverTimestamp(),
    };

    if (!sameWeek) {
      // 🔄 Yeni hafta başladı -> haftalık sayaçları resetle
      update.practiceWeeklyKey = currentWeekKey;
      update.practiceWeeklyScore = amount;
      update[weeklyModeField] = amount;
    } else {
      // 🧮 Aynı hafta -> üstüne ekle
      update.practiceWeeklyScore = increment(amount);
      update[weeklyModeField] = increment(amount);
    }

    // Lifetime doğru sayacı her durumda artar
    update[modeField] = increment(amount);

    await updateDoc(ref, update);
  } catch (e) {
    console.log('awardPracticeScore error', e);
  }
};

/**
 * Bir ders tamamlandığında kullanıcı istatistiklerini günceller:
 * - totalLessonsCompleted
 * - weeklyMinutes / monthlyMinutes
 * - todayXP + currentStreak (daily goal için)
 * - lastLessonId
 * - completedLessonIds (aynı dersi tekrar oynayınca XP vermemek için)
 *
 * Bu kısım PRACTICE leaderboard’dan bağımsız; sadece lesson progression.
 */
export async function applyLessonCompleted(
  uid: string,
  lessonId: string
): Promise<LessonCompleteResult> {
  const userRef = doc(db, 'users', uid);

  return runTransaction(db, async (tx) => {
    const snap = await tx.get(userRef);
    const data = snap.exists() ? (snap.data() as any) : {};

    // 🔹 Daha önce bitirilmiş dersler
    const completedList: string[] = data.completedLessonIds ?? [];
    const alreadyCompleted = completedList.includes(lessonId);

    // 🔹 Temel sayısal alanlar
    let totalLessonsCompleted = data.totalLessonsCompleted ?? 0;
    let weeklyMinutes = data.weeklyMinutes ?? 0;
    let monthlyMinutes = data.monthlyMinutes ?? 0;
    let currentStreak = data.currentStreak ?? 0;
    let todayXP = data.todayXP ?? 0;
    const dailyGoalXP = data.dailyGoalXP ?? 60;

    // Eğer bu dersi ilk kez bitiriyorsa ders sayısını artır
    if (!alreadyCompleted) {
      totalLessonsCompleted += 1;
    }

    // 🔹 Tarihe bağlı alanlar
    const now = new Date();
    const todayKey = toDateKey(now);
    const curWeekKey = toWeekKey(now);
    const curMonthKey = toMonthKey(now);

    let lastPracticeDayKey: string | null = null;
    const lastPracticeAt = data.lastPracticeAt as Timestamp | undefined;

    if (lastPracticeAt && typeof lastPracticeAt.toDate === 'function') {
      lastPracticeDayKey = toDateKey(lastPracticeAt.toDate());
    }

    const prevWeekKey: string | undefined = data.weeklyKey;
    const prevMonthKey: string | undefined = data.monthlyKey;

    // ✅ WEEKLY: farklı haftaya geçildiyse resetle
    if (!prevWeekKey || prevWeekKey !== curWeekKey) {
      weeklyMinutes = 0;
    }
    weeklyMinutes += LESSON_MINUTES;

    // ✅ MONTHLY: farklı aya geçildiyse resetle
    if (!prevMonthKey || prevMonthKey !== curMonthKey) {
      monthlyMinutes = 0;
    }
    monthlyMinutes += LESSON_MINUTES;

    // ✅ STREAK + TODAY XP
    let gainedXp = 0;

    if (!lastPracticeDayKey) {
      // İlk pratik
      currentStreak = 1;
      gainedXp = alreadyCompleted ? 0 : LESSON_XP;
      todayXP = gainedXp;
    } else if (lastPracticeDayKey === todayKey) {
      // Aynı gün
      gainedXp = alreadyCompleted ? 0 : LESSON_XP;
      todayXP += gainedXp;
    } else {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayKey = toDateKey(yesterday);

      if (lastPracticeDayKey === yesterdayKey) {
        currentStreak = (currentStreak ?? 0) + 1;
      } else {
        currentStreak = 1;
      }

      gainedXp = alreadyCompleted ? 0 : LESSON_XP;
      todayXP = gainedXp;
    }

    // 🔥 Firestore'a yaz
    tx.set(
      userRef,
      {
        totalLessonsCompleted,
        weeklyMinutes,
        monthlyMinutes,
        weeklyKey: curWeekKey,
        monthlyKey: curMonthKey,
        currentStreak,
        todayXP,
        dailyGoalXP,
        lastPracticeAt: serverTimestamp(),
        lastLessonId: lessonId,
        completedLessonIds: arrayUnion(lessonId),
      },
      { merge: true }
    );

    return {
      gainedXp,
      todayXP,
      dailyGoalXP,
      currentStreak,
      totalLessonsCompleted,
      alreadyCompleted,
    };
  });
}
