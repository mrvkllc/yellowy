// src/screens/misc/SplashScreen.tsx
import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

const SplashScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  return (
    <View style={styles.container}>
      <View style={styles.logoWrapper}>
        <Ionicons name="sparkles" size={40} color={colors.accent} />
        <Text style={styles.logoText}>Yellowy</Text>
      </View>

      <Text style={styles.tagline}>Loading your Spanish journey...</Text>

      <ActivityIndicator
        style={{ marginTop: 24 }}
        size="large"
        color={colors.primary}
      />
    </View>
  );
};

export default SplashScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 24,
    },
    logoWrapper: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 8,
    },
    logoText: {
      fontSize: 28,
      fontWeight: '800',
      marginLeft: 10,
      color: colors.textPrimary,
    },
    tagline: {
      fontSize: 14,
      color: colors.textSecondary,
      textAlign: 'center',
      marginTop: 4,
    },
  });
