import React, { useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

const GAMES = [
  {
    id: '1',
    title: 'Word Match',
    icon: 'copy-outline',
    description: 'Match words with their meanings',
  },
  {
    id: '2',
    title: 'Listening Game',
    icon: 'headset',
    description: 'Listen & choose the correct word',
  },
  {
    id: '3',
    title: 'Sentence Builder',
    icon: 'construct',
    description: 'Arrange words into correct sentences',
  },
  {
    id: '4',
    title: 'Flash Quiz',
    icon: 'thunderstorm',
    description: 'Fast-paced 60-second quiz',
  },
];

const GamesHomeScreenScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.header}>Game Center 🎮</Text>
      <Text style={styles.subHeader}>
        Practice your Spanish with fun mini-games!
      </Text>

      {GAMES.map((game) => (
        <TouchableOpacity key={game.id} style={styles.card}>
          <Ionicons
            name={game.icon as any}
            size={32}
            color={colors.primary}
            style={{ marginRight: 12 }}
          />
          <View style={{ flex: 1 }}>
            <Text style={styles.cardTitle}>{game.title}</Text>
            <Text style={styles.cardDescription}>{game.description}</Text>
          </View>
          <Ionicons name="arrow-forward" size={22} color={colors.textSecondary} />
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

export default GamesHomeScreenScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    content: {
      padding: 20,
    },
    header: {
      fontSize: 24,
      fontWeight: '700',
      marginBottom: 4,
      color: colors.textPrimary,
    },
    subHeader: {
      fontSize: 14,
      marginBottom: 20,
      color: colors.textSecondary,
    },
    card: {
      flexDirection: 'row',
      backgroundColor: colors.card,
      padding: 16,
      borderRadius: 16,
      alignItems: 'center',
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
    cardTitle: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.textPrimary,
    },
    cardDescription: {
      fontSize: 13,
      color: colors.textSecondary,
      marginTop: 2,
    },
  });
