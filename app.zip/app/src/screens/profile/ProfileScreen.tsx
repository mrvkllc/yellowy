// src/screens/profile/ProfileScreen.tsx
import React, { useMemo, useContext } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/ProfileStackNavigator';

type Props = NativeStackScreenProps<ProfileStackParamList, 'ProfileMain'>;

const ProfileScreen: React.FC<Props> = ({ navigation }) => {
  const { colors, mode, toggleMode } = useAppTheme();
  const { user, logout } = useContext(AuthContext);
  const styles = useMemo(() => createStyles(colors), [colors]);

  const displayName = user?.displayName || 'Yellowy User';
  const email = user?.email || 'no-email@example.com';
  const initial = displayName.charAt(0).toUpperCase();

  const handleEditProfile = () => {
    navigation.navigate('EditProfile');
  };

  const handleGoPremium = () => {
    navigation.navigate('Subscription');
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch (e) {
      console.log('LOGOUT ERROR', e);
    }
  };

  return (
    <View style={styles.container}>
      {/* Avatar + Name */}
      <View style={styles.headerSection}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{initial}</Text>
        </View>
        <Text style={styles.name}>{displayName}</Text>
        <Text style={styles.email}>{email}</Text>

        <TouchableOpacity style={styles.editProfileBtn} onPress={handleEditProfile}>
          <Ionicons name="create-outline" size={18} color={colors.primary} />
          <Text style={styles.editProfileText}>Edit profile</Text>
        </TouchableOpacity>
      </View>

      {/* Settings */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>General</Text>

        <TouchableOpacity style={styles.settingRow}>
          <Ionicons name="language" size={22} color={colors.textPrimary} />
          <Text style={styles.settingText}>App Language</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingRow}>
          <Ionicons name="notifications" size={22} color={colors.textPrimary} />
          <Text style={styles.settingText}>Notifications</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingRow} onPress={toggleMode}>
          <Ionicons
            name={mode === 'dark' ? 'sunny' : 'moon'}
            size={22}
            color={colors.textPrimary}
          />
          <Text style={styles.settingText}>
            Switch to {mode === 'dark' ? 'Light Mode' : 'Dark Mode'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Membership */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Membership</Text>

        <TouchableOpacity style={styles.settingRow} onPress={handleGoPremium}>
          <Ionicons name="star" size={22} color={colors.accent} />
          <Text style={styles.settingText}>Upgrade to Premium</Text>
        </TouchableOpacity>
      </View>

      {/* Logout */}
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={22} color="#fff" />
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
    </View>
  );
};

export default ProfileScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 20,
    },
    headerSection: {
      alignItems: 'center',
      marginBottom: 28,
    },
    avatar: {
      width: 80,
      height: 80,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      justifyContent: 'center',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: colors.border,
    },
    avatarText: {
      color: colors.textPrimary,
      fontSize: 32,
      fontWeight: '700',
    },
    name: {
      color: colors.textPrimary,
      fontSize: 20,
      fontWeight: '700',
      marginTop: 10,
    },
    email: {
      color: colors.textSecondary,
      fontSize: 13,
      marginTop: 2,
    },
    editProfileBtn: {
      marginTop: 8,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
    },
    editProfileText: {
      color: colors.primary,
      fontSize: 12,
      fontWeight: '600',
    },

    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 16,
    },
    sectionTitle: {
      color: colors.textPrimary,
      fontSize: 14,
      fontWeight: '700',
      marginBottom: 12,
    },
    settingRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 12,
    },
    settingText: {
      color: colors.textPrimary,
      fontSize: 15,
      marginLeft: 12,
    },

    logoutButton: {
      marginTop: 'auto',
      backgroundColor: colors.accent,
      paddingVertical: 14,
      borderRadius: 999,
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    logoutText: {
      color: '#fff',
      fontSize: 15,
      fontWeight: '700',
      marginLeft: 8,
    },
  });
