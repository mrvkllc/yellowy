// src/screens/profile/EditProfileScreen.tsx
import React, { useContext, useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { updateEmail, updateProfile } from 'firebase/auth';

const EditProfileScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { user, reloadUser } = useContext(AuthContext);
  const navigation = useNavigation();

  const [name, setName] = useState(user?.displayName ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    const currentUser = user; // TS için local değişken
    if (!currentUser) return;

    setError('');
    setSaving(true);

    try {
      if (name && name !== currentUser.displayName) {
        await updateProfile(currentUser, { displayName: name.trim() });
      }

      if (email && email !== currentUser.email) {
        await updateEmail(currentUser, email.trim());
      }

      // Profil güncellendikten sonra context'i yenile
      await reloadUser();

      navigation.goBack();
    } catch (e: any) {
      console.log('EDIT PROFILE ERROR', e);
      if (e?.code === 'auth/requires-recent-login') {
        setError('Please logout and login again to change email.');
      } else if (e?.code === 'auth/invalid-email') {
        setError('Invalid email address.');
      } else {
        setError('Could not update profile. Try again.');
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Edit Profile</Text>

      {error ? <Text style={styles.error}>{error}</Text> : null}

      <View style={styles.field}>
        <Text style={styles.label}>Name</Text>
        <View style={styles.inputRow}>
          <Ionicons name="person-outline" size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="Your name"
            placeholderTextColor={colors.textSecondary}
          />
        </View>
      </View>

      <View style={styles.field}>
        <Text style={styles.label}>Email</Text>
        <View style={styles.inputRow}>
          <Ionicons name="mail-outline" size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            placeholder="Email"
            placeholderTextColor={colors.textSecondary}
          />
        </View>
      </View>

      <TouchableOpacity
        style={[styles.saveButton, saving && { opacity: 0.7 }]}
        onPress={handleSave}
        disabled={saving}
      >
        <Text style={styles.saveText}>
          {saving ? 'Saving...' : 'Save changes'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default EditProfileScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 20,
      paddingTop: 60,
    },
    title: {
      fontSize: 22,
      fontWeight: '700',
      color: colors.textPrimary,
      marginBottom: 24,
      textAlign: 'center',
    },
    error: {
      color: '#f97373',
      textAlign: 'center',
      marginBottom: 12,
      fontSize: 13,
      fontWeight: '600',
    },
    field: {
      marginBottom: 16,
    },
    label: {
      color: colors.textSecondary,
      fontSize: 13,
      marginBottom: 6,
    },
    inputRow: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.card,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderWidth: 1,
      borderColor: colors.border,
    },
    input: {
      marginLeft: 8,
      flex: 1,
      color: colors.textPrimary,
      fontSize: 15,
    },
    saveButton: {
      marginTop: 24,
      backgroundColor: colors.primary,
      borderRadius: 12,
      paddingVertical: 14,
      alignItems: 'center',
    },
    saveText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: '700',
    },
  });
