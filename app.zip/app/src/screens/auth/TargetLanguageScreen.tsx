import React, { useMemo } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useAppTheme } from '../../theme/theme';

type Props = NativeStackScreenProps<AuthStackParamList, 'TargetLanguage'>;

const TargetLanguageScreen: React.FC<Props> = ({ route, navigation }) => {
  const { nativeLang } = route.params;
  const { colors } = useAppTheme();

  const availableTargets = useMemo(() => {
    const all: ('tr' | 'en' | 'es')[] = ['tr', 'en', 'es'];
    return all.filter((l) => l !== nativeLang);
  }, [nativeLang]);

  const buildLanguagePair = (
    native: 'tr' | 'en' | 'es',
    target: 'tr' | 'en' | 'es',
  ) => {
    return `${native}-${target}` as
      | 'tr-en'
      | 'en-tr'
      | 'tr-es'
      | 'es-tr'
      | 'en-es'
      | 'es-en';
  };

  const handleSelectTarget = (targetLang: 'tr' | 'en' | 'es') => {
    const languagePair = buildLanguagePair(nativeLang, targetLang);

    navigation.navigate('PlacementIntro', {
      nativeLang,
      targetLang,
    });
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Text style={[styles.title, { color: colors.text }]}>
        Hedef dilini seç
      </Text>

      {availableTargets.map((lang) => (
        <TouchableOpacity
          key={lang}
          style={[styles.button, { backgroundColor: colors.primary }]}
          onPress={() => handleSelectTarget(lang)}
        >
          <Text style={styles.buttonText}>
            {lang === 'tr' ? 'Türkçe' : lang === 'en' ? 'English' : 'Español'}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 24 },
  title: { fontSize: 24, fontWeight: '700', marginBottom: 24 },
  button: {
    paddingVertical: 14,
    borderRadius: 999,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});

export default TargetLanguageScreen;
