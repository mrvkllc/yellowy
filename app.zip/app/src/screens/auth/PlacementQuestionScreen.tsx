import React, { useEffect, useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useAppTheme } from '../../theme/theme';
import { collection, doc, getDocs, orderBy, query } from 'firebase/firestore';
import { db } from '../../services/firebase';

type Props = NativeStackScreenProps<AuthStackParamList, 'PlacementQuestion'>;

type PlacementQuestion = {
  id: string;
  order: number;
  levelTag: 'A1' | 'A2' | 'B1' | 'B2';
  skill: string;
  questionType: 'mcq';
  promptNative: string;
  promptTarget: string;
  options: string[];
  correctOptionIndex: number;
  explanationNative?: string;
};

const PlacementQuestionScreen: React.FC<Props> = ({ route, navigation }) => {
  const { nativeLang, targetLang, languagePair } = route.params;
  const { colors } = useAppTheme();

  const [questions, setQuestions] = useState<PlacementQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const testRef = doc(db, 'placementTests', languagePair);
        const qRef = collection(testRef, 'questions');
        const qSnap = await getDocs(query(qRef, orderBy('order', 'asc')));

        const data: PlacementQuestion[] = [];
        qSnap.forEach((d) => {
          const v = d.data();
          data.push({
            id: d.id,
            order: v.order,
            levelTag: v.levelTag,
            skill: v.skill,
            questionType: v.questionType,
            promptNative: v.promptNative,
            promptTarget: v.promptTarget,
            options: v.options,
            correctOptionIndex: v.correctOptionIndex,
            explanationNative: v.explanationNative,
          });
        });

        setQuestions(data);
      } catch (e) {
        console.log('Placement fetch error', e);
      } finally {
        setLoading(false);
      }
    };

    fetchQuestions();
  }, [languagePair]);

  const currentQuestion = useMemo(
    () => (questions.length > 0 ? questions[currentIndex] : null),
    [questions, currentIndex],
  );

  const handleOptionPress = (index: number) => {
    setSelectedIndex(index);
  };

  const mapScoreToLevel = (s: number): 'A1' | 'A2' | 'B1' | 'B2' => {
    if (s <= 6) return 'A1';
    if (s <= 12) return 'A2';
    if (s <= 17) return 'B1';
    return 'B2';
  };

  const handleNext = () => {
    if (!currentQuestion || selectedIndex === null) return;

    const isCorrect = selectedIndex === currentQuestion.correctOptionIndex;
    if (isCorrect) setScore((prev) => prev + 1);

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedIndex(null);
    } else {
      // bitiş
      const level = mapScoreToLevel(score + (isCorrect ? 1 : 0));
      navigation.replace('PlacementResult', {
        nativeLang,
        targetLang,
        languagePair,
        score: score + (isCorrect ? 1 : 0),
        level,
      });
    }
  };

  if (loading || !currentQuestion) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Text style={[styles.progress, { color: colors.primary }]}>
        Soru {currentIndex + 1} / {questions.length}
      </Text>

      {currentQuestion.promptTarget ? (
        <Text style={[styles.promptTarget, { color: colors.textPrimary }]}>
          {currentQuestion.promptTarget}
        </Text>
      ) : null}

      <Text style={[styles.promptNative, { color: colors.primary }]}>
        {currentQuestion.promptNative}
      </Text>

      <View style={{ marginTop: 16 }}>
        {currentQuestion.options.map((opt, idx) => {
          const selected = selectedIndex === idx;
          return (
            <TouchableOpacity
              key={idx}
              style={[
                styles.option,
                {
                  borderColor: selected ? colors.primary : colors.border,
                  backgroundColor: selected ? colors.primary + '22' : 'transparent',
                },
              ]}
              onPress={() => handleOptionPress(idx)}
            >
              <Text
                style={{
                  color: selected ? colors.primary : colors.textPrimary,
                  fontSize: 15,
                }}
              >
                {opt}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <TouchableOpacity
        style={[
          styles.nextButton,
          {
            backgroundColor: selectedIndex === null
              ? colors.primary
              : colors.primary,
          },
        ]}
        disabled={selectedIndex === null}
        onPress={handleNext}
      >
        <Text style={styles.nextText}>
          {currentIndex + 1 === questions.length ? 'Bitir' : 'Sonraki'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24 },
  progress: { fontSize: 14, marginBottom: 12 },
  promptTarget: { fontSize: 22, fontWeight: '700', marginBottom: 8 },
  promptNative: { fontSize: 14, lineHeight: 20 },
  option: {
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 10,
  },
  nextButton: {
    marginTop: 24,
    paddingVertical: 14,
    borderRadius: 999,
    alignItems: 'center',
  },
  nextText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});

export default PlacementQuestionScreen;
