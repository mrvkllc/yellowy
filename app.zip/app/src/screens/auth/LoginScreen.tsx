// src/screens/auth/LoginScreenScreen.tsx
import React, { useMemo, useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';


type Props = NativeStackScreenProps<AuthStackParamList, 'Login'>;

const LoginScreenScreen: React.FC<Props> = ({ navigation }) => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { login } = useContext(AuthContext);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async () => {
    setError('');
    try {
      await login(email.trim(), password);
      // başarılı ise AppNavigator user değişimini algılayıp Main'e atıyor
    } catch (e: any) {
      console.log(e);
      setError('Login failed. Check email/password.');
    }
  };
  const goToRegister = () => {
    navigation.navigate('Register');
  };

  return (
    <View style={styles.container}>
      {/* Title */}
      <Text style={styles.title}>Welcome Back 👋</Text>
      <Text style={styles.subtitle}>Login to continue learning</Text>

      {/* Error */}
      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      {/* Form */}
      <View style={styles.form}>
        {/* Email Input */}
        <View style={styles.inputWrapper}>
          <Ionicons name="mail-outline" size={20} color={colors.textSecondary} />
          <TextInput
            placeholder="Email"
            placeholderTextColor={colors.textSecondary}
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        {/* Password Input */}
        <View style={styles.inputWrapper}>
          <Ionicons name="lock-closed-outline" size={20} color={colors.textSecondary} />
          <TextInput
            placeholder="Password"
            placeholderTextColor={colors.textSecondary}
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        {/* Forgot Password */}
        <TouchableOpacity onPress={() => console.log('Forgot password pressed')}>
          <Text style={styles.forgot}>Forgot password?</Text>
        </TouchableOpacity>

        {/* Login Button */}
        <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
          <Text style={styles.loginText}>Login</Text>
        </TouchableOpacity>
      </View>

      {/* Register */}
      <View style={styles.bottomRow}>
        <Text style={styles.bottomText}>Don’t have an account?</Text>
        <TouchableOpacity onPress={goToRegister}>
          <Text style={styles.bottomLink}>Create account</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default LoginScreenScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 24,
      justifyContent: 'center',
    },
    title: {
      color: colors.textPrimary,
      fontSize: 28,
      fontWeight: '700',
      marginBottom: 4,
      textAlign: 'center',
    },
    subtitle: {
      color: colors.textSecondary,
      fontSize: 14,
      textAlign: 'center',
      marginBottom: 16,
    },
    errorText: {
      color: '#f97373',
      textAlign: 'center',
      marginBottom: 12,
      fontSize: 13,
      fontWeight: '600',
    },
    form: {
      gap: 14,
    },
    inputWrapper: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.card,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
    input: {
      marginLeft: 10,
      flex: 1,
      color: colors.textPrimary,
      fontSize: 15,
    },
    forgot: {
      color: colors.primary,
      textAlign: 'right',
      fontSize: 13,
      fontWeight: '600',
      marginTop: 4,
    },
    loginButton: {
      backgroundColor: colors.primary,
      borderRadius: 12,
      paddingVertical: 14,
      alignItems: 'center',
      marginTop: 10,
    },
    loginText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: '700',
    },
    bottomRow: {
      marginTop: 24,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
    },
    bottomText: {
      color: colors.textSecondary,
      fontSize: 14,
    },
    bottomLink: {
      color: colors.primary,
      fontSize: 14,
      fontWeight: '700',
    },
  });
