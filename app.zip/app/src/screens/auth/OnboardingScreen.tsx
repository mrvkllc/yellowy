// src/screens/auth/OnboardingScreenScreen.tsx
import React, { useState, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';

const { width } = Dimensions.get('window');

type Props = NativeStackScreenProps<AuthStackParamList, 'Onboarding'>;

const SLIDES = [
  {
    id: '1',
    title: 'Learn Spanish Easily',
    description: 'Interactive lessons, quizzes, and games to improve daily.',
    icon: 'school-outline',
  },
  {
    id: '2',
    title: 'Practice Every Skill',
    description: 'Reading, writing, listening, speaking — all in one place.',
    icon: 'book-outline',
  },
  {
    id: '3',
    title: 'Track Your Progress',
    description: 'Daily streaks, statistics, and achievements to motivate you.',
    icon: 'stats-chart-outline',
  },
];

const OnboardingScreenScreen: React.FC<Props> = ({ navigation }) => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const [index, setIndex] = useState(0);

  // FlatList ref
  const flatListRef = useRef<FlatList<any>>(null);

  const handleNext = () => {
    const nextIndex = Math.min(index + 1, SLIDES.length - 1);
    if (nextIndex === index) return;

    flatListRef.current?.scrollToOffset({
      offset: nextIndex * width,
      animated: true,
    });
    setIndex(nextIndex);
  };

  const goToLogin = () => {
  navigation.replace('LanguageSelect');

  };

  const handleSkip = () => {
    goToLogin();
  };

  const handleGetStarted = () => {
    goToLogin();
  };

  return (
    <View style={styles.container}>
      {/* Skip Button */}
      <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Slides */}
      <FlatList
        ref={flatListRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        data={SLIDES}
        keyExtractor={(item) => item.id}
        onMomentumScrollEnd={(e) => {
          const x = e.nativeEvent.contentOffset.x;
          setIndex(Math.round(x / width));
        }}
        renderItem={({ item }) => (
          <View style={[styles.slide, { width }]}>
            <Ionicons
              name={item.icon as any}
              size={80}
              color={colors.primary}
              style={{ marginBottom: 20 }}
            />
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.description}>{item.description}</Text>
          </View>
        )}
      />

      {/* Dots */}
      <View style={styles.dotsContainer}>
        {SLIDES.map((_, i) => (
          <View
            key={i}
            style={[
              styles.dot,
              {
                width: index === i ? 20 : 8,
                backgroundColor:
                  index === i ? colors.primary : colors.cardSoft,
              },
            ]}
          />
        ))}
      </View>

      {/* Bottom Buttons */}
      {index === SLIDES.length - 1 ? (
        <TouchableOpacity style={styles.startButton} onPress={handleGetStarted}>
          <Text style={styles.startText}>Get Started</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
          <Text style={styles.nextText}>Next</Text>
          <Ionicons name="arrow-forward" size={20} color={colors.textPrimary} />
        </TouchableOpacity>
      )}
    </View>
  );
};

export default OnboardingScreenScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      paddingHorizontal: 20,
      paddingTop: 60,
      paddingBottom: 30,
    },

    skipButton: {
      position: 'absolute',
      top: 50,
      right: 20,
      zIndex: 10,
    },
    skipText: {
      color: colors.textSecondary,
      fontSize: 14,
      fontWeight: '600',
    },

    slide: {
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: 20,
    },

    title: {
      fontSize: 26,
      fontWeight: '700',
      color: colors.textPrimary,
      marginBottom: 10,
      textAlign: 'center',
    },
    description: {
      fontSize: 15,
      color: colors.textSecondary,
      textAlign: 'center',
      lineHeight: 22,
    },

    dotsContainer: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 20,
      marginTop: 10,
      gap: 8,
    },
    dot: {
      height: 8,
      borderRadius: 10,
    },

    nextButton: {
      backgroundColor: colors.card,
      paddingVertical: 14,
      borderRadius: 999,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
      borderColor: colors.border,
    },
    nextText: {
      color: colors.textPrimary,
      fontSize: 15,
      fontWeight: '700',
      marginRight: 8,
    },

    startButton: {
      backgroundColor: colors.primary,
      paddingVertical: 14,
      borderRadius: 999,
      alignItems: 'center',
    },
    startText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: '700',
    },
  });
