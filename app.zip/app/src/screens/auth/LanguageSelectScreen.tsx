import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useAppTheme } from '../../theme/theme';

type Props = NativeStackScreenProps<AuthStackParamList, 'LanguageSelect'>;

const LanguageSelectScreen: React.FC<Props> = ({ navigation }) => {
  const { colors } = useAppTheme();

  const handleSelect = (nativeLang: 'tr' | 'en' | 'es') => {
    // Şimdilik sadece navigation, ileride AsyncStorage ile appLanguage kaydedeceğiz
    navigation.navigate('TargetLanguage', { nativeLang });
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
     <Text style={[styles.title, { color: colors.textPrimary }]}>
        Ana dilini seç
      </Text>

      <TouchableOpacity
        style={[styles.button, { backgroundColor: colors.primary }]}
        onPress={() => handleSelect('tr')}
      >
        <Text style={styles.buttonText}>Türkçe</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.button, { backgroundColor: colors.primary }]}
        onPress={() => handleSelect('en')}
      >
        <Text style={styles.buttonText}>English</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.button, { backgroundColor: colors.primary }]}
        onPress={() => handleSelect('es')}
      >
        <Text style={styles.buttonText}>Español</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 24 },
  title: { fontSize: 24, fontWeight: '700', marginBottom: 24 },
  button: {
    paddingVertical: 14,
    borderRadius: 999,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});

export default LanguageSelectScreen;
