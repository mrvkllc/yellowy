import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useAppTheme } from '../../theme/theme';

type Props = NativeStackScreenProps<AuthStackParamList, 'PlacementIntro'>;

const PlacementIntroScreen: React.FC<Props> = ({ route, navigation }) => {
  const { nativeLang, targetLang } = route.params;
  const { colors } = useAppTheme();

  const buildLanguagePair = () =>
    `${nativeLang}-${targetLang}` as
      | 'tr-en'
      | 'en-tr'
      | 'tr-es'
      | 'es-tr'
      | 'en-es'
      | 'es-en';

  const handleStart = () => {
    navigation.navigate('PlacementQuestion', {
      nativeLang,
      targetLang,
      languagePair: buildLanguagePair(),
    });
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Text style={[styles.title, { color: colors.text }]}>
        Kısa seviye testi
      </Text>
      <Text style={[styles.text, { color: colors.primary }]}>
        Seviyeni belirlemek için 10-15 sorudan oluşan kısa bir test
        yapacağız. Bu test kelime, dil bilgisi ve okuma becerilerini ölçer.
      </Text>

      <View style={styles.box}>
        <Text style={[styles.boxText, { color: colors.text }]}>
          Süre: yaklaşık 5-8 dakika{'\n'}
          Seviyeler: A1–B2{'\n'}
          Amaç: sana uygun dersten başlatmak
        </Text>
      </View>

      <TouchableOpacity
        style={[styles.button, { backgroundColor: colors.primary }]}
        onPress={handleStart}
      >
        <Text style={styles.buttonText}>Teste Başla</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: 'center', gap: 16 },
  title: { fontSize: 24, fontWeight: '700', marginBottom: 8 },
  text: { fontSize: 15, lineHeight: 22 },
  box: {
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderStyle: 'dashed',
  },
  boxText: { fontSize: 14, lineHeight: 20 },
  button: {
    marginTop: 24,
    paddingVertical: 14,
    borderRadius: 999,
    alignItems: 'center',
  },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});

export default PlacementIntroScreen;
