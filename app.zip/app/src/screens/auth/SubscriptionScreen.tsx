import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

const SubscriptionScreenScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerBox}>
        <Ionicons name="star" size={60} color={colors.accent} />
        <Text style={styles.title}>Yellowy Premium</Text>
        <Text style={styles.subtitle}>
          Unlock all lessons, games, quizzes and full AI conversation access.
        </Text>
      </View>

      {/* Features */}
      <View style={styles.featuresBox}>
        <View style={styles.featureRow}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.featureText}>Unlimited Lessons</Text>
        </View>

        <View style={styles.featureRow}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.featureText}>AI Conversation Practice</Text>
        </View>

        <View style={styles.featureRow}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.featureText}>Advanced Reading Mode</Text>
        </View>

        <View style={styles.featureRow}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.featureText}>Daily Progress Insights</Text>
        </View>
      </View>

      {/* Plan Cards */}
      <View style={styles.plansBox}>
        <View style={styles.planCard}>
          <Text style={styles.planTitle}>Monthly</Text>
          <Text style={styles.planPrice}>$7.99</Text>
        </View>

        <View style={[styles.planCard, styles.planCardActive]}>
          <Text style={styles.planTitleActive}>Yearly</Text>
          <Text style={styles.planPriceActive}>$59.99</Text>
          <Text style={styles.planSave}>Save 38%</Text>
        </View>
      </View>

      {/* CTA */}
      <TouchableOpacity style={styles.subscribeButton}>
        <Text style={styles.subscribeText}>Start 7-Day Free Trial</Text>
      </TouchableOpacity>

      {/* Footer */}
      <Text style={styles.footerText}>
        Cancel anytime. Payments will be charged to your account.
      </Text>
    </View>
  );
};

export default SubscriptionScreenScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 20,
    },

    // HEADER
    headerBox: {
      alignItems: 'center',
      marginBottom: 20,
      marginTop: 30,
    },
    title: {
      fontSize: 26,
      fontWeight: '700',
      color: colors.textPrimary,
      marginTop: 10,
    },
    subtitle: {
      color: colors.textSecondary,
      fontSize: 14,
      textAlign: 'center',
      marginTop: 8,
      lineHeight: 20,
      paddingHorizontal: 16,
    },

    // FEATURES
    featuresBox: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 24,
    },
    featureRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 6,
    },
    featureText: {
      marginLeft: 10,
      color: colors.textPrimary,
      fontSize: 15,
    },

    // PLANS
    plansBox: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 24,
    },
    planCard: {
      width: '48%',
      backgroundColor: colors.card,
      paddingVertical: 16,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: colors.border,
      alignItems: 'center',
    },
    planCardActive: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    planTitle: {
      color: colors.textPrimary,
      fontSize: 15,
      fontWeight: '700',
    },
    planPrice: {
      color: colors.textPrimary,
      fontSize: 20,
      fontWeight: '700',
      marginTop: 2,
    },

    planTitleActive: {
      color: '#fff',
      fontSize: 15,
      fontWeight: '700',
    },
    planPriceActive: {
      color: '#fff',
      fontSize: 22,
      fontWeight: '800',
      marginTop: 2,
    },
    planSave: {
      color: '#fff',
      marginTop: 4,
      fontSize: 12,
      fontWeight: '600',
    },

    // CTA
    subscribeButton: {
      backgroundColor: colors.accent,
      paddingVertical: 14,
      borderRadius: 999,
      alignItems: 'center',
      marginBottom: 16,
    },
    subscribeText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: '700',
    },

    // FOOTER
    footerText: {
      color: colors.textSecondary,
      fontSize: 12,
      textAlign: 'center',
      lineHeight: 18,
      marginTop: 4,
    },
  });
