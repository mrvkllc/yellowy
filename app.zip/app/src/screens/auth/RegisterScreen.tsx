// src/screens/auth/RegisterScreen.tsx
import React, { useMemo, useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  
} from 'react-native';
import { useRoute, RouteProp } from '@react-navigation/native';
import { auth } from '../../services/firebase';
import { createUserProfile } from '../../services/userProfile';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';



type Props = NativeStackScreenProps<AuthStackParamList, 'Register'>;


const RegisterScreenScreen: React.FC<Props> = ({ navigation }) => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { register } = useContext(AuthContext);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
const route = useRoute<RouteProp<AuthStackParamList, 'Register'>>();
const params = route.params;


const [loading, setLoading] = useState(false); // yoksa ekle

const handleRegister = async () => {
  setError('');

  if (!name || !email || !password || !confirm) {
    setError('Please fill in all fields.');
    return;
  }

  if (password.length < 6) {
    setError('Password must be at least 6 characters.');
    return;
  }

  if (password !== confirm) {
    setError('Passwords do not match.');
    return;
  }

  try {
    setLoading(true);
    console.log('[Register] starting register with', { name, email });

    // 1) Firebase Auth üzerinden kullanıcı oluştur (AuthContext.register)
    await register(name.trim(), email.trim(), password);

    // 2) Şu an login olan kullanıcıyı al
    const currentUser = auth.currentUser;
    console.log('[Register] currentUser after register:', currentUser?.uid);

    if (!currentUser) {
      console.log('[Register] currentUser is null, profile not created');
      return;
    }

    // 3) PlacementResult → Register’dan gelen parametreler
    const {
      nativeLang,
      targetLang,
      languagePair,
      placementLevel,
      placementScore,
    } = params ?? {};

    console.log('[Register] placement params:', {
      nativeLang,
      targetLang,
      languagePair,
      placementLevel,
      placementScore,
    });

    // 4) Firestore'da users/{uid} dokümanı oluştur
    await createUserProfile({
      uid: currentUser.uid,
      email: currentUser.email,
      displayName: currentUser.displayName ?? name.trim(),
      // appLanguage şimdilik ana dil ile aynı
      appLanguage: (nativeLang as 'tr' | 'en' | 'es') ?? 'tr',
      nativeLang: nativeLang as 'tr' | 'en' | 'es' | undefined,
      targetLang: targetLang as 'tr' | 'en' | 'es' | undefined,
      languagePair,
      placementLevel: placementLevel as 'A1' | 'A2' | 'B1' | 'B2' | undefined,
      placementScore,
    });

    console.log('[Register] profile created, navigating to Subscription');

    // 5) Başarılıysa abonelik / main akışına geç
    navigation.replace('Subscription');
  } catch (e: any) {
    console.log('REGISTER ERROR', e?.code, e?.message);

    if (e?.code === 'auth/email-already-in-use') {
      setError('This email is already in use.');
    } else if (e?.code === 'auth/invalid-email') {
      setError('Invalid email address.');
    } else if (e?.code === 'auth/network-request-failed') {
      setError('Network error. Check your internet connection.');
    } else if (e?.code === 'auth/weak-password') {
      setError('Password should be at least 6 characters.');
    } else if (e?.code === 'auth/operation-not-allowed') {
      setError('Email/password sign-in is not enabled in Firebase.');
    } else {
      setError(`Registration failed: ${e?.code ?? 'unknown error'}`);
    }

  }

  try {
    setLoading(true);

    // 1) Firebase Auth üzerinden kullanıcı oluştur (AuthContext.register)
    await register(name.trim(), email.trim(), password);

    // 2) Şu an login olan kullanıcıyı al
    const currentUser = auth.currentUser;

    if (currentUser) {
      // 3) PlacementResult → Register’dan gelen parametreler
      const {
        nativeLang,
        targetLang,
        languagePair,
        placementLevel,
        placementScore,
      } = params ?? {};

      // 4) Firestore'da users/{uid} dokümanı oluştur
     await createUserProfile({
  uid: currentUser.uid,
  email: currentUser.email,
  displayName: currentUser.displayName ?? name.trim(),
  nativeLang,
  targetLang,
  languagePair,
  placementLevel,
  placementScore,
  appLanguage: nativeLang ?? 'tr',
});

    }

    // 5) Başarılıysa abonelik / main akışına geç
    navigation.replace('Subscription');
  } catch (e: any) {
    console.log('REGISTER ERROR', e?.code, e?.message);

    if (e?.code === 'auth/email-already-in-use') {
      setError('This email is already in use.');
    } else if (e?.code === 'auth/invalid-email') {
      setError('Invalid email address.');
    } else if (e?.code === 'auth/network-request-failed') {
      setError('Network error. Check your internet connection.');
    } else if (e?.code === 'auth/weak-password') {
      setError('Password should be at least 6 characters.');
    } else if (e?.code === 'auth/operation-not-allowed') {
      setError('Email/password sign-in is not enabled in Firebase.');
    } else {
      setError(`Registration failed: ${e?.code ?? 'unknown error'}`);
    }
  } finally {
    setLoading(false);
  }
};

  const goToLogin = () => {
    navigation.navigate('Login');
  };

  return (
    <View style={styles.container}>
      {/* Title */}
      <Text style={styles.title}>Create Account ✨</Text>
      <Text style={styles.subtitle}>Join Yellowy and start learning</Text>

      {/* Error */}
      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      {/* Form */}
      <View style={styles.form}>
        {/* Name */}
        <View style={styles.inputWrapper}>
          <Ionicons name="person-outline" size={20} color={colors.textSecondary} />
          <TextInput
            placeholder="Name"
            placeholderTextColor={colors.textSecondary}
            style={styles.input}
            value={name}
            onChangeText={setName}
          />
        </View>

        {/* Email */}
        <View style={styles.inputWrapper}>
          <Ionicons name="mail-outline" size={20} color={colors.textSecondary} />
          <TextInput
            placeholder="Email"
            placeholderTextColor={colors.textSecondary}
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        {/* Password */}
        <View style={styles.inputWrapper}>
          <Ionicons
            name="lock-closed-outline"
            size={20}
            color={colors.textSecondary}
          />
          <TextInput
            placeholder="Password"
            placeholderTextColor={colors.textSecondary}
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        {/* Confirm Password */}
        <View style={styles.inputWrapper}>
          <Ionicons
            name="lock-closed-outline"
            size={20}
            color={colors.textSecondary}
          />
          <TextInput
            placeholder="Confirm Password"
            placeholderTextColor={colors.textSecondary}
            style={styles.input}
            value={confirm}
            onChangeText={setConfirm}
            secureTextEntry
          />
        </View>

        {/* Register Button */}
        <TouchableOpacity style={styles.registerButton} onPress={handleRegister}>
          <Text style={styles.registerText}>Sign Up</Text>
        </TouchableOpacity>
      </View>

      {/* Footer */}
      <View style={styles.bottomRow}>
        <Text style={styles.bottomText}>Already have an account?</Text>
        <TouchableOpacity onPress={goToLogin}>
          <Text style={styles.bottomLink}>Login</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default RegisterScreenScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 24,
      justifyContent: 'center',
    },
    title: {
      color: colors.textPrimary,
      fontSize: 26,
      fontWeight: '700',
      marginBottom: 4,
      textAlign: 'center',
    },
    subtitle: {
      color: colors.textSecondary,
      fontSize: 14,
      textAlign: 'center',
      marginBottom: 16,
    },
    errorText: {
      color: '#f97373',
      textAlign: 'center',
      marginBottom: 10,
      fontSize: 13,
      fontWeight: '600',
    },
    form: {
      gap: 14,
    },
    inputWrapper: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.card,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
    input: {
      marginLeft: 10,
      flex: 1,
      color: colors.textPrimary,
      fontSize: 15,
    },
    registerButton: {
      backgroundColor: colors.primary,
      borderRadius: 12,
      paddingVertical: 14,
      alignItems: 'center',
      marginTop: 10,
    },
    registerText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: '700',
    },
    bottomRow: {
      marginTop: 24,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
    },
    bottomText: {
      color: colors.textSecondary,
      fontSize: 14,
    },
    bottomLink: {
      color: colors.primary,
      fontSize: 14,
      fontWeight: '700',
    },
  });
