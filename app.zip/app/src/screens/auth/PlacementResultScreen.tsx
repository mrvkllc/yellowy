import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useAppTheme } from '../../theme/theme';

type Props = NativeStackScreenProps<AuthStackParamList, 'PlacementResult'>;

const PlacementResultScreen: React.FC<Props> = ({ route, navigation }) => {
  const { nativeLang, targetLang, languagePair, score, level } = route.params;
  const { colors } = useAppTheme();

  const handleContinue = () => {
    navigation.replace('Register', {
      nativeLang,
      targetLang,
      languagePair,
      placementLevel: level,
      placementScore: score,
    });
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Text style={[styles.title, { color: colors.primary }]}>
        Seviyen hazır
      </Text>
      <Text style={[styles.levelText, { color: colors.primary }]}>
        {level}
      </Text>

      <Text style={[styles.info, { color: colors.primary }]}>
        Skorun: {score}{'\n'}
        Hedef dil: {targetLang.toUpperCase()}
      </Text>

      <TouchableOpacity
        style={[styles.button, { backgroundColor: colors.primary }]}
        onPress={handleContinue}
      >
        <Text style={styles.buttonText}>Hesap oluştur</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: '700', marginBottom: 8 },
  levelText: { fontSize: 40, fontWeight: '900', marginBottom: 16 },
  info: { fontSize: 15, textAlign: 'center', marginBottom: 24 },
  button: {
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 999,
  },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});

export default PlacementResultScreen;
