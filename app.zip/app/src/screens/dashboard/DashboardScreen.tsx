// src/screens/dashboard/DashboardScreen.tsx
import React, { useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
  Animated,
  Easing,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';

import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { db } from '../../services/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { MainTabParamList } from '../../navigation/types';

import PrimaryButton from '../../components/ui/PrimaryButton';
import SecondaryButton from '../../components/ui/SecondaryButton';
import EmptyState from '../../components/ui/EmptyState';

type DashboardNav = BottomTabNavigationProp<MainTabParamList, 'Home'>;

type UserStats = {
  totalLessonsCompleted: number;
  weeklyMinutes: number;
  monthlyMinutes: number;
  currentStreak: number;
  todayXP: number;
  dailyGoalXP: number;
  lastLessonId?: string | null;
};

const defaultStats: UserStats = {
  totalLessonsCompleted: 0,
  weeklyMinutes: 0,
  monthlyMinutes: 0,
  currentStreak: 0,
  todayXP: 0,
  dailyGoalXP: 60,
  lastLessonId: null,
};

const DashboardScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { user } = useContext(AuthContext);
  const navigation = useNavigation<DashboardNav>();

  const [stats, setStats] = useState<UserStats>(defaultStats);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Animations
  const progressAnim = useRef(new Animated.Value(0)).current; // 0–1
  const cardsAnim = useRef(new Animated.Value(0)).current; // 0–1
  const streakScale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const ref = doc(db, 'users', user.uid);

    const unsub = onSnapshot(
      ref,
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as any;
          setStats({
            totalLessonsCompleted: data.totalLessonsCompleted ?? 0,
            weeklyMinutes: data.weeklyMinutes ?? 0,
            monthlyMinutes: data.monthlyMinutes ?? 0,
            currentStreak: data.currentStreak ?? 0,
            todayXP: data.todayXP ?? 0,
            dailyGoalXP: data.dailyGoalXP ?? 60,
            lastLessonId: data.lastLessonId ?? null,
          });
        } else {
          setStats(defaultStats);
        }
        setError('');
        setLoading(false);
      },
      (err) => {
        console.log('DASHBOARD STATS ERROR', err);
        setError('İlerleme verileri yüklenemedi.');
        setLoading(false);
      }
    );

    return () => unsub();
  }, [user?.uid]);

  // Progress bar animation (width based)
  useEffect(() => {
    const ratio =
      stats.dailyGoalXP > 0 ? Math.min(1, stats.todayXP / stats.dailyGoalXP) : 0;

    Animated.timing(progressAnim, {
      toValue: ratio,
      duration: 600,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [stats.todayXP, stats.dailyGoalXP, progressAnim]);

  // Cards enter animation
  useEffect(() => {
    Animated.timing(cardsAnim, {
      toValue: 1,
      duration: 450,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [cardsAnim]);

  // Streak breathing (very subtle)
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(streakScale, {
          toValue: 1.04,
          duration: 900,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(streakScale, {
          toValue: 1,
          duration: 900,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, [streakScale]);

  const percent =
    stats.dailyGoalXP > 0
      ? Math.min(100, Math.round((stats.todayXP / stats.dailyGoalXP) * 100))
      : 0;

  const xpLeft = Math.max(0, (stats.dailyGoalXP ?? 0) - (stats.todayXP ?? 0));
  const goalDone = percent >= 100;
  const streakAtRisk = (stats.todayXP ?? 0) === 0;

  const greetingName =
    user?.displayName ||
    (typeof user?.email === 'string' ? user.email.split('@')[0] : 'Yellowy learner');

  const handleContinueCourse = () => {
    if (stats.lastLessonId) {
      navigation.navigate('Learn', {
        screen: 'LessonDetail',
        params: { lessonId: stats.lastLessonId },
      } as any);
    } else {
      navigation.navigate('Learn', { screen: 'Courses' } as any);
    }
  };

  // Micro tasks (routing is simple; you can later make smarter)
  const goWarmupVocab = () => navigation.navigate('Practice', { screen: 'VocabPractice' } as any);
  const goQuickTF = () => navigation.navigate('Learn', { screen: 'Courses' } as any); // placeholder
  const goReading = () => navigation.navigate('Practice', { screen: 'ReadingPractice' } as any);

  const cardsAnimatedStyle = {
    opacity: cardsAnim,
    transform: [
      {
        translateY: cardsAnim.interpolate({
          inputRange: [0, 1],
          outputRange: [10, 0],
        }),
      },
    ],
  };

  const streakAnimatedStyle = {
    transform: [{ scale: streakScale }],
  };

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.loadingText}>Yükleniyor…</Text>
      </View>
    );
  }

  if (!user) {
    return <EmptyState title="Oturum bulunamadı" description="Devam etmek için giriş yap." />;
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      {/* Header */}
      <View style={styles.headerRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.hello}>Hola, {greetingName}</Text>
          <Text style={styles.subtitle}>
            {goalDone
              ? 'Hedef tamam. İstersen küçük bir ekstra tur at.'
              : streakAtRisk
              ? 'Streak riskte. 2 dakikalık hızlı bir görev yeter.'
              : `Bugünkü hedef için ${xpLeft} XP kaldı.`}
          </Text>
        </View>

        <Animated.View style={[styles.streakPill, streakAnimatedStyle]}>
          <Ionicons name="flame" size={18} color="#f97316" />
          <Text style={styles.streakText}>{stats.currentStreak} gün</Text>
        </Animated.View>
      </View>

      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      <Animated.View style={cardsAnimatedStyle}>
        {/* Next Best Action (single CTA) */}
        <View style={styles.primaryActionCard}>
          <View style={styles.primaryActionTop}>
            <View style={{ flex: 1 }}>
              <Text style={styles.primaryActionTitle}>
                {stats.lastLessonId ? 'Devam et' : 'Başla'}
              </Text>
              <Text style={styles.primaryActionSubtitle}>
                {stats.lastLessonId
                  ? `Son kaldığın ders: ${stats.lastLessonId}`
                  : 'A1 derslerini seç ve öğrenmeye başla.'}
              </Text>

              <View style={styles.primaryActionMetaRow}>
                <View style={styles.metaChip}>
                  <Ionicons name="time-outline" size={14} color={colors.textSecondary} />
                  <Text style={styles.metaChipText}>2–8 dk</Text>
                </View>
                <View style={styles.metaChip}>
                  <Ionicons name="flash-outline" size={14} color={colors.textSecondary} />
                  <Text style={styles.metaChipText}>XP kazan</Text>
                </View>
                {streakAtRisk ? (
                  <View style={styles.metaChipWarn}>
                    <Ionicons name="alert-circle-outline" size={14} color="#f97373" />
                    <Text style={styles.metaChipWarnText}>Streak risk</Text>
                  </View>
                ) : null}
              </View>
            </View>

            <Ionicons name="arrow-forward-circle" size={24} color={colors.primary} />
          </View>

          <PrimaryButton
            title={stats.lastLessonId ? 'Derse devam et' : 'Dersleri görüntüle'}
            onPress={handleContinueCourse}
            style={{ alignSelf: 'stretch', marginTop: 12 }}
          />
        </View>

        {/* Today's Goal */}
        <View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <View>
              <Text style={styles.cardTitle}>Bugünkü hedef</Text>
              <Text style={styles.cardSubtitle}>
                {stats.todayXP}/{stats.dailyGoalXP} XP
              </Text>
            </View>

            <View
              style={[
                styles.goalChip,
                goalDone
                  ? { backgroundColor: 'rgba(34,197,94,0.08)', borderColor: '#22c55e' }
                  : null,
              ]}
            >
              <Ionicons
                name={goalDone ? 'checkmark-circle' : 'sparkles-outline'}
                size={14}
                color={goalDone ? '#22c55e' : colors.primary}
              />
              <Text style={[styles.goalChipText, goalDone ? { color: '#22c55e' } : null]}>
                {goalDone ? 'Tamam' : 'Devam'}
              </Text>
            </View>
          </View>

          <View style={styles.progressBarBackground}>
            <Animated.View style={[styles.progressBarFill, { width: progressWidth }]} />
          </View>

          <Text style={styles.progressPercent}>{percent}% tamamlandı</Text>

          {/* Micro goals */}
          <View style={styles.microRow}>
            <TouchableOpacity style={styles.microChip} onPress={goWarmupVocab} activeOpacity={0.9}>
              <Text style={styles.microChipTitle}>+10 XP</Text>
              <Text style={styles.microChipSubtitle}>Isınma (2 dk)</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.microChip} onPress={goReading} activeOpacity={0.9}>
              <Text style={styles.microChipTitle}>+20 XP</Text>
              <Text style={styles.microChipSubtitle}>Reading (5 dk)</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.microChip} onPress={handleContinueCourse} activeOpacity={0.9}>
              <Text style={styles.microChipTitle}>+30 XP</Text>
              <Text style={styles.microChipSubtitle}>Ders (8 dk)</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Stats row */}
        <View style={styles.row}>
          <View style={styles.smallCard}>
            <Text style={styles.smallLabel}>Tamamlanan ders</Text>
            <Text style={styles.smallValue}>{stats.totalLessonsCompleted}</Text>
            <Text style={styles.smallHint}>Toplam bitirilen ders</Text>
          </View>

          <View style={styles.smallCard}>
            <Text style={styles.smallLabel}>Bu hafta</Text>
            <Text style={styles.smallValue}>{stats.weeklyMinutes} dk</Text>
            <Text style={styles.smallHint}>Odaklı öğrenme</Text>
          </View>
        </View>

        {/* This month */}
        <View style={styles.card}>
          <View style={styles.monthHeader}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Ionicons name="calendar-outline" size={18} color={colors.textSecondary} />
              <Text style={[styles.sectionTitle, { marginLeft: 6 }]}>Bu ay</Text>
            </View>
            <Text style={styles.monthMinutes}>{stats.monthlyMinutes} dk</Text>
          </View>

          <Text style={styles.monthSubtitle}>
            Bu ay toplam odaklı çalışma süren.
          </Text>
        </View>

        {/* Quick practice (smaller, lower cognitive load) */}
        <Text style={styles.sectionTitle}>Hızlı pratik</Text>

        <View style={styles.quickRow}>
          <View style={styles.quickCard}>
            <Text style={styles.quickTitle}>Vocab</Text>
            <Text style={styles.quickSubtitle}>2 dk, hızlı tekrar</Text>
            <PrimaryButton title="Başlat" onPress={goWarmupVocab} style={{ alignSelf: 'stretch', marginTop: 10 }} />
          </View>

          <View style={styles.quickCard}>
            <Text style={styles.quickTitle}>Reading</Text>
            <Text style={styles.quickSubtitle}>5 dk, odaklı okuma</Text>
            <PrimaryButton title="Başlat" onPress={goReading} style={{ alignSelf: 'stretch', marginTop: 10 }} />
          </View>
        </View>

        {/* Secondary action */}
        <View style={{ marginTop: 10 }}>
          <SecondaryButton title="Tüm dersleri görüntüle" onPress={() => navigation.navigate('Learn', { screen: 'Courses' } as any)} />
        </View>
      </Animated.View>
    </ScrollView>
  );
};

export default DashboardScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    centered: { justifyContent: 'center', alignItems: 'center' },
    loadingText: { marginTop: 8, color: colors.textSecondary },

    headerRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 12,
      gap: 12,
    },
    hello: { fontSize: 20, fontWeight: '800', color: colors.textPrimary },
    subtitle: { fontSize: 13, color: colors.textSecondary, marginTop: 4, lineHeight: 18 },

    streakPill: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.card,
      borderRadius: 999,
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderWidth: 1,
      borderColor: colors.border,
    },
    streakText: { color: colors.textPrimary, fontSize: 13, marginLeft: 6, fontWeight: '700' },

    errorText: {
      color: '#f97373',
      textAlign: 'center',
      marginBottom: 8,
      fontSize: 13,
      fontWeight: '600',
    },

    // Primary action
    primaryActionCard: {
      backgroundColor: colors.card,
      borderRadius: 18,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 16,
    },
    primaryActionTop: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 12,
    },
    primaryActionTitle: {
      color: colors.textPrimary,
      fontSize: 16,
      fontWeight: '900',
    },
    primaryActionSubtitle: {
      marginTop: 6,
      color: colors.textSecondary,
      fontSize: 13,
      lineHeight: 18,
    },
    primaryActionMetaRow: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 8,
      marginTop: 10,
    },
    metaChip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    metaChipText: { color: colors.textSecondary, fontSize: 11, fontWeight: '700' },
    metaChipWarn: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      backgroundColor: 'rgba(249,115,115,0.08)',
      borderWidth: 1,
      borderColor: 'rgba(249,115,115,0.35)',
    },
    metaChipWarnText: { color: '#f97373', fontSize: 11, fontWeight: '800' },

    // Standard cards
    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 16,
    },
    cardHeaderRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 12,
      gap: 10,
    },
    cardTitle: { color: colors.textPrimary, fontSize: 16, fontWeight: '800', marginBottom: 4 },
    cardSubtitle: { color: colors.textSecondary, fontSize: 13 },

    goalChip: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: colors.primary,
      backgroundColor: 'rgba(0,0,0,0.02)',
      gap: 4,
    },
    goalChipText: { fontSize: 11, color: colors.primary, fontWeight: '800' },

    progressBarBackground: {
      height: 10,
      borderRadius: 999,
      overflow: 'hidden',
      backgroundColor: colors.cardSoft,
      marginBottom: 8,
      marginTop: 8,
      borderWidth: 1,
      borderColor: colors.border,
    },
    progressBarFill: {
      height: '100%',
      backgroundColor: colors.primary,
      borderRadius: 999,
    },
    progressPercent: { color: colors.textSecondary, fontSize: 12, fontWeight: '700' },

    microRow: {
      flexDirection: 'row',
      gap: 10,
      marginTop: 12,
    },
    microChip: {
      flex: 1,
      backgroundColor: colors.cardSoft,
      borderRadius: 14,
      paddingVertical: 10,
      paddingHorizontal: 10,
      borderWidth: 1,
      borderColor: colors.border,
    },
    microChipTitle: { color: colors.textPrimary, fontSize: 13, fontWeight: '900' },
    microChipSubtitle: { color: colors.textSecondary, fontSize: 11, marginTop: 2, fontWeight: '700' },

    row: { flexDirection: 'row', gap: 12, marginBottom: 16 },
    smallCard: {
      flex: 1,
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 14,
      borderWidth: 1,
      borderColor: colors.border,
    },
    smallLabel: { color: colors.textSecondary, fontSize: 12, marginBottom: 6, fontWeight: '700' },
    smallValue: { color: colors.textPrimary, fontSize: 18, fontWeight: '900' },
    smallHint: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },

    sectionTitle: { color: colors.textPrimary, fontSize: 15, fontWeight: '900', marginBottom: 8 },

    monthHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 4,
    },
    monthMinutes: { color: colors.textPrimary, fontSize: 18, fontWeight: '900' },
    monthSubtitle: { color: colors.textSecondary, fontSize: 13, lineHeight: 18 },

    quickRow: { flexDirection: 'row', gap: 12, marginBottom: 8 },
    quickCard: {
      flex: 1,
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 14,
      borderWidth: 1,
      borderColor: colors.border,
    },
    quickTitle: { color: colors.textPrimary, fontSize: 14, fontWeight: '900' },
    quickSubtitle: { color: colors.textSecondary, fontSize: 12, marginTop: 4, lineHeight: 16 },
  });
