// src/screens/practice/WritingPracticeScreen.tsx

import React, { useContext, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
} from 'react-native';
import { RouteProp, useRoute } from '@react-navigation/native';

import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { PracticeStackParamList } from '../../navigation/types';

/* -------------------- TYPES -------------------- */

type RouteT = RouteProp<PracticeStackParamList, 'WritingPractice'>;

/* -------------------- COMPONENT -------------------- */

const WritingPracticeScreen: React.FC = () => {
  const route = useRoute<RouteT>();
  const lessonId = route.params?.lessonId; // 👈 KRİTİK FIX

  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { user } = useContext(AuthContext);

  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState('');
  const [submitted, setSubmitted] = useState(false);

  /* -------------------- GUARD -------------------- */

  if (!user) {
    return (
      <View style={styles.center}>
        <Text style={styles.centerText}>Giriş yapman gerekiyor.</Text>
      </View>
    );
  }

  if (!lessonId) {
    return (
      <View style={styles.center}>
        <Text style={styles.centerText}>
          Ders bilgisi bulunamadı.
        </Text>
      </View>
    );
  }

  /* -------------------- ACTIONS -------------------- */

  const handleSubmit = () => {
    if (!answer.trim()) {
      Alert.alert('Uyarı', 'Lütfen bir cevap yaz.');
      return;
    }

    setSubmitted(true);

    Alert.alert(
      'Gönderildi',
      'Yazma cevabın kaydedildi (şimdilik local).'
    );
  };

  /* -------------------- RENDER -------------------- */

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.primary} />
        <Text style={styles.centerText}>Yükleniyor…</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ padding: 16 }}
    >
      <Text style={styles.title}>Writing Practice</Text>

      <Text style={styles.subtitle}>
        Lesson: {lessonId}
      </Text>

      <View style={styles.card}>
        <Text style={styles.prompt}>
          Aşağıdaki konuda kısa bir paragraf yaz:
        </Text>

        <Text style={styles.promptBold}>
          “Kendini tanıtan 3–4 cümle yaz.”
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Cevabını buraya yaz…"
          placeholderTextColor={colors.textSecondary}
          value={answer}
          onChangeText={setAnswer}
          multiline
          editable={!submitted}
        />
      </View>

      {!submitted ? (
        <TouchableOpacity
          style={styles.submitBtn}
          onPress={handleSubmit}
        >
          <Text style={styles.submitText}>Gönder</Text>
        </TouchableOpacity>
      ) : (
        <Text style={styles.footer}>
          Cevabın alındı ✅
        </Text>
      )}
    </ScrollView>
  );
};



/* -------------------- STYLES -------------------- */

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    center: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      padding: 16,
      backgroundColor: colors.background,
    },
    centerText: {
      color: colors.textSecondary,
      fontSize: 14,
      textAlign: 'center',
    },
    title: {
      fontSize: 20,
      fontWeight: '700',
      color: colors.textPrimary,
      marginBottom: 6,
    },
    subtitle: {
      fontSize: 12,
      color: colors.textSecondary,
      marginBottom: 16,
    },
    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 16,
    },
    prompt: {
      fontSize: 14,
      color: colors.textSecondary,
      marginBottom: 6,
    },
    promptBold: {
      fontSize: 15,
      fontWeight: '600',
      color: colors.textPrimary,
      marginBottom: 12,
    },
    input: {
      minHeight: 120,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: colors.border,
      padding: 12,
      color: colors.textPrimary,
      textAlignVertical: 'top',
      backgroundColor: colors.cardSoft,
    },
    submitBtn: {
      backgroundColor: colors.primary,
      paddingVertical: 12,
      borderRadius: 999,
      alignItems: 'center',
    },
    submitText: {
      color: '#000',
      fontWeight: '700',
      fontSize: 14,
    },
    footer: {
      textAlign: 'center',
      marginTop: 12,
      color: colors.textSecondary,
      fontSize: 12,
    },
  });
export default WritingPracticeScreen;