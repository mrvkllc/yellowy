// src/screens/practice/PracticeLeaderboardScreen.tsx
import React, { useEffect, useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import {
  collection,
  getDocs,
  orderBy,
  limit,
  query,
} from 'firebase/firestore';

import { db } from '../../services/firebase';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';

type LeaderUser = {
  id: string;
  displayName?: string;
  practiceWeeklyScore: number;
};

const PracticeLeaderboardScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = createStyles(colors);
  const { user } = useContext(AuthContext);

  const [data, setData] = useState<LeaderUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const qRef = query(
          collection(db, 'users'),
          orderBy('practiceWeeklyScore', 'desc'),
          limit(50)
        );

        const snap = await getDocs(qRef);

        const list: LeaderUser[] = snap.docs.map((d) => {
          const val = d.data() as any;
          return {
            id: d.id,
            displayName:
              val.displayName ??
              (typeof val.email === 'string'
                ? val.email.split('@')[0]
                : 'Unknown'),
            practiceWeeklyScore: val.practiceWeeklyScore ?? 0,
          };
        });

        setData(list);
      } catch (e) {
        console.log('leaderboard error', e);
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (!data.length) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Weekly practice leaderboard</Text>
        <Text style={styles.subtitle}>
          Answer practice questions correctly this week and climb the board.
        </Text>
        <View style={styles.emptyBox}>
          <Text style={styles.emptyText}>
            No practice activity yet this week. Be the first one to appear on
            the board!
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Weekly practice leaderboard</Text>
      <Text style={styles.subtitle}>
        Answer practice questions correctly this week and climb the board.
      </Text>

      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingVertical: 12 }}
        renderItem={({ item, index }) => {
          const isCurrentUser = item.id === user?.uid;

          return (
            <View
              style={[
                styles.row,
                isCurrentUser && styles.currentUserRow,
              ]}
            >
              <Text style={styles.rank}>{index + 1}</Text>

              <View style={styles.avatar}>
                <Text style={styles.avatarText}>
                  {item.displayName?.charAt(0).toUpperCase()}
                </Text>
              </View>

              <View style={{ flex: 1 }}>
                <Text
                  style={[
                    styles.name,
                    isCurrentUser && styles.nameCurrent,
                  ]}
                >
                  {item.displayName}
                </Text>
              </View>

              <Text style={styles.score}>
                {item.practiceWeeklyScore} pt
              </Text>
            </View>
          );
        }}
      />
    </View>
  );
};

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 16,
    },
    center: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.background,
    },
    title: {
      fontSize: 20,
      fontWeight: '700',
      color: colors.textPrimary,
    },
    subtitle: {
      fontSize: 12,
      color: colors.textSecondary,
      marginTop: 4,
      marginBottom: 12,
    },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 8,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
      gap: 8,
    },
    currentUserRow: {
      backgroundColor: colors.primarySoft,
      borderRadius: 12,
      marginHorizontal: -8,
      paddingHorizontal: 8,
    },
    rank: {
      width: 24,
      textAlign: 'center',
      fontSize: 14,
      fontWeight: '700',
      color: colors.textSecondary,
    },
    avatar: {
      width: 32,
      height: 32,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    avatarText: {
      color: colors.textPrimary,
      fontWeight: '700',
    },
    name: {
      fontSize: 14,
      color: colors.textPrimary,
    },
    nameCurrent: {
      fontWeight: '700',
    },
    score: {
      fontSize: 13,
      fontWeight: '700',
      color: colors.primary,
    },
    emptyBox: {
      marginTop: 16,
      padding: 12,
      borderRadius: 12,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
    },
    emptyText: {
      fontSize: 13,
      color: colors.textSecondary,
    },
  });

export default PracticeLeaderboardScreen;
