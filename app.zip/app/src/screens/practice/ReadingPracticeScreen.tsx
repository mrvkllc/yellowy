// src/screens/practice/ReadingPracticeScreen.tsx
import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

const STORIES = [
  {
    id: '1',
    title: 'Mi Rutina Diaria',
    level: 'A1',
    type: 'Short Story',
    words: 250,
    primary: true,
  },
  {
    id: '2',
    title: 'En el Café',
    level: 'A1',
    type: 'Dialogue',
    words: 120,
    primary: false,
  },
  {
    id: '3',
    title: 'En el Mercado',
    level: 'A2',
    type: 'Conversation',
    words: 180,
    primary: false,
  },
];

const ReadingPracticeScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.sectionTitle}>Reading Practice</Text>
      <Text style={styles.subText}>Improve your comprehension with graded stories</Text>

      {STORIES.map((story) => (
        <View
          key={story.id}
          style={[
            styles.storyCard,
            { borderColor: colors.border, backgroundColor: colors.card },
          ]}
        >
          <View style={styles.row}>
            <Text style={styles.storyTitle}>{story.title}</Text>
            <View style={styles.levelPill}>
              <Text style={styles.levelText}>{story.level}</Text>
            </View>
          </View>

          <Text style={styles.storyMeta}>
            {story.level} • {story.type} • {story.words} words
          </Text>

          <TouchableOpacity
            style={story.primary ? styles.buttonPrimary : styles.buttonSecondary}
          >
            <Text
              style={
                story.primary ? styles.buttonPrimaryText : styles.buttonSecondaryText
              }
            >
              {story.primary ? 'Start Reading' : 'Read & Translate'}
            </Text>

            <Ionicons
              name={story.primary ? 'book' : 'language'}
              size={18}
              color={story.primary ? '#fff' : colors.primary}
              style={{ marginLeft: 6 }}
            />
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
};

export default ReadingPracticeScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    content: {
      padding: 20,
    },
    sectionTitle: {
      fontSize: 24,
      fontWeight: '700',
      color: colors.textPrimary,
    },
    subText: {
      color: colors.textSecondary,
      fontSize: 14,
      marginTop: 4,
      marginBottom: 20,
    },
    storyCard: {
      padding: 16,
      borderRadius: 16,
      borderWidth: 1,
      marginBottom: 14,
    },
    row: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 6,
    },
    storyTitle: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.textPrimary,
    },
    storyMeta: {
      fontSize: 12,
      color: colors.textSecondary,
      marginBottom: 14,
    },
    levelPill: {
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    levelText: {
      color: colors.accent,
      fontSize: 11,
      fontWeight: '700',
    },
    buttonPrimary: {
      backgroundColor: colors.primary,
      paddingVertical: 12,
      borderRadius: 999,
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    buttonPrimaryText: {
      color: '#fff',
      fontSize: 14,
      fontWeight: '700',
    },
    buttonSecondary: {
      paddingVertical: 12,
      borderRadius: 999,
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: colors.primary,
      backgroundColor: 'transparent',
    },
    buttonSecondaryText: {
      color: colors.primary,
      fontSize: 14,
      fontWeight: '700',
    },
  });
