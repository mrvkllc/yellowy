// src/screens/practice/PracticeHomeScreen.tsx
import React, { useContext, useEffect, useMemo, useState } from 'react';
import { LinearGradient } from 'expo-linear-gradient';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { UI } from '../../theme/ui';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { PracticeStackParamList, MainTabParamList } from '../../navigation/types';
import { db } from '../../services/firebase';
import { doc, getDoc, collection, getDocs, orderBy, limit, query } from 'firebase/firestore';

import LoadingState from '../../components/ui/LoadingState';
import EmptyState from '../../components/ui/EmptyState';
import PrimaryButton from '../../components/ui/PrimaryButton';


type PracticeStackNav = NativeStackNavigationProp<PracticeStackParamList, 'PracticeHome'>;
type TabNav = BottomTabNavigationProp<MainTabParamList, 'Practice'>;

type UserMiniStats = {
  lastLessonId?: string | null;
};

const PracticeHomeScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { user } = useContext(AuthContext);
  const stackNav = useNavigation<PracticeStackNav>();
  const tabNav = useNavigation<TabNav>();

  const [miniStats, setMiniStats] = useState<UserMiniStats>({});
  const [loading, setLoading] = useState(true);
  const [practiceInfo, setPracticeInfo] = useState<{ weeklyScore: number; rank: number | null }>({
    weeklyScore: 0,
    rank: null,
  });

  useEffect(() => {
    const load = async () => {
      if (!user) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);

        const ref = doc(db, 'users', user.uid);
        const snap = await getDoc(ref);

        let weeklyScore = 0;

        if (snap.exists()) {
          const d = snap.data() as any;
          setMiniStats({ lastLessonId: d.lastLessonId ?? null });
          weeklyScore = d.practiceWeeklyScore ?? 0;
        } else {
          setMiniStats({});
        }

        // Weekly leaderboard rank (top 50 içinde mi)
        let rank: number | null = null;
        try {
          const lbRef = query(collection(db, 'users'), orderBy('practiceWeeklyScore', 'desc'), limit(50));
          const lbSnap = await getDocs(lbRef);

          lbSnap.docs.forEach((docSnap, idx) => {
            if (docSnap.id === user.uid) rank = idx + 1;
          });
        } catch (err) {
          console.log('PracticeHome leaderboard meta error', err);
        }

        setPracticeInfo({ weeklyScore, rank });
      } catch (e) {
        console.log('PracticeHome mini stats error', e);
        setMiniStats({});
        setPracticeInfo({ weeklyScore: 0, rank: null });
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [user?.uid]);

  const greetingName =
    user?.displayName || (typeof user?.email === 'string' ? user.email.split('@')[0] : 'Yellowy learner');

  const handleLeaderboard = () => stackNav.navigate('PracticeLeaderboard');
  const handleReading = () => stackNav.navigate('ReadingPractice');
 const handleWriting = () =>
  stackNav.navigate('WritingPractice', miniStats.lastLessonId ? { lessonId: miniStats.lastLessonId } : undefined);

  const handleListening = () => stackNav.navigate('ListeningPractice');

  const handleVocabPractice = () => {
    if (miniStats.lastLessonId) {
      stackNav.navigate('VocabPractice', { lessonId: miniStats.lastLessonId });
    } else {
      tabNav.navigate('Learn', { screen: 'Courses' } as any);
    }
  };

  if (loading) {
    return <LoadingState text="Pratik ekranı hazırlanıyor…" />;
  }

  if (!user) {
    return (
      <EmptyState
        title="Giriş gerekli"
        description="Practice ekranını kullanmak için giriş yapmalısın."
      />
    );
  }

  // Gradient renklerini tema üzerinden üretelim (hardcode sarı sevimli değil, kırılıyor)
  // theme.tsx içinde primarySoft yoksa: cardSoft’u kullanıyoruz.
  const primarySoft = (colors as any).primarySoft ?? colors.cardSoft;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Practice</Text>
          <Text style={styles.subtitle}>Short sessions to strengthen what you’re learning.</Text>
        </View>

        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{greetingName.charAt(0).toUpperCase()}</Text>
        </View>
      </View>

      {/* Weekly leaderboard */}
      <LinearGradient
        colors={[primarySoft, 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.leaderboardCard, { borderColor: colors.primary }]}
      >
        <View style={styles.leaderboardHeaderRow}>
          <View style={[styles.leaderboardTag, { backgroundColor: primarySoft, borderColor: colors.border }]}>
            <Ionicons name="people-outline" size={14} color={colors.primary} />
            <Text style={[styles.leaderboardTagText, { color: colors.textPrimary }]}>Community</Text>
          </View>

          <View style={[styles.leaderboardIconWrapper, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="trophy-outline" size={20} color={colors.primary} />
          </View>
        </View>

        <Text style={styles.leaderboardTitle}>Weekly leaderboard</Text>

        <Text style={styles.leaderboardText}>
          Climb the rankings with correct practice answers this week.
        </Text>

        {practiceInfo.rank !== null ? (
          <Text style={styles.leaderboardStats}>
            Your rank: #{practiceInfo.rank} • {practiceInfo.weeklyScore} pt this week
          </Text>
        ) : practiceInfo.weeklyScore > 0 ? (
          <Text style={styles.leaderboardStats}>
            {practiceInfo.weeklyScore} pt this week • Not in top 50 yet
          </Text>
        ) : (
          <Text style={styles.leaderboardStats}>
            No practice points yet this week – start a session to enter the board.
          </Text>
        )}

        <PrimaryButton title="View leaderboard" onPress={handleLeaderboard} />
      </LinearGradient>

      {/* Reading */}
      <View style={styles.card}>
        <View style={styles.cardHeaderRow}>
          <View style={styles.iconWrapper}>
            <Ionicons name="book-outline" size={18} color={colors.primary} />
          </View>
          <Text style={styles.cardTitle}>Reading practice</Text>
        </View>

        <Text style={styles.cardText}>
          Short stories & dialogs to improve reading and comprehension.
        </Text>

        <PrimaryButton title="Start reading" onPress={handleReading} />
      </View>

      {/* Writing */}
      <View style={styles.card}>
        <View style={styles.cardHeaderRow}>
          <View style={styles.iconWrapper}>
            <Ionicons name="pencil-outline" size={18} color={colors.primary} />
          </View>
          <Text style={styles.cardTitle}>Writing practice</Text>
        </View>

        <Text style={styles.cardText}>
          Turn prompts into sentences in your target language and get instant feedback.
        </Text>

        <PrimaryButton title="Start writing" onPress={handleWriting} />
      </View>

      {/* Vocab */}
      <View style={styles.card}>
        <View style={styles.cardHeaderRow}>
          <View style={styles.iconWrapper}>
            <Ionicons name="list-outline" size={18} color={colors.primary} />
          </View>
          <Text style={styles.cardTitle}>Vocab practice</Text>
        </View>

        <Text style={styles.cardText}>
          Review key words from your current lessons using spaced repetition.
        </Text>

        <PrimaryButton
          title={miniStats.lastLessonId ? 'Continue vocab session' : 'Choose a lesson'}
          onPress={handleVocabPractice}
        />
      </View>

      {/* Listening */}
      <View style={styles.card}>
        <View style={styles.cardHeaderRow}>
          <View style={styles.iconWrapper}>
            <Ionicons name="ear-outline" size={18} color={colors.primary} />
          </View>
          <Text style={styles.cardTitle}>Listening practice</Text>
        </View>

        <Text style={styles.cardText}>
          Listen to short audios and choose the correct sentence.
        </Text>

        <PrimaryButton title="Start listening" onPress={handleListening} />
      </View>
    </ScrollView>
  );
};



const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 20,
    },
    title: {
      fontSize: 22,
      fontWeight: '800',
      color: colors.textPrimary,
    },
    subtitle: {
      fontSize: 13,
      color: colors.textSecondary,
      marginTop: 4,
      maxWidth: 260,
    },

    avatar: {
      width: 40,
      height: 40,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
      borderColor: colors.border,
    },
    avatarText: {
      fontSize: 18,
      fontWeight: '800',
      color: colors.textPrimary,
    },

    leaderboardCard: {
      borderRadius: 16,
      padding: 16,
      marginBottom: 12,
      borderWidth: 1,
    },
    leaderboardHeaderRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 8,
    },
    leaderboardTag: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 999,
      gap: 6,
      borderWidth: 1,
    },
    leaderboardTagText: {
      fontSize: 11,
      fontWeight: '700',
    },
    leaderboardIconWrapper: {
      width: 32,
      height: 32,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
    },
    leaderboardTitle: {
      fontSize: 15,
      fontWeight: '800',
      color: colors.textPrimary,
      marginBottom: 4,
    },
    leaderboardText: {
      fontSize: 13,
      color: colors.textSecondary,
      marginBottom: 6,
    },
    leaderboardStats: {
      fontSize: 12,
      color: colors.textSecondary,
      marginBottom: 12,
      marginTop: 2,
    },

  card: {
  backgroundColor: colors.card,
  borderRadius: 16,
  borderWidth: 1,
  borderColor: colors.border,
},
    cardHeaderRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 8,
      gap: 8,
    },
    iconWrapper: {
      width: 28,
      height: 28,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    cardTitle: {
      fontSize: 15,
      fontWeight: '800',
      color: colors.textPrimary,
    },
    cardText: {
      fontSize: 13,
      color: colors.textSecondary,
      marginBottom: 10,
    },
  });
export default PracticeHomeScreen;