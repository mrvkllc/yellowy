// src/screens/practice/ListeningPracticeScreen.tsx
import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  FlatList,
  Alert,
} from 'react-native';
import { Audio } from 'expo-av';
import {
  collection,
  getDocs,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';

import { db } from '../../services/firebase';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { PracticeStackParamList } from '../../navigation/types';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

type Props = NativeStackScreenProps<
  PracticeStackParamList,
  'ListeningPractice'
>;

type ListeningExercise = {
  id: string;
  languagePair: 'tr-es' | 'en-es' | 'tr-en';
  level: 'A1' | 'A2' | 'B1' | 'B2';
  order: number;
  title: string;
  audioUrl: string;
  prompt: string;
  options: string[];
  correctIndex: number;
  transcript: string;
  explanation?: string;
};

const LETTERS = ['A', 'B', 'C', 'D', 'E', 'F'];

const ListeningPracticeScreen: React.FC<Props> = ({ navigation }) => {
  const { colors } = useAppTheme();
  const styles = createStyles(colors);

  const [exercises, setExercises] = useState<ListeningExercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);

  // TODO: user ayarlarından gelecek
  const languagePair: ListeningExercise['languagePair'] = 'tr-es';
  const level: ListeningExercise['level'] = 'A1';

  // ---- Firestore'dan veri çekme ----
  useEffect(() => {
    const loadExercises = async () => {
      try {
        const qRef = query(
          collection(db, 'listening_exercises'),
         // where('languagePair', '==', languagePair),
         // where('level', '==', level),
          orderBy('order', 'asc')
        );

        const snapshot = await getDocs(qRef);
        const data: ListeningExercise[] = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...(doc.data() as Omit<ListeningExercise, 'id'>),
        }));

        setExercises(data);
      } catch (err) {
        console.error('Listening fetch error', err);
        Alert.alert('Error', 'Listening exercises could not be loaded.');
      } finally {
        setLoading(false);
      }
    };

    loadExercises();
  }, [languagePair, level]);

  // ---- Ses çalma / durdurma ----
  const unloadSound = useCallback(async () => {
    if (sound) {
      try {
        await sound.unloadAsync();
      } catch (e) {
        console.log('Unload sound error', e);
      }
      setSound(null);
    }
  }, [sound]);

  const handlePlayPause = useCallback(async () => {
    const current = exercises[currentIndex];
    if (!current) return;

    try {
      if (sound && isPlaying) {
        await sound.pauseAsync();
        setIsPlaying(false);
        return;
      }

      if (sound && !isPlaying) {
        await sound.playAsync();
        setIsPlaying(true);
        return;
      }

      // yeni sound
      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: current.audioUrl },
        { shouldPlay: true }
      );
      setSound(newSound);
      setIsPlaying(true);

      newSound.setOnPlaybackStatusUpdate((status) => {
        if (!status.isLoaded) return;
        if (status.didJustFinish) {
          setIsPlaying(false);
        }
      });
    } catch (err) {
      console.error('Audio error', err);
      Alert.alert('Error', 'Audio could not be played.');
    }
  }, [exercises, currentIndex, sound, isPlaying]);

  useEffect(() => {
    return () => {
      // ekran kapanırken sesi temizle
      unloadSound();
    };
  }, [unloadSound]);

  // ---- Cevap kontrol ----
  const handleCheck = () => {
    if (selectedIndex === null) {
      Alert.alert('Select an option', 'Please choose an answer first.');
      return;
    }
    const current = exercises[currentIndex];
    if (!current) return;

    const correct = selectedIndex === current.correctIndex;
    setIsCorrect(correct);
    setChecked(true);

    // TODO: burada XP + progress entegrasyonu yapacağız (B aşaması)
    // if (correct) awardXp('listening', 10);
  };

  const handleNext = async () => {
    await unloadSound();
    setIsPlaying(false);
    setSelectedIndex(null);
    setChecked(false);
    setIsCorrect(null);
    setShowTranscript(false);

    if (currentIndex + 1 < exercises.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      Alert.alert('Great job!', 'You have completed all listening exercises.', [
        {
          text: 'Back to practice',
          onPress: () => navigation.goBack(),
        },
      ]);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.centerText}>Loading listening exercises…</Text>
      </View>
    );
  }

  if (!exercises.length) {
    return (
      <View style={styles.center}>
        <Text style={styles.emptyTitle}>No exercises yet</Text>
        <Text style={styles.emptyText}>
          We couldn&apos;t find any listening exercises for{' '}
          {languagePair.toUpperCase()} – {level}. Add some from the admin panel.
        </Text>
      </View>
    );
  }

  const current = exercises[currentIndex];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.screenTitle}>Listening practice</Text>
          <Text style={styles.screenSubtitle}>
            Listen to the audio and choose the correct sentence.
          </Text>
        </View>

        <View style={styles.rightHeader}>
          <View style={styles.chip}>
            <Ionicons
              name="language-outline"
              size={13}
              color={colors.textSecondary}
            />
            <Text style={styles.chipText}>{languagePair.toUpperCase()}</Text>
          </View>
          <View style={styles.chipSecondary}>
            <Text style={styles.chipSecondaryText}>{level}</Text>
          </View>
        </View>
      </View>

      {/* Progress */}
      <View style={styles.progressRow}>
        <Text style={styles.progressText}>
          Question {currentIndex + 1} of {exercises.length}
        </Text>
        <View style={styles.progressBarBackground}>
          <View
            style={[
              styles.progressBarFill,
              {
                width: `${((currentIndex + 1) / exercises.length) * 100}%`,
                backgroundColor: colors.primary,
              },
            ]}
          />
        </View>
      </View>

      {/* Card */}
      <View style={styles.card}>
        {/* Title */}
        <View style={styles.cardHeader}>
          <View style={styles.iconCircle}>
            <Ionicons
              name="ear-outline"
              size={20}
              color={colors.primary}
            />
          </View>
          <Text style={styles.exerciseTitle}>{current.title}</Text>
        </View>

        {/* Audio Controls */}
        <TouchableOpacity
          style={styles.audioButton}
          onPress={handlePlayPause}
          activeOpacity={0.8}
        >
          <View style={styles.audioIconWrapper}>
            <Ionicons
              name={isPlaying ? 'pause' : 'play'}
              size={22}
              color="#050816"
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.audioButtonTitle}>
              {isPlaying ? 'Pause audio' : 'Play audio'}
            </Text>
            <Text style={styles.audioButtonSubtitle}>Tap to listen again</Text>
          </View>
        </TouchableOpacity>

        {/* Prompt */}
        <Text style={styles.prompt}>{current.prompt}</Text>

        {/* Transcript Toggle */}
        <TouchableOpacity
          style={styles.transcriptToggle}
          onPress={() => setShowTranscript((prev) => !prev)}
          activeOpacity={0.7}
        >
          <Ionicons
            name={showTranscript ? 'chevron-up' : 'chevron-down'}
            size={14}
            color={colors.textSecondary}
          />
          <Text style={styles.transcriptToggleText}>
            {showTranscript ? 'Hide transcript' : 'Show transcript'}
          </Text>
        </TouchableOpacity>

        {showTranscript && (
          <View style={styles.transcriptBox}>
            <Text style={styles.transcriptLabel}>Transcript</Text>
            <Text style={styles.transcriptText}>{current.transcript}</Text>
          </View>
        )}

        {/* Options */}
        <FlatList
          data={current.options}
          keyExtractor={(_, index) => index.toString()}
          scrollEnabled={false}
          contentContainerStyle={{ marginTop: 8 }}
          renderItem={({ item, index }) => {
            const isSelected = selectedIndex === index;
            const isAnswerPhase = checked;
            let optionStyle = styles.option;

            if (isAnswerPhase) {
              if (index === current.correctIndex) {
                optionStyle = { ...styles.option, ...styles.optionCorrect };
              } else if (isSelected && index !== current.correctIndex) {
                optionStyle = { ...styles.option, ...styles.optionWrong };
              }
            } else if (isSelected) {
              optionStyle = { ...styles.option, ...styles.optionSelected };
            }

            return (
              <TouchableOpacity
                style={optionStyle}
                onPress={() => !checked && setSelectedIndex(index)}
                activeOpacity={0.85}
              >
                <View style={styles.optionLetter}>
                  <Text style={styles.optionLetterText}>
                    {LETTERS[index] ?? '?'}
                  </Text>
                </View>
                <Text style={styles.optionText}>{item}</Text>
              </TouchableOpacity>
            );
          }}
        />

        {/* Feedback */}
        {checked && isCorrect !== null && (
          <View style={styles.feedbackBox}>
            <View style={styles.feedbackRow}>
              <Ionicons
                name={isCorrect ? 'checkmark-circle' : 'close-circle'}
                size={18}
                color={isCorrect ? '#22c55e' : '#ef4444'}
              />
              <Text
                style={[
                  styles.feedbackText,
                  isCorrect ? styles.correctText : styles.wrongText,
                ]}
              >
                {isCorrect ? 'Correct!' : 'Not quite.'}
              </Text>
            </View>
            {!!current.explanation && (
              <Text style={styles.explanationText}>{current.explanation}</Text>
            )}
          </View>
        )}

        {/* Actions */}
        <View style={styles.actionsRow}>
          {!checked ? (
            <TouchableOpacity
              style={[
                styles.actionButton,
                { backgroundColor: colors.primary },
              ]}
              onPress={handleCheck}
              activeOpacity={0.9}
            >
              <Text style={styles.actionButtonText}>Check answer</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[
                styles.actionButton,
                { backgroundColor: colors.accent },
              ]}
              onPress={handleNext}
              activeOpacity={0.9}
            >
              <Text style={styles.actionButtonText}>
                {currentIndex + 1 === exercises.length
                  ? 'Finish session'
                  : 'Next question'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </View>
  );
};


const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      paddingHorizontal: 16,
      paddingTop: 16,
      paddingBottom: 8,
    },
    center: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.background,
      padding: 16,
    },
    centerText: {
      marginTop: 8,
      color: colors.textSecondary,
      fontSize: 14,
      textAlign: 'center',
    },
    emptyTitle: {
      fontSize: 18,
      fontWeight: '700',
      color: colors.textPrimary,
      marginBottom: 6,
    },
    emptyText: {
      color: colors.textSecondary,
      fontSize: 13,
      textAlign: 'center',
      maxWidth: 260,
    },
    headerRow: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      marginBottom: 12,
    },
    screenTitle: {
      fontSize: 22,
      fontWeight: '700',
      color: colors.textPrimary,
    },
    screenSubtitle: {
      marginTop: 4,
      fontSize: 12,
      color: colors.textSecondary,
      maxWidth: 260,
    },
    rightHeader: {
      alignItems: 'flex-end',
      gap: 6,
    },
    chip: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.cardSoft,
      gap: 4,
    },
    chipText: {
      fontSize: 11,
      color: colors.textSecondary,
      fontWeight: '500',
    },
    chipSecondary: {
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 999,
      backgroundColor: colors.accentSoft,
    },
    chipSecondaryText: {
      fontSize: 11,
      color: colors.accent,
      fontWeight: '700',
    },
    progressRow: {
      marginBottom: 12,
    },
    progressText: {
      fontSize: 12,
      color: colors.textSecondary,
      marginBottom: 4,
    },
    progressBarBackground: {
      width: '100%',
      height: 6,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      overflow: 'hidden',
    },
    progressBarFill: {
      height: '100%',
      borderRadius: 999,
    },
    card: {
      flex: 1,
      backgroundColor: colors.card,
      borderRadius: 18,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
    },
    cardHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 12,
      gap: 10,
    },
    iconCircle: {
      width: 32,
      height: 32,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    exerciseTitle: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.textPrimary,
      flexShrink: 1,
    },
    audioButton: {
      flexDirection: 'row',
      alignItems: 'center',
      borderRadius: 16,
      paddingHorizontal: 14,
      paddingVertical: 10,
      backgroundColor: colors.primarySoft,
      marginBottom: 12,
      gap: 10,
    },
    audioIconWrapper: {
      width: 34,
      height: 34,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#faf500',
    },
    audioButtonTitle: {
      fontSize: 14,
      fontWeight: '700',
      color: colors.textPrimary,
    },
    audioButtonSubtitle: {
      fontSize: 11,
      color: colors.textSecondary,
    },
    prompt: {
      fontSize: 13,
      color: colors.textSecondary,
      marginBottom: 8,
      marginTop: 2,
    },
    transcriptToggle: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.cardSoft,
      gap: 4,
      marginBottom: 6,
    },
    transcriptToggleText: {
      fontSize: 11,
      color: colors.textSecondary,
    },
    transcriptBox: {
      backgroundColor: colors.cardSoft,
      borderRadius: 12,
      padding: 10,
      marginBottom: 8,
      borderWidth: 1,
      borderColor: colors.border,
    },
    transcriptLabel: {
      fontSize: 11,
      color: colors.textSecondary,
      marginBottom: 3,
    },
    transcriptText: {
      fontSize: 13,
      color: colors.textPrimary,
    },
    option: {
      flexDirection: 'row',
      alignItems: 'center',
      borderRadius: 14,
      borderWidth: 1,
      borderColor: colors.border,
      paddingVertical: 9,
      paddingHorizontal: 12,
      marginTop: 8,
      backgroundColor: colors.cardSoft,
      gap: 10,
    },
    optionSelected: {
      borderColor: colors.primary,
      backgroundColor: colors.primarySoft,
    },
    optionCorrect: {
      borderColor: '#22c55e',
      backgroundColor: 'rgba(34,197,94,0.12)',
    },
    optionWrong: {
      borderColor: '#ef4444',
      backgroundColor: 'rgba(239,68,68,0.12)',
    },
    optionLetter: {
      width: 22,
      height: 22,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.background,
      borderWidth: 1,
      borderColor: colors.border,
    },
    optionLetterText: {
      fontSize: 11,
      fontWeight: '700',
      color: colors.textSecondary,
    },
    optionText: {
      flex: 1,
      fontSize: 13,
      color: colors.textPrimary,
    },
    feedbackBox: {
      marginTop: 12,
      paddingTop: 8,
      borderTopWidth: 1,
      borderTopColor: colors.border,
    },
    feedbackRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      marginBottom: 4,
    },
    feedbackText: {
      fontSize: 13,
      fontWeight: '600',
    },
    correctText: {
      color: '#22c55e',
    },
    wrongText: {
      color: '#ef4444',
    },
    explanationText: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    actionsRow: {
      marginTop: 16,
      flexDirection: 'row',
      justifyContent: 'flex-end',
    },
    actionButton: {
      borderRadius: 999,
      paddingHorizontal: 20,
      paddingVertical: 10,
    },
    actionButtonText: {
      fontSize: 13,
      fontWeight: '700',
      color: '#ffffff',
    },
  });

export default ListeningPracticeScreen;