// src/screens/practice/VocabPracticeScreen.tsx
import React, { useContext, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { RouteProp, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';

import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { AuthContext } from '../../context/AuthContext';
import { PracticeStackParamList } from '../../navigation/types';
import { getLessonVocab, LessonVocab } from '../../services/vocab';
import {
  getUserWordProgressMap,
  updateWordReview,
  ReviewQuality,
  UserWordProgress,
} from '../../services/vocabProgress';
import { awardPracticeScore } from '../../services/progress';

/* ---------------- TYPES ---------------- */

type RouteT = RouteProp<PracticeStackParamList, 'VocabPractice'>;

type VocabCard = {
  vocab: LessonVocab;
  progress: UserWordProgress | null;
};

type LangCode = 'tr' | 'en' | 'es';
type Direction = 'forward' | 'reverse';

/* ---------------- HELPERS ---------------- */

const buildPairConfig = (native: LangCode, target: LangCode) => ({
  forward: {
    front: target,
    back: native,
    label: `${target.toUpperCase()} → ${native.toUpperCase()}`,
  },
  reverse: {
    front: native,
    back: target,
    label: `${native.toUpperCase()} → ${target.toUpperCase()}`,
  },
});

const getText = (v: LessonVocab, lang: LangCode) => {
  if (lang === 'tr') return v.tr ?? '';
  if (lang === 'en') return v.en ?? '';
  return v.es ?? '';
};

const getExample = (v: LessonVocab, lang: LangCode) => {
  if (lang === 'tr') return v.exampleTr ?? '';
  if (lang === 'en') return v.exampleEn ?? '';
  return v.exampleEs ?? '';
};

const localeOf = (lang: LangCode) => {
  if (lang === 'tr') return 'tr-TR';
  if (lang === 'es') return 'es-ES';
  return 'en-US';
};

/* ---------------- COMPONENT ---------------- */

const VocabPracticeScreen: React.FC = () => {
  const route = useRoute<RouteT>();
  const { lessonId } = route.params;

  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  // AuthContext içinde userProfile yoksa burada patlarsın.
  // Bu ekranı kullanabilmek için AuthContext’e userProfile’ı eklemiş olman gerekiyor.
  const { user, userProfile } = useContext(AuthContext) as any;

  const [loading, setLoading] = useState(true);
  const [cards, setCards] = useState<VocabCard[]>([]);
  const [index, setIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [direction, setDirection] = useState<Direction>('forward');
  const [saving, setSaving] = useState(false);

  const [seen, setSeen] = useState(0);
  const [known, setKnown] = useState(0);

  /* -------- GUARD -------- */
  if (!user || !userProfile) {
    return (
      <View style={styles.center}>
        <Text style={styles.centerText}>Profil yükleniyor…</Text>
      </View>
    );
  }

  const nativeLang = userProfile.nativeLang as LangCode | undefined;
  const targetLang = userProfile.targetLang as LangCode | undefined;

  // languagePair undefined gelirse fallback üret
  const languagePair: string =
    (userProfile.languagePair as string | undefined) ??
    (nativeLang && targetLang ? `${nativeLang}-${targetLang}` : 'tr-en');

  // native/target yoksa da fallback ile patlamasın
  const safeNative: LangCode = (nativeLang ?? 'tr') as LangCode;
  const safeTarget: LangCode = (targetLang ?? 'en') as LangCode;

  const pairCfg = buildPairConfig(safeNative, safeTarget);
  const dirCfg = pairCfg[direction];

  const current = cards[index];

  /* -------- LOAD DATA -------- */
  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);

        // ✅ getLessonVocab tek argüman bekliyorsa böyle kalmalı
        const vocabList = await getLessonVocab(lessonId);

        const progressMap = await getUserWordProgressMap(user.uid, lessonId);

        const now = new Date();
        const due: VocabCard[] = [];

        vocabList.forEach((v) => {
          const p = progressMap[v.id] ?? null;

          // hiç çalışılmamış veya review zamanı gelmişse due
          if (!p || !p.nextReviewAt || p.nextReviewAt.toDate() <= now) {
            due.push({ vocab: v, progress: p });
          }
        });

        const finalCards =
          due.length > 0
            ? due
            : vocabList.map((v) => ({
                vocab: v,
                progress: progressMap[v.id] ?? null,
              }));

        setCards(finalCards);
        setIndex(0);
        setSeen(0);
        setKnown(0);
        setShowAnswer(false);
      } catch (e) {
        console.log('VocabPractice load error', e);
        setCards([]);
      } finally {
        setLoading(false);
      }
    };

    load();
    // languagePair burada sadece “context değişince reload” için dursun.
    // getLessonVocab şu an pair’e göre filtrelemiyor; ileride servisi güncellersen burada kullanırsın.
  }, [lessonId, user.uid, languagePair]);

  /* -------- ACTIONS -------- */

  const speak = () => {
    if (!current) return;

    const text = getText(current.vocab, dirCfg.front).trim();
    if (!text) return; // ✅ boşsa TTS çağırma

    Speech.stop();
    Speech.speak(text, {
      language: localeOf(dirCfg.front),
      rate: 1,
      pitch: 1,
    });
  };

  const answer = async (q: ReviewQuality) => {
    if (!current) return;
    setSaving(true);

    try {
      await updateWordReview(user.uid, current.vocab, q);
      setSeen((s) => s + 1);

      if (q === 'good') {
        setKnown((k) => k + 1);
        awardPracticeScore(user.uid, 'vocab', 1).catch(() => {});
      }

      setShowAnswer(false);

      if (index < cards.length - 1) {
        setIndex((i) => i + 1);
      } else {
        Alert.alert('Bitti', `${cards.length} kelime tamamlandı.`);
      }
    } catch (e) {
      console.log('answer error', e);
    } finally {
      setSaving(false);
    }
  };

  /* -------- RENDER -------- */

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.primary} />
        <Text style={styles.centerText}>Yükleniyor…</Text>
      </View>
    );
  }

  if (!current) {
    return (
      <View style={styles.center}>
        <Text style={styles.centerText}>Kelime bulunamadı.</Text>
      </View>
    );
  }

  const frontWord = getText(current.vocab, dirCfg.front);
  const backWord = getText(current.vocab, dirCfg.back);

  const frontExample = getExample(current.vocab, dirCfg.front);
  const backExample = getExample(current.vocab, dirCfg.back);

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Kelime Pratiği</Text>

      <Text style={styles.meta}>
        Pair: {languagePair} • {index + 1}/{cards.length} • Görülen: {seen} • Kolaydı: {known}
      </Text>

      {/* Direction Tabs */}
      <View style={styles.tabs}>
        {(['forward', 'reverse'] as Direction[]).map((d) => (
          <TouchableOpacity
            key={d}
            style={[styles.tab, direction === d && styles.tabActive]}
            onPress={() => {
              setDirection(d);
              setShowAnswer(false);
            }}
            activeOpacity={0.85}
          >
            <Text style={[styles.tabText, direction === d && styles.tabTextActive]}>
              {pairCfg[d].label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Card */}
      <TouchableOpacity
        style={styles.card}
        onPress={() => setShowAnswer((s) => !s)}
        activeOpacity={0.9}
      >
        <View style={styles.cardHeader}>
          <Text style={styles.cardLabel}>{pairCfg[direction].label}</Text>

          <TouchableOpacity onPress={speak} style={styles.audioBtn} activeOpacity={0.8}>
            <Ionicons name="volume-high-outline" size={18} color={colors.primary} />
          </TouchableOpacity>
        </View>

        {!showAnswer ? (
          <>
            <Text style={styles.word}>{frontWord}</Text>
            {!!frontExample?.trim() && <Text style={styles.example}>{frontExample}</Text>}
            <Text style={styles.hint}>Çevirmek için dokun</Text>
          </>
        ) : (
          <>
            <Text style={styles.wordBack}>{backWord}</Text>
            {!!backExample?.trim() && <Text style={styles.example}>{backExample}</Text>}
            <Text style={styles.hint}>Seçimini yap</Text>
          </>
        )}
      </TouchableOpacity>

      {/* Answers */}
      {showAnswer && (
        <View style={styles.answers}>
          <TouchableOpacity
            style={[styles.answerBtn, styles.answerAgain]}
            onPress={() => answer('again')}
            disabled={saving}
          >
            <Text style={styles.answerText}>Unuttum</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.answerBtn, styles.answerHard]}
            onPress={() => answer('hard')}
            disabled={saving}
          >
            <Text style={styles.answerText}>Zordu</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.answerBtn, styles.answerGood]}
            onPress={() => answer('good')}
            disabled={saving}
          >
            <Text style={styles.answerText}>Kolaydı</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
};

export default VocabPracticeScreen;

/* ---------------- STYLES ---------------- */

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 16 },
    centerText: { color: colors.textSecondary, textAlign: 'center' },

    title: { fontSize: 18, fontWeight: '700', marginBottom: 8, color: colors.textPrimary },
    meta: { fontSize: 12, color: colors.textSecondary, marginBottom: 12 },

    tabs: { flexDirection: 'row', gap: 8, marginBottom: 12 },
    tab: {
      flex: 1,
      paddingVertical: 10,
      alignItems: 'center',
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    tabActive: {
      backgroundColor: colors.card,
    },
    tabText: { color: colors.textSecondary, fontSize: 12, fontWeight: '600' },
    tabTextActive: { color: colors.textPrimary },

    card: {
      padding: 18,
      borderRadius: 16,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 16,
    },
    cardHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 10,
    },
    cardLabel: { fontSize: 12, color: colors.textSecondary, fontWeight: '600' },
    audioBtn: {
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },

    word: { fontSize: 28, fontWeight: '800', color: colors.textPrimary, marginBottom: 8 },
    wordBack: { fontSize: 18, fontWeight: '700', color: colors.textPrimary, marginBottom: 8 },

    example: { fontSize: 13, color: colors.textSecondary, fontStyle: 'italic' },
    hint: { marginTop: 12, fontSize: 11, color: colors.textSecondary },

    answers: { flexDirection: 'row', gap: 8 },
    answerBtn: {
      flex: 1,
      paddingVertical: 12,
      borderRadius: 999,
      alignItems: 'center',
      borderWidth: 1,
      borderColor: colors.border,
    },
    answerAgain: { backgroundColor: colors.accentSoft },
    answerHard: { backgroundColor: '#fef3c7' },
    answerGood: { backgroundColor: '#dcfce7' },
    answerText: { fontSize: 13, fontWeight: '700', color: colors.textPrimary },
  });
