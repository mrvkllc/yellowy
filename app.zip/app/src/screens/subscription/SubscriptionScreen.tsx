// src/screens/subscription/SubscriptionScreen.tsx
import React, { useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

const SubscriptionScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const handleSubscribe = () => {
    console.log("Premium activated!");
    // buraya ödeme sistemi entegre olacak
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Go Premium</Text>
      <Text style={styles.subtitle}>Unlock all features and boost your Spanish learning.</Text>

      <View style={styles.card}>
        <View style={styles.row}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.feature}>Unlimited AI Chat</Text>
        </View>

        <View style={styles.row}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.feature}>All Courses Unlocked</Text>
        </View>

        <View style={styles.row}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.feature}>Reading & Translation Stories</Text>
        </View>

        <View style={styles.row}>
          <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
          <Text style={styles.feature}>Flashcards + Games</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.subscribeButton} onPress={handleSubscribe}>
        <Text style={styles.subscribeText}>Upgrade — $7.99 / month</Text>
      </TouchableOpacity>
    </View>
  );
};

export default SubscriptionScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 24,
      paddingTop: 60,
    },
    title: {
      color: colors.textPrimary,
      fontSize: 26,
      fontWeight: '700',
      textAlign: 'center',
      marginBottom: 8,
    },
    subtitle: {
      color: colors.textSecondary,
      fontSize: 14,
      textAlign: 'center',
      marginBottom: 24,
    },
    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 20,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 24,
    },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 8,
    },
    feature: {
      marginLeft: 12,
      fontSize: 16,
      color: colors.textPrimary,
      fontWeight: '500',
    },
    subscribeButton: {
      backgroundColor: colors.primary,
      borderRadius: 999,
      paddingVertical: 14,
      alignItems: 'center',
    },
    subscribeText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: '700',
    },
  });
