import React, { useState, useRef, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

type Message = {
  id: string;
  from: 'user' | 'ai';
  text: string;
};

const AIChatScreen: React.FC = () => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      from: 'ai',
      text: 'Hola Merve 👋 How can I help you practice today?',
    },
  ]);

  const [input, setInput] = useState('');
  const flatListRef = useRef<FlatList>(null);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      from: 'user',
      text: input.trim(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');

    setTimeout(() => {
      const aiReply: Message = {
        id: (Date.now() + 1).toString(),
        from: 'ai',
        text: 'Great sentence! Try saying it in Spanish too 🌟',
      };
      setMessages((prev) => [...prev, aiReply]);
    }, 500);

    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 50);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Ionicons name="sparkles" size={24} color={colors.accent} />
        <Text style={styles.headerText}>AI Conversation</Text>
      </View>

      {/* Messages */}
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={(m) => m.id}
        contentContainerStyle={styles.messagesContainer}
        onContentSizeChange={() =>
          flatListRef.current?.scrollToEnd({ animated: true })
        }
        renderItem={({ item }) => (
          <View
            style={[
              styles.bubble,
              item.from === 'user' ? styles.userBubble : styles.aiBubble,
            ]}
          >
            <Text
              style={[
                styles.messageText,
                {
                  color:
                    item.from === 'user'
                      ? '#111'
                      : colors.textPrimary,
                },
              ]}
            >
              {item.text}
            </Text>
          </View>
        )}
      />

      {/* Input Bar */}
      <View style={styles.inputRow}>
        <TouchableOpacity style={styles.micButton}>
          <Ionicons name="mic-outline" size={22} color={colors.textSecondary} />
        </TouchableOpacity>

        <TextInput
          style={styles.input}
          placeholder="Write something..."
          placeholderTextColor={colors.textSecondary}
          value={input}
          onChangeText={setInput}
        />

        <TouchableOpacity
          style={[
            styles.sendButton,
            { backgroundColor: input.trim() ? colors.primary : colors.cardSoft },
          ]}
          onPress={handleSend}
        >
          <Ionicons
            name="send"
            size={20}
            color={input.trim() ? '#fff' : colors.textSecondary}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default AIChatScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    // Header
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerText: {
      color: colors.textPrimary,
      fontSize: 18,
      fontWeight: '700',
      marginLeft: 8,
    },

    // Messages
    messagesContainer: {
      padding: 16,
      paddingBottom: 80,
    },
    bubble: {
      maxWidth: '80%',
      padding: 12,
      marginBottom: 10,
      borderRadius: 16,
    },
    userBubble: {
      backgroundColor: colors.accent,
      alignSelf: 'flex-end',
      borderBottomRightRadius: 4,
    },
    aiBubble: {
      backgroundColor: colors.card,
      alignSelf: 'flex-start',
      borderBottomLeftRadius: 4,
      borderWidth: 1,
      borderColor: colors.border,
    },
    messageText: {
      fontSize: 15,
      lineHeight: 20,
    },

    // Input Bar
    inputRow: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 12,
      borderTopWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.background,
    },
    micButton: {
      marginRight: 10,
    },
    input: {
      flex: 1,
      backgroundColor: colors.card,
      borderRadius: 999,
      paddingHorizontal: 14,
      paddingVertical: 10,
      borderWidth: 1,
      borderColor: colors.border,
      color: colors.textPrimary,
      fontSize: 15,
    },
    sendButton: {
      marginLeft: 10,
      padding: 12,
      borderRadius: 999,
    },
  });
