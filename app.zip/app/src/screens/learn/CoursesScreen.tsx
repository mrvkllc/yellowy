// src/screens/learn/CoursesScreen.tsx
import React, { useEffect, useMemo, useState, useContext } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { collection, getDocs, onSnapshot, orderBy, query, doc } from 'firebase/firestore';

import { LearnStackParamList } from '../../navigation/types';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { db } from '../../services/firebase';
import { AuthContext } from '../../context/AuthContext';

import LoadingState from '../../components/ui/LoadingState';
import EmptyState from '../../components/ui/EmptyState';

type Props = NativeStackScreenProps<LearnStackParamList, 'Courses'>;

type LessonCard = {
  id: string;
  title: string;
  level: string;       // "A1"
  courseId?: string;
  order: number;       // required for sorting/locking
};

const CoursesScreen: React.FC<Props> = ({ navigation }) => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { user } = useContext(AuthContext);

  const [lessons, setLessons] = useState<LessonCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [completedLessonIds, setCompletedLessonIds] = useState<string[]>([]);

  // 1) Load lessons
  useEffect(() => {
    const loadLessons = async () => {
      try {
        setError('');
        setLoading(true);

        const ref = collection(db, 'lessons');
        const qRef = query(ref, orderBy('order', 'asc'));
        const snap = await getDocs(qRef);

        const data: LessonCard[] = snap.docs
          .map((docSnap) => {
            const d = docSnap.data() as any;
            return {
              id: docSnap.id,
              title: d.title ?? docSnap.id,
              level: d.level ?? 'A1',
              courseId: d.courseId,
              order: typeof d.order === 'number' ? d.order : 999999,
            };
          })
          .sort((a, b) => a.order - b.order);

        setLessons(data);
      } catch (e) {
        console.log('LOAD LESSONS ERROR', e);
        setError('Dersler yüklenemedi. Lütfen tekrar dene.');
      } finally {
        setLoading(false);
      }
    };

    loadLessons();
  }, []);

  // 2) Listen user progress
  useEffect(() => {
    if (!user?.uid) return;

    const ref = doc(db, 'users', user.uid);
    const unsub = onSnapshot(
      ref,
      (snap) => {
        if (!snap.exists()) {
          setCompletedLessonIds([]);
          return;
        }
        const data = snap.data() as any;
        const ids = Array.isArray(data.completedLessonIds) ? data.completedLessonIds : [];
        setCompletedLessonIds(ids);
      },
      (err) => {
        console.log('COURSES USER SNAP ERROR', err);
        // burada UI'ı bozma, sadece sessiz geç
      }
    );

    return () => unsub();
  }, [user?.uid]);

  // 3) A1 progress + locking logic
  const {
    a1Lessons,
    completedCount,
    totalCount,
    progressRatio,
    nextUnlockedOrder,
    nextLessonId,
  } = useMemo(() => {
    const a1 = lessons.filter((l) => (l.level ?? 'A1') === 'A1').sort((a, b) => a.order - b.order);

    const completedSet = new Set(completedLessonIds);
    const completed = a1.filter((l) => completedSet.has(l.id)).length;

    // Sequential unlock: next unlocked = smallest order that is NOT completed
    const next = a1.find((l) => !completedSet.has(l.id)) ?? null;

    const total = a1.length;
    const ratio = total > 0 ? Math.min(1, completed / total) : 0;

    // If no A1 lesson, keep safe fallbacks
    return {
      a1Lessons: a1,
      completedCount: completed,
      totalCount: total,
      progressRatio: ratio,
      nextUnlockedOrder: next ? next.order : Number.POSITIVE_INFINITY,
      nextLessonId: next ? next.id : null,
    };
  }, [lessons, completedLessonIds]);

  if (loading) return <LoadingState text="Dersler yükleniyor…" />;

  if (error) {
    return <EmptyState title="Bir şeyler ters gitti" description={error} />;
  }

  if (a1Lessons.length === 0) {
    return (
      <EmptyState
        title="Henüz A1 dersi yok"
        description="Admin panelinden A1 lesson eklediğinde burada listelenecek."
      />
    );
  }

  const percentText = `${Math.round(progressRatio * 100)}%`;

  const renderItem = ({ item, index }: { item: LessonCard; index: number }) => {
    const isCompleted = completedLessonIds.includes(item.id);

    // Locked rule:
    // - Completed always accessible (review)
    // - Next lesson accessible (first incomplete)
    // - Everything after next lesson locked
    const isNext = !!nextLessonId && item.id === nextLessonId;
    const isLocked = !isCompleted && !isNext;

    const statusIcon = isCompleted
      ? { name: 'checkmark-circle' as const, color: '#22c55e' }
      : isLocked
      ? { name: 'lock-closed' as const, color: colors.textSecondary }
      : { name: 'play-circle' as const, color: colors.primary };

    const onPress = () => {
      if (isLocked) return;
      navigation.navigate('LessonDetail', { lessonId: item.id });
    };

    return (
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={onPress}
        disabled={isLocked}
        style={[
          styles.card,
          isLocked && styles.cardLocked,
        ]}
      >
        <View style={styles.cardTopRow}>
          <View style={{ flex: 1 }}>
            <Text
              style={[styles.cardTitle, isLocked && styles.cardTitleLocked]}
              numberOfLines={2}
            >
              {item.title}
            </Text>

            <View style={styles.metaRow}>
              <View style={styles.pill}>
                <Text style={styles.pillText}>{item.level}</Text>
              </View>

              <Text style={[styles.cardMeta, isLocked && styles.cardMetaLocked]}>
                {isCompleted ? 'Completed' : isNext ? 'Next' : 'Locked'}
              </Text>
            </View>
          </View>

          <View style={styles.statusIconWrap}>
            <Ionicons name={statusIcon.name} size={20} color={statusIcon.color} />
          </View>
        </View>

        {/* Mini progress under each card (optional, light) */}
        <View style={styles.cardBottomRow}>
          <Text style={[styles.cardHint, isLocked && styles.cardHintLocked]}>
            Lesson {index + 1}
          </Text>

          {isCompleted ? (
            <View style={styles.reviewChip}>
              <Ionicons name="refresh" size={14} color={colors.textSecondary} />
              <Text style={styles.reviewChipText}>Review</Text>
            </View>
          ) : isNext ? (
            <View style={styles.nextChip}>
              <Ionicons name="arrow-forward" size={14} color={colors.primary} />
              <Text style={styles.nextChipText}>Start</Text>
            </View>
          ) : (
            <View style={styles.lockChip}>
              <Ionicons name="lock-closed" size={14} color={colors.textSecondary} />
              <Text style={styles.lockChipText}>Complete previous</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>A1 Course</Text>
        <Text style={styles.subtitle}>
          Progress: {completedCount}/{totalCount} • {percentText}
        </Text>

        <View style={styles.progressBarBg}>
          <View style={[styles.progressBarFill, { width: `${progressRatio * 100}%` }]} />
        </View>

        {/* Next lesson quick CTA */}
        {!!nextLessonId && (
          <TouchableOpacity
            activeOpacity={0.9}
            style={styles.nextLessonCta}
            onPress={() => navigation.navigate('LessonDetail', { lessonId: nextLessonId })}
          >
            <View style={{ flex: 1 }}>
              <Text style={styles.nextLessonTitle}>Continue</Text>
              <Text style={styles.nextLessonSub}>
                Next lesson is unlocked. Start now.
              </Text>
            </View>
            <Ionicons name="arrow-forward-circle" size={24} color={colors.primary} />
          </TouchableOpacity>
        )}
      </View>

      <FlatList
        data={a1Lessons}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={renderItem}
      />
    </View>
  );
};

export default CoursesScreen;

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },

    header: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 8 },
    title: { fontSize: 22, fontWeight: '900', color: colors.textPrimary },
    subtitle: { marginTop: 6, fontSize: 13, color: colors.textSecondary, fontWeight: '700' },

    progressBarBg: {
      marginTop: 10,
      height: 10,
      borderRadius: 999,
      overflow: 'hidden',
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    progressBarFill: {
      height: '100%',
      backgroundColor: colors.primary,
      borderRadius: 999,
    },

    nextLessonCta: {
      marginTop: 12,
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 14,
      borderWidth: 1,
      borderColor: colors.border,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
    },
    nextLessonTitle: { color: colors.textPrimary, fontSize: 14, fontWeight: '900' },
    nextLessonSub: { marginTop: 2, color: colors.textSecondary, fontSize: 12, lineHeight: 16 },

    listContent: { padding: 16, paddingTop: 10 },

    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 16,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
    cardLocked: {
      backgroundColor: colors.cardSoft,
      opacity: 0.7,
    },

    cardTopRow: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 10,
    },
    cardTitle: {
      color: colors.textPrimary,
      fontSize: 15,
      fontWeight: '900',
      lineHeight: 20,
    },
    cardTitleLocked: {
      color: colors.textSecondary,
    },

    metaRow: {
      marginTop: 10,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },

    pill: {
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    pillText: {
      color: colors.textSecondary,
      fontSize: 11,
      fontWeight: '800',
    },

    cardMeta: {
      color: colors.textSecondary,
      fontSize: 12,
      fontWeight: '800',
    },
    cardMetaLocked: {
      color: colors.textSecondary,
    },

    statusIconWrap: {
      width: 34,
      height: 34,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.cardSoft,
      alignItems: 'center',
      justifyContent: 'center',
    },

    cardBottomRow: {
      marginTop: 12,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 10,
    },
    cardHint: { color: colors.textSecondary, fontSize: 12, fontWeight: '700' },
    cardHintLocked: { color: colors.textSecondary },

    reviewChip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.cardSoft,
    },
    reviewChipText: { color: colors.textSecondary, fontSize: 11, fontWeight: '800' },

    nextChip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.cardSoft,
    },
    nextChipText: { color: colors.textPrimary, fontSize: 11, fontWeight: '900' },

    lockChip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.cardSoft,
    },
    lockChipText: { color: colors.textSecondary, fontSize: 11, fontWeight: '800' },
  });
