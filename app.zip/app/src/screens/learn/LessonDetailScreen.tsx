import React, { useEffect, useMemo, useState, useContext } from 'react';
import { View, Text, StyleSheet, ScrollView, Modal, Platform } from 'react-native';
import { RouteProp, useRoute, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { doc, getDoc } from 'firebase/firestore';

import { LearnStackParamList } from '../../navigation/types';
import { useAppTheme, AppThemeColors } from '../../theme/theme';
import { db } from '../../services/firebase';
import { AuthContext } from '../../context/AuthContext';
import { applyLessonCompleted } from '../../services/progress';

import LoadingState from '../../components/ui/LoadingState';
import EmptyState from '../../components/ui/EmptyState';
import PrimaryButton from '../../components/ui/PrimaryButton';
import SecondaryButton from '../../components/ui/SecondaryButton';

type LessonDetailRouteProp = RouteProp<LearnStackParamList, 'LessonDetail'>;

type LessonStep = {
  id: string;
  order: number;
  type: string;
  title?: string;
  text?: string;
  question?: string;
  statement?: string;
};

type Lesson = {
  lessonId: string;
  title: string;
  description?: string;
  xp?: number;
  estimatedMinutes?: number;
  steps: LessonStep[];
};

type LessonCompleteStats = {
  gainedXp: number;
  todayXP: number;
  dailyGoalXP: number;
  currentStreak: number;
  totalLessonsCompleted: number;
  alreadyCompleted: boolean;
};

const LessonDetailScreen: React.FC = () => {
  const route = useRoute<LessonDetailRouteProp>();
  const { lessonId } = route.params;

  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const { user } = useContext(AuthContext);
  const navigation = useNavigation<NativeStackNavigationProp<LearnStackParamList>>();

  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [completedStats, setCompletedStats] = useState<LessonCompleteStats | null>(null);
  const [showComplete, setShowComplete] = useState(false);

  // ✅ Step index artık tek kaynak: LessonDetail
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const fetchLesson = async () => {
      setLoading(true);
      setError(null);

      try {
        const ref = doc(db, 'lessons', lessonId);
        const snap = await getDoc(ref);

        if (!snap.exists()) {
          setError('Bu ders bulunamadı.');
          setLesson(null);
          return;
        }

        const data = snap.data() as any;
        const stepsRaw = (data.steps ?? []) as any[];

        const steps: LessonStep[] = stepsRaw
          .map((s: any, index: number) => ({
            id: s.id ?? `step-${index + 1}`,
            order: s.order ?? index + 1,
            type: s.type ?? 'info',
            title: s.title ?? s.question ?? s.statement ?? '',
            text: s.text,
            question: s.question,
            statement: s.statement,
          }))
          .sort((a, b) => a.order - b.order);

        const normalized: Lesson = {
          lessonId: data.lessonId ?? lessonId,
          title: data.title ?? lessonId,
          description: data.description ?? '',
          xp: data.xp ?? 0,
          estimatedMinutes: data.estimatedMinutes ?? 0,
          steps,
        };

        setLesson(normalized);
        setStepIndex(0); // ✅ derse girince step reset
      } catch (e) {
        console.log('LessonDetail fetch error', e);
        setError('Ders yüklenirken bir hata oluştu.');
        setLesson(null);
      } finally {
        setLoading(false);
      }
    };

    fetchLesson();
  }, [lessonId]);

  const handleLessonCompleted = async () => {
    if (!user) return;

    try {
      const result = await applyLessonCompleted(user.uid, lesson?.lessonId ?? lessonId);

      setCompletedStats({
        gainedXp: result.gainedXp,
        todayXP: result.todayXP,
        dailyGoalXP: result.dailyGoalXP,
        currentStreak: result.currentStreak,
        totalLessonsCompleted: result.totalLessonsCompleted,
        alreadyCompleted: result.alreadyCompleted,
      });

      setShowComplete(true);
    } catch (e) {
      console.log('applyLessonCompleted error', e);
    }
  };

  const getNextLessonId = (): string | null => {
    const id = lesson?.lessonId ?? lessonId;
    const match = id.match(/(\d+)$/);
    if (!match) return null;
    const num = parseInt(match[1], 10);
    return id.replace(/(\d+)$/, String(num + 1));
  };

  if (loading) return <LoadingState text="Ders yükleniyor…" />;

  if (error || !lesson) {
    return <EmptyState title="Ders bulunamadı" description={error ?? 'Bu derse ulaşılamadı.'} />;
  }

  const stepsCount = lesson.steps.length;
  const hasSteps = stepsCount > 0;

  const isFirst = stepIndex === 0;
  const isLast = stepIndex === stepsCount - 1;

  return (
    <View style={styles.screen}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={{ padding: 16, paddingBottom: 140 }}
      >
        {/* Header Card */}
        <View style={styles.headerCard}>
          <View style={styles.headerTopRow}>
            <Text style={styles.lessonTitle}>{lesson.title}</Text>
            <View style={styles.pill}>
              <Text style={styles.pillText}>{lesson.xp ?? 0} XP</Text>
            </View>
          </View>

          {!!lesson.description && <Text style={styles.lessonDesc}>{lesson.description}</Text>}

          <Text style={styles.lessonMeta}>
            Tahmini süre: {lesson.estimatedMinutes ?? 0} dk • Step: {lesson.steps.length}
          </Text>
        </View>

        {/* Steps */}
        {!hasSteps ? (
          <EmptyState title="Step yok" description="Bu derse ait step bulunamadı." />
        ) : (
          <LessonStepPlayer
            steps={lesson.steps}
            index={stepIndex}
          />
        )}
      </ScrollView>

      {/* ✅ GERÇEK FIXED BAR (ekranın en altı) */}
      {hasSteps && (
        <View style={styles.bottomBar}>
          <SecondaryButton
            title="Önceki"
            onPress={() => setStepIndex((i) => Math.max(0, i - 1))}
            disabled={isFirst}
            style={{ flex: 1 }}
          />

          {isLast ? (
            <PrimaryButton
              title="Dersi Bitir"
              onPress={() => void handleLessonCompleted()}
              style={{ flex: 1 }}
            />
          ) : (
            <PrimaryButton
              title="Sonraki"
              onPress={() => setStepIndex((i) => Math.min(stepsCount - 1, i + 1))}
              style={{ flex: 1 }}
            />
          )}
        </View>
      )}

      {/* Modal */}
      <LessonCompleteModal
        visible={showComplete}
        stats={completedStats}
        onClose={() => setShowComplete(false)}
        onGoNextLesson={() => {
          const nextId = getNextLessonId();
          setShowComplete(false);

          if (nextId) navigation.replace('LessonDetail', { lessonId: nextId });
          else navigation.navigate('Courses');
        }}
      />
    </View>
  );
};

export default LessonDetailScreen;

/* -------------------- Step Player: Card + Progress (NO bottom bar) -------------------- */

type StepPlayerProps = {
  steps: LessonStep[];
  index: number;
};

const LessonStepPlayer: React.FC<StepPlayerProps> = ({ steps, index }) => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const step = steps[index];
  const progress = steps.length > 0 ? (index + 1) / steps.length : 0;

  const bodyText =
    (step.type === 'info' && step.text) ||
    step.question ||
    step.statement ||
    step.text ||
    '';

  return (
    <View style={{ marginTop: 8 }}>
      <View style={styles.stepTopMeta}>
        <Text style={styles.stepMetaText}>
          Step {index + 1}/{steps.length} • {step.type}
        </Text>
        <Text style={styles.stepMetaText}>{Math.round(progress * 100)}%</Text>
      </View>

      <View style={styles.progressBarBg}>
        <View
          style={[
            styles.progressBarFill,
            { width: `${progress * 100}%`, backgroundColor: colors.primary },
          ]}
        />
      </View>

      <View style={styles.stepCard}>
        {!!step.title && <Text style={styles.stepTitle}>{step.title}</Text>}
        <Text style={styles.stepBody}>{bodyText || 'Bu step için içerik eklenmemiş.'}</Text>
      </View>
    </View>
  );
};

/* -------------------- Modal (Primary/Secondary standard) -------------------- */

type LessonCompleteModalProps = {
  visible: boolean;
  stats: LessonCompleteStats | null;
  onClose: () => void;
  onGoNextLesson: () => void;
};

const LessonCompleteModal: React.FC<LessonCompleteModalProps> = ({
  visible,
  stats,
  onClose,
  onGoNextLesson,
}) => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  if (!stats) return null;

  const { gainedXp, todayXP, dailyGoalXP, currentStreak, totalLessonsCompleted, alreadyCompleted } =
    stats;

  const progress = dailyGoalXP > 0 ? Math.min(1, todayXP / dailyGoalXP) : 0;

  const level = 1 + Math.floor(totalLessonsCompleted / 5);
  let badge = 'Yeni Başlayan';
  if (currentStreak >= 7) badge = 'Fire Streak';
  else if (currentStreak >= 3) badge = 'Seri Öğrenen';

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.modalOverlay}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>Ders Tamamlandı</Text>

          <Text style={styles.modalText}>
            {alreadyCompleted
              ? 'Bu dersi daha önce tamamlamıştın. Tekrar olarak sayıldı, XP eklenmedi.'
              : `Bu dersten ${gainedXp} XP kazandın.`}
          </Text>

          <Text style={styles.modalText}>
            Bugünkü toplamın:{' '}
            <Text style={styles.modalHighlight}>
              {todayXP} / {dailyGoalXP} XP
            </Text>
          </Text>

          <View style={styles.progressBarModalBg}>
            <View style={[styles.progressBarModalFill, { width: `${progress * 100}%` }]} />
          </View>

          <Text style={styles.modalText}>
            Seviye: <Text style={styles.modalHighlight}>Lv. {level}</Text>
          </Text>

          <Text style={styles.modalText}>
            Streak: <Text style={styles.modalHighlight}>{currentStreak} gün</Text> • Rozet:{' '}
            <Text style={styles.modalHighlight}>{badge}</Text>
          </Text>

          <Text style={[styles.modalText, { marginTop: 8 }]}>
            Tamamlanan ders sayısı:{' '}
            <Text style={styles.modalHighlight}>{totalLessonsCompleted}</Text>
          </Text>

          <View style={styles.modalButtons}>
            <PrimaryButton title="Sonraki Derse Geç" onPress={onGoNextLesson} style={{ flex: 1 }} />
            <SecondaryButton title="Kapat" onPress={onClose} style={{ flex: 1 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
};

/* -------------------- Styles -------------------- */

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.background },
    container: { flex: 1, backgroundColor: colors.background },

    headerCard: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 12,
    },
    headerTopRow: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 10,
    },
    lessonTitle: { flex: 1, fontSize: 20, fontWeight: '800', color: colors.textPrimary },
    lessonDesc: { fontSize: 13, color: colors.textSecondary, marginTop: 8, lineHeight: 18 },
    lessonMeta: { fontSize: 12, color: colors.textSecondary, marginTop: 10 },

    pill: {
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
    },
    pillText: { fontSize: 11, fontWeight: '800', color: colors.textSecondary },

    stepTopMeta: {
      marginTop: 6,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 8,
    },
    stepMetaText: { fontSize: 12, fontWeight: '700', color: colors.textSecondary },

    progressBarBg: {
      height: 8,
      borderRadius: 999,
      overflow: 'hidden',
      backgroundColor: colors.cardSoft,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: 12,
    },
    progressBarFill: { height: '100%', borderRadius: 999 },

    stepCard: {
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 14,
      borderWidth: 1,
      borderColor: colors.border,
    },
    stepTitle: { fontSize: 14, fontWeight: '900', color: colors.textPrimary, marginBottom: 6 },
    stepBody: { fontSize: 13, color: colors.textSecondary, lineHeight: 18 },

    // ✅ gerçek fixed bottom bar
    bottomBar: {
      position: 'absolute',
      left: 16,
      right: 16,
      bottom: Platform.OS === 'ios' ? 24 : 16,
      flexDirection: 'row',
      gap: 10,
      padding: 12,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.card,
    },

    // Modal
    modalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.6)',
      justifyContent: 'center',
      alignItems: 'center',
      padding: 24,
    },
    modalCard: {
      width: '100%',
      backgroundColor: colors.card,
      borderRadius: 20,
      padding: 20,
      borderWidth: 1,
      borderColor: colors.border,
    },
    modalTitle: {
      fontSize: 18,
      fontWeight: '900',
      color: colors.textPrimary,
      textAlign: 'center',
      marginBottom: 8,
    },
    modalText: { fontSize: 13, color: colors.textSecondary, marginTop: 6, textAlign: 'center' },
    modalHighlight: { color: colors.primary, fontWeight: '900' },

    progressBarModalBg: {
      height: 8,
      borderRadius: 999,
      overflow: 'hidden',
      backgroundColor: colors.cardSoft,
      marginTop: 14,
      marginBottom: 10,
      borderWidth: 1,
      borderColor: colors.border,
    },
    progressBarModalFill: { height: '100%', backgroundColor: colors.primary },

    modalButtons: { marginTop: 16, flexDirection: 'row', gap: 10 },
  });
