import React, { useMemo } from 'react';
import { TouchableOpacity, Text, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { useAppTheme, AppThemeColors } from '../../theme/theme';

type Props = {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
};

const PrimaryButton: React.FC<Props> = ({ title, onPress, disabled, style }) => {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createStyles(colors), [colors]);

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      onPress={onPress}
      disabled={disabled}
      style={[
        styles.btn,
        disabled && styles.btnDisabled,
        style,
      ]}
    >
      <Text style={styles.text}>{title}</Text>
    </TouchableOpacity>
  );
};

const createStyles = (colors: AppThemeColors) =>
  StyleSheet.create({
    btn: {
      alignSelf: 'flex-start',
      paddingHorizontal: 14,
      paddingVertical: 10,
      borderRadius: 999,
      backgroundColor: colors.primary,
      borderWidth: 1,
      borderColor: colors.border,
    },
    btnDisabled: {
      opacity: 0.6,
    },
    text: {
      color: '#fff',
      fontSize: 13,
      fontWeight: '800',
    },
  });

export default PrimaryButton;
