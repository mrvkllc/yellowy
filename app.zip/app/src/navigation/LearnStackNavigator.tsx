import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { LearnStackParamList } from './types';
import { useAppTheme } from '../theme/theme';
import CoursesScreen from '../screens/learn/CoursesScreen';
import LessonDetailScreen from '../screens/learn/LessonDetailScreen';


const Stack = createNativeStackNavigator<LearnStackParamList>();

const LearnStackNavigator = () => {
    const { colors } = useAppTheme();
  return (
    <Stack.Navigator
      id="LearnStack"
      screenOptions={{
        headerShown: true,
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.textPrimary,
        headerTitleStyle: { color: colors.textPrimary },
        headerShadowVisible: false,
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Screen
        name="Courses"
        component={CoursesScreen}
        options={{ title: 'Courses' }}
      />
      <Stack.Screen
        name="LessonDetail"
        component={LessonDetailScreen}
        options={{ title: 'Lesson' }}
      />
     
    
     
    </Stack.Navigator>
  );
};

export default LearnStackNavigator;
