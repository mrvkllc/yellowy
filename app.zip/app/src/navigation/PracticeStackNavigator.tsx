// src/navigation/PracticeStackNavigator.tsx
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { PracticeStackParamList } from './types';

import PracticeHomeScreen from '../screens/practice/PracticeHomeScreen';
import ReadingPracticeScreen from '../screens/practice/ReadingPracticeScreen';
import VocabPracticeScreen from '../screens/practice/VocabPracticeScreen';
import WritingPracticeScreen from '../screens/practice/WritingPracticeScreen';
import ListeningPracticeScreen from '../screens/practice/ListeningPracticeScreen';
import PracticeLeaderboardScreen from '../screens/practice/PracticeLeaderboardScreen';

const Stack = createNativeStackNavigator<PracticeStackParamList>();

const PracticeStackNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName="PracticeHome"
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name="PracticeHome" component={PracticeHomeScreen} />

      <Stack.Screen
        name="ReadingPractice"
        component={ReadingPracticeScreen}
        options={{ headerShown: true, title: 'Reading Practice' }}
      />

     <Stack.Screen
  name="WritingPractice"
  component={WritingPracticeScreen}
  options={{ title: 'Writing Practice' }}
/>


      <Stack.Screen
        name="ListeningPractice"
        component={ListeningPracticeScreen}
        options={{ headerShown: true, title: 'Listening Practice' }}
      />

      <Stack.Screen
        name="GrammarPractice"
        // şimdilik placeholder istiyorsan ayrı bir dosyada gerçek component yap, ama children ile de olur.
        // component vermek daha temiz.
        component={ReadingPracticeScreen as any}
        options={{ headerShown: true, title: 'Grammar Practice' }}
      />

      <Stack.Screen
        name="VocabPractice"
        component={VocabPracticeScreen}
        options={{ headerShown: true, title: 'Kelime Pratiği' }}
      />

      <Stack.Screen
        name="PracticeLeaderboard"
        component={PracticeLeaderboardScreen}
        options={{ headerShown: true, title: 'Practice leaderboard' }}
      />
    </Stack.Navigator>
  );
};

export default PracticeStackNavigator;
