import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthStackParamList } from './types';
import OnboardingScreen from '../screens/auth/OnboardingScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';
import SubscriptionScreen from '../screens/auth/SubscriptionScreen';
import LanguageSelectScreen from '../screens/auth/LanguageSelectScreen';
import TargetLanguageScreen from '../screens/auth/TargetLanguageScreen';
import PlacementIntroScreen from '../screens/auth/PlacementIntroScreen';
import PlacementQuestionScreen from '../screens/auth/PlacementQuestionScreen';
import PlacementResultScreen from '../screens/auth/PlacementResultScreen';
console.log('TargetLanguageScreen typeof =', typeof TargetLanguageScreen);

const Stack = createNativeStackNavigator<AuthStackParamList>();

const AuthNavigator = () => {
  return (
    <Stack.Navigator
      id="AuthStack"
      screenOptions={{ headerShown: false }}
    >
     <Stack.Screen name="Onboarding" component={OnboardingScreen} />
  <Stack.Screen name="LanguageSelect" component={LanguageSelectScreen} />
  <Stack.Screen name="TargetLanguage" component={TargetLanguageScreen} />
  <Stack.Screen name="PlacementIntro" component={PlacementIntroScreen} />
  <Stack.Screen name="PlacementQuestion" component={PlacementQuestionScreen} />
  <Stack.Screen name="PlacementResult" component={PlacementResultScreen} />

  <Stack.Screen name="Login" component={LoginScreen} />
  <Stack.Screen name="Register" component={RegisterScreen} />
  <Stack.Screen name="Subscription" component={SubscriptionScreen} />
     
    </Stack.Navigator>
  );
};


export default AuthNavigator;
