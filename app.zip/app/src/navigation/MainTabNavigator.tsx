import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import { MainTabParamList } from './types';
import PracticeHomeScreen from '../screens/practice/PracticeHomeScreen';
import DashboardScreen from '../screens/dashboard/DashboardScreen';
import LearnStackNavigator from './LearnStackNavigator';
import PracticeStackNavigator from './PracticeStackNavigator';
import GamesStackNavigator from './GamesStackNavigator';
import AIChatScreen from '../screens/chat/AIChatScreen';
import ProfileStackNavigator from './ProfileStackNavigator';

const Tab = createBottomTabNavigator<MainTabParamList>();

const MainTabNavigator = () => {
  return (
    <Tab.Navigator
    id="MainTabs"
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: true,
        tabBarStyle: {
          backgroundColor: '#050816',
          borderTopColor: '#111827',
        },
        tabBarActiveTintColor: '#faf500',
        tabBarInactiveTintColor: '#9ca3af',
        tabBarIcon: ({ color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap = 'home';

          if (route.name === 'Home') iconName = 'home';
          if (route.name === 'Learn') iconName = 'book';
          if (route.name === 'Practice') iconName = 'pencil';
          if (route.name === 'Games') iconName = 'game-controller';
          if (route.name === 'Chat') iconName = 'chatbubbles';
          if (route.name === 'Profile') iconName = 'person';

          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={DashboardScreen} />
      <Tab.Screen name="Learn" component={LearnStackNavigator} />
      <Tab.Screen name="Practice" component={PracticeStackNavigator} />
      <Tab.Screen name="Games" component={GamesStackNavigator} />
      <Tab.Screen name="Chat" component={AIChatScreen} />
      <Tab.Screen name="Profile" component={ProfileStackNavigator} />
    </Tab.Navigator>
  );
};

export default MainTabNavigator;
