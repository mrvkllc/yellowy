import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { GamesStackParamList } from './types';

import GamesHomeScreen from '../screens/games/GamesHomeScreen';
import { View, Text } from 'react-native';

const Stack = createNativeStackNavigator<GamesStackParamList>();

const Placeholder = ({ title }: { title: string }) => (
  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#050816' }}>
    <Text style={{ color: '#f9fafb' }}>{title} Screen</Text>
  </View>
);

const GamesStackNavigator = () => {
  return (
    <Stack.Navigator
      id="GamesStack"
      screenOptions={{
        headerStyle: { backgroundColor: '#050816' },
        headerTintColor: '#fafafa',
      }}
    >
      <Stack.Screen
        name="GamesHome"
        component={GamesHomeScreen}
        options={{ title: 'Games' }}
      />
      <Stack.Screen
        name="WordMatchGame"
        children={() => <Placeholder title="Word Match Game" />}
        options={{ title: 'Word Match' }}
      />
      <Stack.Screen
        name="SentenceBuilderGame"
        children={() => <Placeholder title="Sentence Builder Game" />}
        options={{ title: 'Sentence Builder' }}
      />
      <Stack.Screen
        name="ListeningGame"
        children={() => <Placeholder title="Listening Game" />}
        options={{ title: 'Listening Game' }}
      />
    </Stack.Navigator>
  );
};

export default GamesStackNavigator;
