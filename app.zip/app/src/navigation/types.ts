// src/navigation/types.ts

import type { NavigatorScreenParams } from '@react-navigation/native';


export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
};

export type AuthStackParamList = {
  Onboarding: undefined;
  LanguageSelect: undefined;
  TargetLanguage: { nativeLang: 'tr' | 'en' | 'es' };
  PlacementIntro: {
    nativeLang: 'tr' | 'en' | 'es';
    targetLang: 'tr' | 'en' | 'es';
  };
  PlacementQuestion: {
    nativeLang: 'tr' | 'en' | 'es';
    targetLang: 'tr' | 'en' | 'es';
    languagePair: 'tr-en' | 'en-tr' | 'tr-es' | 'es-tr' | 'en-es' | 'es-en';
  };
  PlacementResult: {
    nativeLang: 'tr' | 'en' | 'es';
    targetLang: 'tr' | 'en' | 'es';
    languagePair: 'tr-en' | 'en-tr' | 'tr-es' | 'es-tr' | 'en-es' | 'es-en';
    score: number;
    level: 'A1' | 'A2' | 'B1' | 'B2';
  };

  Login: undefined;
  Register: {
    nativeLang?: 'tr' | 'en' | 'es';
    targetLang?: 'tr' | 'en' | 'es';
    languagePair?: string;
    placementLevel?: 'A1' | 'A2' | 'B1' | 'B2';
    placementScore?: number;
  } | undefined;
  Subscription: undefined;
  // ... mevcut diğerleri
};


export type MainTabParamList = {
  Home: undefined;
  Learn: NavigatorScreenParams<LearnStackParamList>;
  Practice: NavigatorScreenParams<PracticeStackParamList>;
  Games: undefined;
  Chat: undefined;
  Profile: NavigatorScreenParams<ProfileStackParamList>;
   WritingPractice: undefined;
}

export type LearnStackParamList = {
  Courses: undefined;
  LessonDetail: { lessonId: string };
  Vocabulary: { lessonId?: string };
  Flashcards: { lessonId?: string };
  Quiz: { lessonId?: string };
};

export type PracticeStackParamList = {
  PracticeHome: undefined;
  ReadingPractice: undefined;
  WritingPractice:  { lessonId: string }  | undefined;
  ListeningPractice: undefined;
  GrammarPractice: undefined;
  VocabPractice: { lessonId: string }; 
   PracticeLeaderboard: undefined;       // 🔹 YENİ ROUTE
};

export type GamesStackParamList = {
  GamesHome: undefined;
  WordMatchGame: undefined;
  SentenceBuilderGame: undefined;
  ListeningGame: undefined;
};

export type ProfileStackParamList = {
  ProfileHome: undefined;
  Settings: undefined;
  LanguagePairs: undefined;
  Stats: undefined;
};

export type ListeningExercise = {
  id: string;
  languagePair: 'tr-es' | 'en-es' | 'tr-en';
  level: 'A1' | 'A2' | 'B1' | 'B2';
  order: number;
  title: string;
  audioUrl: string;
  prompt: string;
  options: string[];
  correctIndex: number;
  transcript: string;
  explanation?: string;
};
