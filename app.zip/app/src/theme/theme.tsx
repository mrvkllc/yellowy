import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { Appearance, ColorSchemeName, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type ThemeMode = 'light' | 'dark';

export type AppThemeColors = {
  // Brand
  primary: string;
  accent: string;
  primarySoft: string;
accentSoft: string;

  // Surfaces
  background: string;
  card: string;
  cardSoft: string;
  border: string;

  // Text
  textPrimary: string;
  textSecondary: string;

  // Misc
  success: string;
  warning: string;
  danger: string;
};

type ThemeContextValue = {
  mode: ThemeMode;
  colors: AppThemeColors;
  setMode: (m: ThemeMode) => void;
  toggleMode: () => void;
  hydrated: boolean; // storage okundu mu
};

const THEME_KEY = 'yw_theme_mode';

const lightColors: AppThemeColors = {
  primary: '#F7D54A',
  accent: '#FF6B6B',
  primarySoft: '#FFF4C2',
accentSoft: '#FFE4E4',


  background: '#F7F8FB',
  card: '#FFFFFF',
  cardSoft: '#F1F3F8',
  border: '#E3E7EF',

  textPrimary: '#121826',
  textSecondary: '#5B6475',

  success: '#22C55E',
  warning: '#F59E0B',
  danger: '#EF4444',
};

const darkColors = {
  background: '#0B0F1A',                 // laciverti bırak, daha kömür
  card: 'rgba(255,255,255,0.045)',       // CAM KART
  cardSoft: 'rgba(255,255,255,0.075)',   // CAM SOFT
  border: 'rgba(255,255,255,0.09)',      // yumuşak border

  textPrimary: '#F8FAFC',
  textSecondary: 'rgba(248,250,252,0.72)',

  // KRİTİK: White text istiyorsan primary sarıyı KOYULAŞTIR
  primary: '#C9B800',                    // parlak sarı değil, koyu sarı
  primarySoft: 'rgba(201,184,0,0.16)',   // varsa
  accent: '#7C3AED',
  accentSoft: 'rgba(124,58,237,0.16)',

  success: '#22C55E',
  warning: '#F59E0B',
  danger: '#EF4444',
};

const ThemeContext = createContext<ThemeContextValue>({
  mode: 'dark',
  colors: darkColors,
  setMode: () => {},
  toggleMode: () => {},
  hydrated: false,
});

const getSystemMode = (): ThemeMode => {
  const scheme: ColorSchemeName = Appearance.getColorScheme();
  return scheme === 'light' ? 'light' : 'dark';
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setModeState] = useState<ThemeMode>('dark');
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const init = async () => {
      try {
        const saved = await AsyncStorage.getItem(THEME_KEY);
        if (saved === 'light' || saved === 'dark') {
          setModeState(saved);
        } else {
          setModeState(getSystemMode());
        }
      } finally {
        setHydrated(true);
      }
    };
    init();

    // Sistem teması değişirse: sadece kullanıcı kaydı yoksa takip et
    const sub = Appearance.addChangeListener(async () => {
      const saved = await AsyncStorage.getItem(THEME_KEY);
      if (!saved) setModeState(getSystemMode());
    });

    return () => sub.remove();
  }, []);

  const setMode = async (m: ThemeMode) => {
    setModeState(m);
    await AsyncStorage.setItem(THEME_KEY, m);
  };

  const toggleMode = async () => {
    const next: ThemeMode = mode === 'dark' ? 'light' : 'dark';
    await setMode(next);
  };

  const colors = useMemo(() => (mode === 'dark' ? darkColors : lightColors), [mode]);

  const value = useMemo(
    () => ({ mode, colors, setMode, toggleMode, hydrated }),
    [mode, colors, hydrated]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useAppTheme = () => useContext(ThemeContext);
