// importVocab.js
const fs = require('fs');
const path = require('path');
const admin = require('firebase-admin');

// 1) Firebase Admin init
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

// 2) Basit CSV parser (virgül içermeyen alanlar için yeterli)
function parseCsv(text) {
  const lines = text.trim().split('\n').filter(l => l.trim().length > 0);
  const headers = lines[0].split(',').map(h => h.trim());

  return lines.slice(1).map(line => {
    const cols = line.split(',').map(c => c.trim());
    const row = {};
    headers.forEach((h, i) => {
      row[h] = cols[i] ?? '';
    });
    return row;
  });
}

async function importVocab(csvPath) {
  const fullPath = path.resolve(csvPath);
  console.log('CSV okunuyor:', fullPath);

  const fileText = fs.readFileSync(fullPath, 'utf8');
  const rows = parseCsv(fileText);

  console.log(`Toplam satır: ${rows.length}`);

  const batch = db.batch();
  const vocabCol = db.collection('vocab');

  rows.forEach((row, idx) => {
    const docRef = vocabCol.doc(); // otomatik id

    const orderNumber = Number(row.order) || 0;

    const payload = {
      lessonId: row.lessonId,
      order: orderNumber,
      es: row.es || '',
      tr: row.tr || '',
      en: row.en || '',
      exampleEs: row.exampleEs || '',
      exampleTr: row.exampleTr || '',
      exampleEn: row.exampleEn || '',
    };

    console.log(`#${idx + 1}`, payload);
    batch.set(docRef, payload);
  });

  await batch.commit();
  console.log('✅ Import tamamlandı!');
}

// CLI giriş noktası
const csvFile = process.argv[2];

if (!csvFile) {
  console.error('Kullanım: node importVocab.js vocab.csv');
  process.exit(1);
}

importVocab(csvFile)
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('Import sırasında hata:', err);
    process.exit(1);
  });
