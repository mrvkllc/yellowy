// App.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';

import AppNavigator from './src/navigation/AppNavigator';
import { ThemeProvider, useAppTheme } from './src/theme/theme';
import { AuthProvider } from './src/context/AuthContext';

// Bu component sadece NavigationContainer + theme işini yapıyor
const AppInner: React.FC = () => {
  const { navTheme } = useAppTheme();

  return (
    <NavigationContainer theme={navTheme}>
      <AppNavigator />
    </NavigationContainer>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <AppInner />
      </ThemeProvider>
    </AuthProvider>
  );
}
