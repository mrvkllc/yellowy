
// src/types/lesson.ts
export type LessonStepType =
  | 'info'
  | 'vocab'
  | 'mcq'
  | 'trueFalse'
  | 'imageMcq';

export type LessonStepBase = {
  id: string;
  type: LessonStepType;
  order: number;
};

export type InfoStep = LessonStepBase & {
  type: 'info';
  title: string;
  text: string;
};

export type VocabItem = {
  term: string;
  translationTr: string;
  translationEn: string;
  exampleEs?: string;
  exampleTr?: string;
};

export type VocabStep = LessonStepBase & {
  type: 'vocab';
  title: string;
  items: VocabItem[];
};

export type McqOption = {
  id: string; // A, B, C...
  text: string;
};

export type McqStep = LessonStepBase & {
  type: 'mcq';
  question: string;
  options: McqOption[];
  correctOptionId: string;
  explanation?: string;
};

export type TrueFalseStep = LessonStepBase & {
  type: 'trueFalse';
  statement: string;
  correct: boolean;
  explanation?: string;
};

export type ImageMcqStep = LessonStepBase & {
  type: 'imageMcq';
  question: string;
  imageUrl: string;
  options: McqOption[];
  correctOptionId: string;
};

export type LessonStep =
  | InfoStep
  | VocabStep
  | McqStep
  | TrueFalseStep
  | ImageMcqStep;

export type Lesson = {
  lessonId: string;
  courseId: string;
  level: string;
  order: number;
  title: string;
  description: string;
  xp: number;
  estimatedMinutes: number;
  minCorrectToPass: number;
  steps: LessonStep[];
};
