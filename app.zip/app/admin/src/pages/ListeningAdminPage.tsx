// admin/src/pages/ListeningAdminPage.tsx
import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { db } from '../firebase';

type ListeningExercise = {
  id?: string;
  languagePair: 'tr-es' | 'en-es' | 'tr-en';
  level: 'A1' | 'A2' | 'B1' | 'B2';
  order: number;
  title: string;
  audioUrl: string;
  prompt: string;
  options: string[];
  correctIndex: number;
  transcript: string;
  explanation?: string;
};

const LANGUAGE_PAIRS: ListeningExercise['languagePair'][] = [
  'tr-es',
  'en-es',
  'tr-en',
];

const LEVELS: ListeningExercise['level'][] = ['A1', 'A2', 'B1', 'B2'];

const emptyExercise: ListeningExercise = {
  languagePair: 'tr-es',
  level: 'A1',
  order: 1,
  title: '',
  audioUrl: '',
  prompt: '',
  options: [],
  correctIndex: 0,
  transcript: '',
  explanation: '',
};

const ListeningAdminPage: React.FC = () => {
  const [languagePairFilter, setLanguagePairFilter] =
    useState<ListeningExercise['languagePair']>('tr-es');
  const [levelFilter, setLevelFilter] =
    useState<ListeningExercise['level']>('A1');

  const [exercises, setExercises] = useState<ListeningExercise[]>([]);
  const [loading, setLoading] = useState(false);

  const [editing, setEditing] = useState<ListeningExercise | null>(null);
  const [optionsText, setOptionsText] = useState(''); // textarea için

  const isEditingExisting = useMemo(
    () => !!editing && !!editing.id,
    [editing]
  );

  // Listeyi yükle
  const loadExercises = async () => {
    setLoading(true);
    try {
      const baseRef = collection(db, 'listening_exercises');

      const q = query(
        baseRef,
        where('languagePair', '==', languagePairFilter),
        where('level', '==', levelFilter),
        orderBy('order', 'asc')
      );

      const snap = await getDocs(q);
      const list: ListeningExercise[] = snap.docs.map((d) => {
        const data = d.data() as any;
        return {
          id: d.id,
          languagePair: data.languagePair,
          level: data.level,
          order: data.order,
          title: data.title,
          audioUrl: data.audioUrl,
          prompt: data.prompt,
          options: data.options ?? [],
          correctIndex: data.correctIndex ?? 0,
          transcript: data.transcript ?? '',
          explanation: data.explanation ?? '',
        };
      });

      setExercises(list);
    } catch (e) {
      console.error('ListeningAdmin load error', e);
      alert('Error loading listening exercises');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExercises();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [languagePairFilter, levelFilter]);

  const handleNew = () => {
    const nextOrder =
      exercises.length > 0
        ? (exercises[exercises.length - 1].order ?? exercises.length) + 1
        : 1;

    const initial: ListeningExercise = {
      ...emptyExercise,
      languagePair: languagePairFilter,
      level: levelFilter,
      order: nextOrder,
    };

    setEditing(initial);
    setOptionsText('');
  };

  const handleEdit = (ex: ListeningExercise) => {
    setEditing(ex);
    setOptionsText(ex.options.join('\n'));
  };

  const handleDelete = async (ex: ListeningExercise) => {
    if (!ex.id) return;
    const ok = window.confirm(
      `Delete listening exercise "${ex.title}"?`
    );
    if (!ok) return;

    try {
      await deleteDoc(doc(db, 'listening_exercises', ex.id));
      await loadExercises();
    } catch (e) {
      console.error('ListeningAdmin delete error', e);
      alert('Error deleting exercise');
    }
  };

  const handleSave = async () => {
    if (!editing) return;

    // options textarea -> array
    const options = optionsText
      .split('\n')
      .map((o) => o.trim())
      .filter((o) => o.length > 0);

    if (!editing.title.trim()) {
      alert('Title is required');
      return;
    }
    if (!editing.audioUrl.trim()) {
      alert('Audio URL is required');
      return;
    }
    if (options.length < 2) {
      alert('At least 2 options required');
      return;
    }
    if (
      editing.correctIndex < 0 ||
      editing.correctIndex >= options.length
    ) {
      alert('Correct index must be between 0 and ' + (options.length - 1));
      return;
    }

    const payload = {
      languagePair: editing.languagePair,
      level: editing.level,
      order: editing.order,
      title: editing.title.trim(),
      audioUrl: editing.audioUrl.trim(),
      prompt: editing.prompt.trim(),
      options,
      correctIndex: editing.correctIndex,
      transcript: editing.transcript.trim(),
      explanation: editing.explanation?.trim() || '',
    };

    try {
      if (editing.id) {
        // update
        await updateDoc(
          doc(db, 'listening_exercises', editing.id),
          payload
        );
      } else {
        // create
        await addDoc(collection(db, 'listening_exercises'), payload);
      }

      setEditing(null);
      setOptionsText('');
      await loadExercises();
    } catch (e) {
      console.error('ListeningAdmin save error', e);
      alert('Error saving exercise');
    }
  };

  const handleCancel = () => {
    setEditing(null);
    setOptionsText('');
  };

  return (
    <div style={styles.page}>
      <h1 style={styles.pageTitle}>Listening exercises</h1>

      {/* FILTER BAR */}
      <div style={styles.filterRow}>
        <div style={styles.filterGroup}>
          <label style={styles.label}>Language pair</label>
          <select
            value={languagePairFilter}
            onChange={(e) =>
              setLanguagePairFilter(e.target.value as ListeningExercise['languagePair'])
            }
            style={styles.select}
          >
            {LANGUAGE_PAIRS.map((lp) => (
              <option key={lp} value={lp}>
                {lp.toUpperCase()}
              </option>
            ))}
          </select>
        </div>

        <div style={styles.filterGroup}>
          <label style={styles.label}>Level</label>
          <select
            value={levelFilter}
            onChange={(e) =>
              setLevelFilter(e.target.value as ListeningExercise['level'])
            }
            style={styles.select}
          >
            {LEVELS.map((lv) => (
              <option key={lv} value={lv}>
                {lv}
              </option>
            ))}
          </select>
        </div>

        <button style={styles.newButton} onClick={handleNew}>
          + New exercise
        </button>
      </div>

      {/* LIST */}
      <div style={styles.listBox}>
        {loading ? (
          <div style={styles.center}>
            <span>Loading…</span>
          </div>
        ) : exercises.length === 0 ? (
          <div style={styles.center}>
            <span>No exercises for this filter.</span>
          </div>
        ) : (
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Order</th>
                <th style={styles.th}>Title</th>
                <th style={styles.th}>Prompt</th>
                <th style={styles.th}>Options</th>
                <th style={styles.th}>Correct</th>
                <th style={styles.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {exercises.map((ex) => (
                <tr key={ex.id}>
                  <td style={styles.td}>{ex.order}</td>
                  <td style={styles.td}>{ex.title}</td>
                  <td style={styles.td}>{ex.prompt}</td>
                  <td style={styles.td}>
                    {ex.options.slice(0, 3).join(' | ')}
                    {ex.options.length > 3 && '…'}
                  </td>
                  <td style={styles.td}>{ex.correctIndex}</td>
                  <td style={styles.td}>
                    <button
                      style={styles.smallButton}
                      onClick={() => handleEdit(ex)}
                    >
                      Edit
                    </button>
                    <button
                      style={styles.smallDangerButton}
                      onClick={() => handleDelete(ex)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* EDIT / CREATE FORM */}
      {editing && (
        <div style={styles.formWrapper}>
          <h2 style={styles.formTitle}>
            {isEditingExisting ? 'Edit exercise' : 'New exercise'}
          </h2>

          <div style={styles.formGrid}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Language pair</label>
              <select
                value={editing.languagePair}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev
                      ? {
                          ...prev,
                          languagePair: e.target
                            .value as ListeningExercise['languagePair'],
                        }
                      : prev
                  )
                }
                style={styles.select}
              >
                {LANGUAGE_PAIRS.map((lp) => (
                  <option key={lp} value={lp}>
                    {lp.toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Level</label>
              <select
                value={editing.level}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev
                      ? {
                          ...prev,
                          level: e.target.value as ListeningExercise['level'],
                        }
                      : prev
                  )
                }
                style={styles.select}
              >
                {LEVELS.map((lv) => (
                  <option key={lv} value={lv}>
                    {lv}
                  </option>
                ))}
              </select>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Order</label>
              <input
                type="number"
                value={editing.order}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev
                      ? { ...prev, order: Number(e.target.value) || 0 }
                      : prev
                  )
                }
                style={styles.input}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Title</label>
              <input
                type="text"
                value={editing.title}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, title: e.target.value } : prev
                  )
                }
                style={styles.input}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Audio URL</label>
              <input
                type="text"
                value={editing.audioUrl}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, audioUrl: e.target.value } : prev
                  )
                }
                style={styles.input}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Prompt</label>
              <input
                type="text"
                value={editing.prompt}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, prompt: e.target.value } : prev
                  )
                }
                style={styles.input}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>
                Options (one per line, index 0..N)
              </label>
              <textarea
                value={optionsText}
                onChange={(e) => setOptionsText(e.target.value)}
                rows={5}
                style={styles.textarea}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Correct index</label>
              <input
                type="number"
                value={editing.correctIndex}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev
                      ? {
                          ...prev,
                          correctIndex: Number(e.target.value) || 0,
                        }
                      : prev
                  )
                }
                style={styles.input}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Transcript</label>
              <textarea
                value={editing.transcript}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, transcript: e.target.value } : prev
                  )
                }
                rows={3}
                style={styles.textarea}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Explanation (optional)</label>
              <textarea
                value={editing.explanation ?? ''}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, explanation: e.target.value } : prev
                  )
                }
                rows={3}
                style={styles.textarea}
              />
            </div>
          </div>

          <div style={styles.formActions}>
            <button style={styles.saveButton} onClick={handleSave}>
              {isEditingExisting ? 'Save changes' : 'Create exercise'}
            </button>
            <button style={styles.cancelButton} onClick={handleCancel}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Basit inline “design system”
const styles: { [key: string]: React.CSSProperties } = {
  page: {
    padding: 24,
    maxWidth: 1100,
    margin: '0 auto',
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 700,
    marginBottom: 16,
  },
  filterRow: {
    display: 'flex',
    alignItems: 'flex-end',
    gap: 12,
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  filterGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
    minWidth: 160,
  },
  label: {
    fontSize: 12,
    fontWeight: 600,
  },
  select: {
    padding: '6px 8px',
    borderRadius: 8,
    border: '1px solid #d1d5db',
    fontSize: 13,
  },
  newButton: {
    padding: '8px 14px',
    borderRadius: 999,
    border: 'none',
    backgroundColor: '#004aad',
    color: '#ffffff',
    fontSize: 13,
    fontWeight: 600,
    cursor: 'pointer',
  },
  listBox: {
    borderRadius: 12,
    border: '1px solid #e5e7eb',
    overflow: 'hidden',
    backgroundColor: '#ffffff',
  },
  center: {
    padding: 24,
    textAlign: 'center',
    fontSize: 13,
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: 13,
  },
  th: {
    textAlign: 'left',
    padding: '8px 10px',
    borderBottom: '1px solid #e5e7eb',
    backgroundColor: '#f9fafb',
    fontWeight: 600,
    fontSize: 12,
  },
  td: {
    padding: '8px 10px',
    borderBottom: '1px solid #f3f4f6',
    verticalAlign: 'top',
  },
  smallButton: {
    padding: '4px 8px',
    borderRadius: 999,
    border: '1px solid #d1d5db',
    backgroundColor: '#ffffff',
    fontSize: 11,
    cursor: 'pointer',
    marginRight: 6,
  },
  smallDangerButton: {
    padding: '4px 8px',
    borderRadius: 999,
    border: '1px solid #fecaca',
    backgroundColor: '#fee2e2',
    color: '#991b1b',
    fontSize: 11,
    cursor: 'pointer',
  },
  formWrapper: {
    marginTop: 20,
    padding: 16,
    borderRadius: 12,
    border: '1px solid #e5e7eb',
    backgroundColor: '#f9fafb',
  },
  formTitle: {
    fontSize: 18,
    fontWeight: 600,
    marginBottom: 12,
  },
  formGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
    gap: 12,
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
  },
  formGroupFull: {
    gridColumn: '1 / -1',
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
  },
  input: {
    padding: '6px 8px',
    borderRadius: 8,
    border: '1px solid #d1d5db',
    fontSize: 13,
  },
  textarea: {
    padding: '6px 8px',
    borderRadius: 8,
    border: '1px solid #d1d5db',
    fontSize: 13,
    resize: 'vertical',
  },
  formActions: {
    marginTop: 16,
    display: 'flex',
    gap: 8,
  },
  saveButton: {
    padding: '8px 16px',
    borderRadius: 999,
    border: 'none',
    backgroundColor: '#004aad',
    color: '#ffffff',
    fontSize: 13,
    fontWeight: 600,
    cursor: 'pointer',
  },
  cancelButton: {
    padding: '8px 16px',
    borderRadius: 999,
    border: '1px solid #d1d5db',
    backgroundColor: '#ffffff',
    fontSize: 13,
    cursor: 'pointer',
  },
};

export default ListeningAdminPage;
