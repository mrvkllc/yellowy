// src/pages/CsvImportPage.tsx
import React, { useState } from 'react';
import Papa from 'papaparse';
import { collection, doc, writeBatch } from 'firebase/firestore';
import { db } from '../firebase';
import type { Lesson, LessonStep, VocabItem, McqOption } from '../types/lesson';

type CsvRow = Record<string, string>;

const CsvImportPage: React.FC = () => {
  const [lessonsFile, setLessonsFile] = useState<File | null>(null);
  const [stepsFile, setStepsFile] = useState<File | null>(null);
  const [status, setStatus] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);

  const handleLessonsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLessonsFile(e.target.files?.[0] ?? null);
  };

  const handleStepsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setStepsFile(e.target.files?.[0] ?? null);
  };

  const parseCsv = (file: File): Promise<CsvRow[]> => {
    return new Promise((resolve, reject) => {
      Papa.parse<CsvRow>(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          if (results.errors.length) {
            reject(results.errors[0]);
          } else {
            resolve(results.data);
          }
        },
        error: (err) => reject(err),
      });
    });
  };

  const handleUpload = async () => {
    if (!lessonsFile || !stepsFile) {
      setStatus('Lütfen hem Lessons.csv hem de LessonSteps.csv dosyalarını seçin.');
      return;
    }

    setIsUploading(true);
    setStatus('CSV dosyaları okunuyor...');

    try {
      const [lessonsRows, stepsRows] = await Promise.all([
        parseCsv(lessonsFile),
        parseCsv(stepsFile),
      ]);

      // 1) Ders header bilgilerini map'le
      const lessonMap = new Map<string, Lesson>();

      for (const row of lessonsRows) {
        const lessonId = (row.lessonId || '').trim();
        if (!lessonId) continue;

        const lesson: Lesson = {
          lessonId,
          courseId: (row.courseId || '').trim(),
          level: (row.level || '').trim(),
          order: Number(row.order || 0),
          title: (row.title || '').trim(),
          description: (row.description || '').trim(),
          xp: Number(row.xp || 0),
          estimatedMinutes: Number(row.estimatedMinutes || 0),
          minCorrectToPass: Number(row.minCorrectToPass || 0),
          steps: [],
        };

        lessonMap.set(lessonId, lesson);
      }

      // 2) Step satırlarını derslere dağıt
      for (const row of stepsRows) {
        const lessonId = (row.lessonId || '').trim();
        if (!lessonId) continue;

        const lesson = lessonMap.get(lessonId);
        if (!lesson) continue; // header yoksa atla

        const type = (row.type || '').trim() as any;
        const order = Number(row.order || 0);
        const id = (row.stepId || '').trim() || `step-${order || lesson.steps.length + 1}`;

        let step: LessonStep | null = null;

        if (type === 'info') {
          step = {
            id,
            type: 'info',
            order,
            title: (row.title || '').trim(),
            text: (row.text || '').trim(),
          };
        } else if (type === 'vocab') {
          let items: VocabItem[] = [];
          const json = row.vocabJson;
          if (json) {
            try {
              const parsed = JSON.parse(json) as any[];
              items = parsed.map((it) => ({
                term: it.term ?? '',
                translationTr: it.tr ?? it.translationTr ?? '',
                translationEn: it.en ?? it.translationEn ?? '',
                exampleEs: it.exampleEs ?? '',
                exampleTr: it.exampleTr ?? '',
              }));
            } catch (e) {
              console.warn('vocabJson parse error', e);
            }
          }

          step = {
            id,
            type: 'vocab',
            order,
            title: (row.title || '').trim() || 'Kelime listesi',
            items,
          };
        } else if (type === 'mcq' || type === 'imageMcq') {
          let options: McqOption[] = [];
          const json = row.optionsJson;
          if (json) {
            try {
              const parsed = JSON.parse(json) as string[];
              options = parsed.map((text, idx) => ({
                id: String.fromCharCode(65 + idx), // A,B,C...
                text,
              }));
            } catch (e) {
              console.warn('optionsJson parse error', e);
            }
          }

          const base = {
            id,
            order,
            question: (row.question || '').trim(),
            options,
            correctOptionId: (row.correctOptionId || '').trim(),
          };

          if (type === 'mcq') {
            step = {
              ...base,
              type: 'mcq',
            };
          } else {
            step = {
              ...base,
              type: 'imageMcq',
              imageUrl: (row.imageUrl || '').trim(),
            };
          }
        } else if (type === 'trueFalse') {
          const correctStr = (row.correct || '').trim().toLowerCase();
          const correct =
            correctStr === 'true' ||
            correctStr === '1' ||
            correctStr === 'evet';

          step = {
            id,
            type: 'trueFalse',
            order,
            statement: (row.statement || '').trim(),
            correct,
          };
        }

        if (step) {
          lesson.steps.push(step);
        }
      }

      // 3) Firestore'a yaz
      if (!lessonMap.size) {
        setStatus('Hiç ders bulunamadı. CSV içeriğini kontrol edin.');
        setIsUploading(false);
        return;
      }

      setStatus('Firestore\'a yazılıyor...');

      const batch = writeBatch(db);
      const lessonsCol = collection(db, 'lessons');

      for (const lesson of lessonMap.values()) {
        // step'leri order'a göre sırala
        lesson.steps.sort((a, b) => a.order - b.order);
        const ref = doc(lessonsCol, lesson.lessonId);
        batch.set(ref, lesson, { merge: true });
      }

      await batch.commit();

      setStatus(`✅ Toplam ${lessonMap.size} ders Firestore'a yüklendi.`);
    } catch (err: any) {
      console.error(err);
      setStatus('❌ Yükleme sırasında bir hata oluştu. Konsolu kontrol edin.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div
      style={{
        backgroundColor: '#ffffff',
        borderRadius: 12,
        padding: 24,
        boxShadow: '0 10px 30px rgba(15,23,42,0.08)',
        border: '1px solid #e5e7eb',
      }}
    >
      <h1 style={{ fontSize: 24, marginBottom: 8 }}>CSV ile Ders Yükleme</h1>
      <p style={{ color: '#4b5563', fontSize: 14, marginBottom: 16 }}>
        Bu sayfadan <strong>Lessons.csv</strong> ve <strong>LessonSteps.csv</strong> dosyalarınızı
        yükleyerek dersleri Firestore&apos;daki <code>lessons</code> koleksiyonuna
        otomatik olarak ekleyebilirsiniz.
      </p>

      <div style={{ marginBottom: 16 }}>
        <label style={{ display: 'block', fontWeight: 600, marginBottom: 6 }}>
          Lessons.csv (ders başlıkları)
        </label>
        <input type="file" accept=".csv" onChange={handleLessonsChange} />
        <p style={{ fontSize: 12, color: '#6b7280', marginTop: 4 }}>
          Kolonlar: lessonId, courseId, level, order, title, description, xp, estimatedMinutes,
          minCorrectToPass
        </p>
      </div>

      <div style={{ marginBottom: 16 }}>
        <label style={{ display: 'block', fontWeight: 600, marginBottom: 6 }}>
          LessonSteps.csv (ders adımları)
        </label>
        <input type="file" accept=".csv" onChange={handleStepsChange} />
        <p style={{ fontSize: 12, color: '#6b7280', marginTop: 4 }}>
          Kolonlar: lessonId, stepId, order, type, title, text, question, statement, correct,
          optionsJson, correctOptionId, imageUrl, vocabJson
        </p>
      </div>

      <button
        onClick={handleUpload}
        disabled={isUploading}
        style={{
          padding: '10px 18px',
          borderRadius: 999,
          border: 'none',
          backgroundColor: isUploading ? '#9ca3af' : '#004aad',
          color: '#ffffff',
          fontWeight: 600,
          fontSize: 14,
          cursor: isUploading ? 'default' : 'pointer',
        }}
      >
        {isUploading ? 'Yükleniyor...' : 'CSV\'leri Firestore\'a Yükle'}
      </button>

      {status && (
        <p style={{ marginTop: 16, fontSize: 14, color: '#111827' }}>{status}</p>
      )}

      <div
        style={{
          marginTop: 24,
          paddingTop: 16,
          borderTop: '1px solid #e5e7eb',
          fontSize: 12,
          color: '#6b7280',
          lineHeight: 1.5,
        }}
      >
        <p style={{ margin: 0 }}>
          <strong>Not:</strong> Aynı <code>lessonId</code> ile daha önce ders varsa{' '}
          <strong>üzerine yazar</strong> (merge kullanıyoruz). Bu sayfayı önce 1–2 test dersi ile
          denemen iyi olur.
        </p>
      </div>
    </div>
  );
};

export default CsvImportPage;
