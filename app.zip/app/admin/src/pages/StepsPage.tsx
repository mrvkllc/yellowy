// src/pages/StepsPage.tsx
import React, { useEffect, useState } from "react";
import { collection, doc, getDocs, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";

type Lesson = {
  id: string;
  title: string;
};

type Step = {
  id: string;
  order: number;
  type: string;
  title?: string;
};

export const StepsPage: React.FC = () => {
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [selectedLessonId, setSelectedLessonId] = useState<string>("");
  const [steps, setSteps] = useState<Step[]>([]);
  const [loadingLessons, setLoadingLessons] = useState(true);
  const [loadingSteps, setLoadingSteps] = useState(false);

  // 1) Lessons listesini çek
  useEffect(() => {
    const fetchLessons = async () => {
      setLoadingLessons(true);
      try {
        const snap = await getDocs(collection(db, "lessons"));
        const list: Lesson[] = [];
        snap.forEach((d) => {
          const data = d.data() as any;
          list.push({
            id: d.id,
            title: data.title ?? d.id,
          });
        });
        list.sort((a, b) => a.title.localeCompare(b.title));
        setLessons(list);
        if (!selectedLessonId && list.length > 0) {
          setSelectedLessonId(list[0].id);
        }
      } finally {
        setLoadingLessons(false);
      }
    };

    fetchLessons();
  }, []);

  // 2) Seçili lesson dokümanındaki `steps` array'ini dinle
  useEffect(() => {
    if (!selectedLessonId) {
      setSteps([]);
      return;
    }

    setLoadingSteps(true);

    const lessonRef = doc(db, "lessons", selectedLessonId);

    const unsub = onSnapshot(
      lessonRef,
      (snap) => {
        const data = snap.data() as any;
        const rawSteps = (data?.steps ?? []) as any[];

        const list: Step[] = rawSteps
          .map((s, idx) => ({
            id: s.id ?? `step-${idx + 1}`,
            order: s.order ?? idx + 1,
            type: s.type ?? "",
            title: s.title ?? s.question ?? "",
          }))
          .sort((a, b) => a.order - b.order);

        setSteps(list);
        setLoadingSteps(false);
      },
      (err) => {
        console.error("Step listener error", err);
        setSteps([]);
        setLoadingSteps(false);
      }
    );

    return () => unsub();
  }, [selectedLessonId]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold">Lesson Steps</h1>
          <p className="text-sm text-slate-400">
            Step akışlarını seçtiğin ders için görüntüleyebilirsin.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            className="rounded-full border border-slate-700 bg-slate-900/70 px-3 py-2 text-sm text-slate-100"
            value={selectedLessonId}
            onChange={(e) => setSelectedLessonId(e.target.value)}
            disabled={loadingLessons}
          >
            {lessons.map((l) => (
              <option key={l.id} value={l.id}>
                {l.id} — {l.title}
              </option>
            ))}
          </select>

          {/* Şimdilik sadece görüntüleme; edit kısmını sonra yaparız */}
          <button
            type="button"
            className="rounded-full bg-slate-800 hover:bg-slate-700 px-4 py-2 text-xs font-medium text-slate-100"
            disabled
          >
            + Yeni Step
          </button>
        </div>
      </div>

      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow">
        <div className="mb-3 text-sm font-medium text-slate-200">
          Step Listesi
        </div>

        {loadingSteps ? (
          <div className="text-sm text-slate-400">Stepler yükleniyor…</div>
        ) : steps.length === 0 ? (
          <div className="text-sm text-slate-400">
            Bu ders için henüz step bulunmuyor.
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-xs uppercase text-slate-400 border-b border-slate-800">
              <tr>
                <th className="text-left py-2">Order</th>
                <th className="text-left py-2">Step ID</th>
                <th className="text-left py-2">Type</th>
                <th className="text-left py-2">Başlık / Soru</th>
              </tr>
            </thead>
            <tbody>
              {steps.map((s) => (
                <tr
                  key={s.id}
                  className="border-b border-slate-800/60 last:border-0"
                >
                  <td className="py-2 pr-2">{s.order}</td>
                  <td className="py-2 pr-2 text-slate-300">{s.id}</td>
                  <td className="py-2 pr-2 text-slate-300">{s.type}</td>
                  <td className="py-2 pr-2 text-slate-100">{s.title}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
