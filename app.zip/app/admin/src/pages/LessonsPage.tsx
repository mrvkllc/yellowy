import { useEffect, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  orderBy,
  query,
  setDoc,
} from "firebase/firestore";
import { db } from "../firebase";

type Lesson = {
  lessonId: string;
  courseId: string;
  level: string;
  order: number;
  title: string;
  description?: string;
  xp?: number;
  estimatedMinutes?: number;
  minCorrectToPass?: number;
};

export function LessonsPage() {
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState<Partial<Lesson>>({
    lessonId: "",
    courseId: "SPANISH-A1",
    level: "A1",
    order: 1,
    title: "",
    description: "",
    xp: 20,
    estimatedMinutes: 8,
    minCorrectToPass: 3,
  });

  useEffect(() => {
    loadLessons();
  }, []);

  async function loadLessons() {
    setLoading(true);
    const q = query(collection(db, "lessons"), orderBy("order", "asc"));
    const snap = await getDocs(q);
    const data: Lesson[] = snap.docs.map((d) => d.data() as Lesson);
    setLessons(data);
    setLoading(false);
  }

  function handleEditClick(l: Lesson) {
    setForm(l);
  }

  function handleNewLesson() {
    setForm({
      lessonId: "",
      courseId: "SPANISH-A1",
      level: "A1",
      order: lessons.length + 1,
      title: "",
      description: "",
      xp: 20,
      estimatedMinutes: 8,
      minCorrectToPass: 3,
    });
  }

  async function handleSave() {
    if (!form.lessonId || !form.title) {
      alert("lessonId ve title zorunlu");
      return;
    }

    setSaving(true);

    const payload: Lesson = {
      lessonId: form.lessonId,
      courseId: form.courseId || "SPANISH-A1",
      level: form.level || "A1",
      order: Number(form.order) || 1,
      title: form.title,
      description: form.description || "",
      xp: Number(form.xp) || 0,
      estimatedMinutes: Number(form.estimatedMinutes) || 0,
      minCorrectToPass: Number(form.minCorrectToPass) || 0,
    };

    const ref = doc(db, "lessons", payload.lessonId);
    await setDoc(ref, payload, { merge: true });

    setSaving(false);
    await loadLessons();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">A1 Lessons</h2>
          <p className="text-xs text-slate-400">
            Buradan ders başlıklarını, sırasını, XP ve geçme kriterlerini yönetebilirsin.
          </p>
        </div>
        <button
          onClick={handleNewLesson}
          className="inline-flex items-center justify-center rounded-full px-4 py-2 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 transition"
        >
          + Yeni Ders
        </button>
      </div>

      <div className="grid lg:grid-cols-[2fr,1fr] gap-4">
        {/* Ders listesi */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl shadow-sm overflow-hidden">
          <div className="border-b border-slate-800 px-4 py-3 flex items-center justify-between">
            <span className="text-sm font-medium text-slate-100">
              Ders Listesi
            </span>
            {loading && (
              <span className="text-[10px] text-slate-400">Yükleniyor…</span>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-900/80 text-xs uppercase text-slate-400">
                <tr>
                  <th className="px-3 py-2 text-left">Order</th>
                  <th className="px-3 py-2 text-left">LessonId</th>
                  <th className="px-3 py-2 text-left">Başlık</th>
                  <th className="px-3 py-2 text-left">XP</th>
                  <th className="px-3 py-2 text-left">Min Correct</th>
                  <th className="px-3 py-2 text-right">İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {lessons.length === 0 && !loading && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-4 text-center text-xs text-slate-500"
                    >
                      Henüz ders yok. Sağ üstten yeni ders ekleyebilirsin.
                    </td>
                  </tr>
                )}

                {lessons.map((l) => (
                  <tr
                    key={l.lessonId}
                    className="border-t border-slate-800/80 hover:bg-slate-900/60 transition"
                  >
                    <td className="px-3 py-2 text-slate-300">{l.order}</td>
                    <td className="px-3 py-2 text-slate-300 font-mono text-xs">
                      {l.lessonId}
                    </td>
                    <td className="px-3 py-2 text-slate-100">{l.title}</td>
                    <td className="px-3 py-2 text-slate-300">{l.xp}</td>
                    <td className="px-3 py-2 text-slate-300">
                      {l.minCorrectToPass}
                    </td>
                    <td className="px-3 py-2 text-right">
                      <button
                        onClick={() => handleEditClick(l)}
                        className="inline-flex items-center rounded-full px-3 py-1 text-[11px] font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 transition"
                      >
                        Düzenle
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Ders formu */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl shadow-sm p-4 space-y-3">
          <h3 className="text-sm font-semibold text-slate-100">
            Ders Formu
          </h3>
          <p className="text-xs text-slate-400">
            Var olan bir dersi seçip düzenleyebilir veya yeni bir ders tanımlayabilirsin.
          </p>

          <div className="space-y-2">
            <Input
              label="Lesson ID"
              placeholder="A1-L1"
              value={form.lessonId || ""}
              onChange={(v) => setForm((f) => ({ ...f, lessonId: v }))}
            />
            <Input
              label="Başlık"
              placeholder="Greetings & Basic Phrases"
              value={form.title || ""}
              onChange={(v) => setForm((f) => ({ ...f, title: v }))}
            />
            <Textarea
              label="Açıklama"
              placeholder="Bu derste temel selamlaşma kalıplarını öğreneceksin."
              value={form.description || ""}
              onChange={(v) => setForm((f) => ({ ...f, description: v }))}
            />

            <div className="grid grid-cols-2 gap-2">
              <Input
                label="Order"
                type="number"
                value={form.order ?? ""}
                onChange={(v) =>
                  setForm((f) => ({ ...f, order: Number(v) || 0 }))
                }
              />
              <Input
                label="XP"
                type="number"
                value={form.xp ?? ""}
                onChange={(v) =>
                  setForm((f) => ({ ...f, xp: Number(v) || 0 }))
                }
              />
              <Input
                label="Estimated Minutes"
                type="number"
                value={form.estimatedMinutes ?? ""}
                onChange={(v) =>
                  setForm((f) => ({
                    ...f,
                    estimatedMinutes: Number(v) || 0,
                  }))
                }
              />
              <Input
                label="Min Correct To Pass"
                type="number"
                value={form.minCorrectToPass ?? ""}
                onChange={(v) =>
                  setForm((f) => ({
                    ...f,
                    minCorrectToPass: Number(v) || 0,
                  }))
                }
              />
            </div>

            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-yellow-400 via-amber-300 to-orange-500 text-slate-950 text-sm font-semibold py-2.5 shadow-lg shadow-yellow-500/40 hover:brightness-105 transition disabled:opacity-60 mt-2"
            >
              {saving ? "Kaydediliyor..." : "Dersi Kaydet"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

type InputProps = {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
};

function Input({ label, value, onChange, placeholder, type = "text" }: InputProps) {
  return (
    <label className="text-xs text-slate-300 space-y-1 block">
      <span>{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-yellow-400/70 focus:border-yellow-400/70"
      />
    </label>
  );
}

type TextareaProps = {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
};

function Textarea({ label, value, onChange, placeholder }: TextareaProps) {
  return (
    <label className="text-xs text-slate-300 space-y-1 block">
      <span>{label}</span>
      <textarea
        value={value}
        placeholder={placeholder}
        rows={3}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-yellow-400/70 focus:border-yellow-400/70 resize-none"
      />
    </label>
  );
}
