// src/pages/WritingAdminPage.tsx
import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { db } from '../firebase';

type WritingExercise = {
  id?: string;
  languagePair: 'tr-es' | 'en-es' | 'tr-en';
  level: 'A1' | 'A2' | 'B1' | 'B2';
  order: number;
  prompt: string;
  targetAnswer: string;
  acceptableAnswers?: string[];
  hint?: string;
  explanation?: string;
};

const LANGUAGE_PAIRS: WritingExercise['languagePair'][] = [
  'tr-es',
  'en-es',
  'tr-en',
];

const LEVELS: WritingExercise['level'][] = ['A1', 'A2', 'B1', 'B2'];

const emptyExercise: WritingExercise = {
  languagePair: 'tr-es',
  level: 'A1',
  order: 1,
  prompt: '',
  targetAnswer: '',
  acceptableAnswers: [],
  hint: '',
  explanation: '',
};

const WritingAdminPage: React.FC = () => {
  const [languagePairFilter, setLanguagePairFilter] =
    useState<WritingExercise['languagePair']>('tr-es');
  const [levelFilter, setLevelFilter] =
    useState<WritingExercise['level']>('A1');

  const [exercises, setExercises] = useState<WritingExercise[]>([]);
  const [loading, setLoading] = useState(false);

  const [editing, setEditing] = useState<WritingExercise | null>(null);
  const [acceptableText, setAcceptableText] = useState(''); // her satır 1 alternatif cevap

  const isEditingExisting = useMemo(
    () => !!editing && !!editing.id,
    [editing]
  );

  const loadExercises = async () => {
    setLoading(true);
    try {
      const baseRef = collection(db, 'writing_exercises');

      const q = query(
        baseRef,
        where('languagePair', '==', languagePairFilter),
        where('level', '==', levelFilter),
        orderBy('order', 'asc')
      );

      const snap = await getDocs(q);
      const list: WritingExercise[] = snap.docs.map((d) => {
        const data = d.data() as any;
        return {
          id: d.id,
          languagePair: data.languagePair,
          level: data.level,
          order: data.order ?? 0,
          prompt: data.prompt ?? '',
          targetAnswer: data.targetAnswer ?? '',
          acceptableAnswers: data.acceptableAnswers ?? [],
          hint: data.hint ?? '',
          explanation: data.explanation ?? '',
        };
      });

      setExercises(list);
    } catch (e) {
      console.error('WritingAdmin load error', e);
      alert('Error loading writing exercises');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExercises();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [languagePairFilter, levelFilter]);

  const handleNew = () => {
    const nextOrder =
      exercises.length > 0
        ? (exercises[exercises.length - 1].order ?? exercises.length) + 1
        : 1;

    const initial: WritingExercise = {
      ...emptyExercise,
      languagePair: languagePairFilter,
      level: levelFilter,
      order: nextOrder,
    };

    setEditing(initial);
    setAcceptableText('');
  };

  const handleEdit = (ex: WritingExercise) => {
    setEditing(ex);
    setAcceptableText((ex.acceptableAnswers ?? []).join('\n'));
  };

  const handleDelete = async (ex: WritingExercise) => {
    if (!ex.id) return;
    const ok = window.confirm(
      `Delete writing exercise with prompt:\n"${ex.prompt}" ?`
    );
    if (!ok) return;

    try {
      await deleteDoc(doc(db, 'writing_exercises', ex.id));
      await loadExercises();
    } catch (e) {
      console.error('WritingAdmin delete error', e);
      alert('Error deleting exercise');
    }
  };

  const handleSave = async () => {
    if (!editing) return;

    const acceptableAnswers = acceptableText
      .split('\n')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (!editing.prompt.trim()) {
      alert('Prompt is required');
      return;
    }
    if (!editing.targetAnswer.trim()) {
      alert('Target answer is required');
      return;
    }

    const payload = {
      languagePair: editing.languagePair,
      level: editing.level,
      order: editing.order,
      prompt: editing.prompt.trim(),
      targetAnswer: editing.targetAnswer.trim(),
      acceptableAnswers,
      hint: editing.hint?.trim() || '',
      explanation: editing.explanation?.trim() || '',
    };

    try {
      if (editing.id) {
        await updateDoc(
          doc(db, 'writing_exercises', editing.id),
          payload
        );
      } else {
        await addDoc(collection(db, 'writing_exercises'), payload);
      }

      setEditing(null);
      setAcceptableText('');
      await loadExercises();
    } catch (e) {
      console.error('WritingAdmin save error', e);
      alert('Error saving exercise');
    }
  };

  const handleCancel = () => {
    setEditing(null);
    setAcceptableText('');
  };

  return (
    <div style={styles.page}>
      <h1 style={styles.pageTitle}>Writing exercises</h1>
      <p style={styles.pageSubtitle}>
        Manage free-text writing prompts and correct answers for practice
        mode.
      </p>

      {/* FILTER BAR */}
      <div style={styles.filterRow}>
        <div style={styles.filterGroup}>
          <label style={styles.label}>Language pair</label>
          <select
            value={languagePairFilter}
            onChange={(e) =>
              setLanguagePairFilter(
                e.target.value as WritingExercise['languagePair']
              )
            }
            style={styles.select}
          >
            {LANGUAGE_PAIRS.map((lp) => (
              <option key={lp} value={lp}>
                {lp.toUpperCase()}
              </option>
            ))}
          </select>
        </div>

        <div style={styles.filterGroup}>
          <label style={styles.label}>Level</label>
          <select
            value={levelFilter}
            onChange={(e) =>
              setLevelFilter(e.target.value as WritingExercise['level'])
            }
            style={styles.select}
          >
            {LEVELS.map((lv) => (
              <option key={lv} value={lv}>
                {lv}
              </option>
            ))}
          </select>
        </div>

        <button style={styles.newButton} onClick={handleNew}>
          + New writing exercise
        </button>
      </div>

      {/* LIST */}
      <div style={styles.listBox}>
        {loading ? (
          <div style={styles.center}>Loading…</div>
        ) : exercises.length === 0 ? (
          <div style={styles.center}>
            No exercises for this filter. Create a new one.
          </div>
        ) : (
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Order</th>
                <th style={styles.th}>Prompt</th>
                <th style={styles.th}>Target answer</th>
                <th style={styles.th}>Alt. answers</th>
                <th style={styles.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {exercises.map((ex) => (
                <tr key={ex.id}>
                  <td style={styles.td}>{ex.order}</td>
                  <td style={styles.td}>{ex.prompt}</td>
                  <td style={styles.td}>{ex.targetAnswer}</td>
                  <td style={styles.td}>
                    {(ex.acceptableAnswers ?? []).slice(0, 2).join(' | ')}
                    {(ex.acceptableAnswers ?? []).length > 2 && '…'}
                  </td>
                  <td style={styles.td}>
                    <button
                      style={styles.smallButton}
                      onClick={() => handleEdit(ex)}
                    >
                      Edit
                    </button>
                    <button
                      style={styles.smallDangerButton}
                      onClick={() => handleDelete(ex)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* EDIT / NEW FORM */}
      {editing && (
        <div style={styles.formWrapper}>
          <h2 style={styles.formTitle}>
            {isEditingExisting ? 'Edit exercise' : 'New exercise'}
          </h2>

          <div style={styles.formGrid}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Language pair</label>
              <select
                value={editing.languagePair}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev
                      ? {
                          ...prev,
                          languagePair: e.target
                            .value as WritingExercise['languagePair'],
                        }
                      : prev
                  )
                }
                style={styles.select}
              >
                {LANGUAGE_PAIRS.map((lp) => (
                  <option key={lp} value={lp}>
                    {lp.toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Level</label>
              <select
                value={editing.level}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev
                      ? {
                          ...prev,
                          level: e.target.value as WritingExercise['level'],
                        }
                      : prev
                  )
                }
                style={styles.select}
              >
                {LEVELS.map((lv) => (
                  <option key={lv} value={lv}>
                    {lv}
                  </option>
                ))}
              </select>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Order</label>
              <input
                type="number"
                value={editing.order}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev
                      ? { ...prev, order: Number(e.target.value) || 0 }
                      : prev
                  )
                }
                style={styles.input}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Prompt</label>
              <textarea
                value={editing.prompt}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, prompt: e.target.value } : prev
                  )
                }
                rows={2}
                style={styles.textarea}
                placeholder='Örn: "Aşağıdaki cümleyi İspanyolca yaz: Benim adım Merve."'
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Target answer</label>
              <input
                type="text"
                value={editing.targetAnswer}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, targetAnswer: e.target.value } : prev
                  )
                }
                style={styles.input}
                placeholder="Örn: Me llamo Merve."
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>
                Acceptable answers (one per line)
              </label>
              <textarea
                value={acceptableText}
                onChange={(e) => setAcceptableText(e.target.value)}
                rows={4}
                style={styles.textarea}
                placeholder={'Me llamo Merve\nMi nombre es Merve'}
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Hint (optional)</label>
              <textarea
                value={editing.hint ?? ''}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, hint: e.target.value } : prev
                  )
                }
                rows={2}
                style={styles.textarea}
                placeholder='Örn: "Me llamo + isim"'
              />
            </div>

            <div style={styles.formGroupFull}>
              <label style={styles.label}>Explanation (optional)</label>
              <textarea
                value={editing.explanation ?? ''}
                onChange={(e) =>
                  setEditing((prev) =>
                    prev ? { ...prev, explanation: e.target.value } : prev
                  )
                }
                rows={3}
                style={styles.textarea}
              />
            </div>
          </div>

          <div style={styles.formActions}>
            <button style={styles.saveButton} onClick={handleSave}>
              {isEditingExisting ? 'Save changes' : 'Create exercise'}
            </button>
            <button style={styles.cancelButton} onClick={handleCancel}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const styles: { [key: string]: React.CSSProperties } = {
  page: {
    padding: 24,
    maxWidth: 1100,
    margin: '0 auto',
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 700,
    marginBottom: 4,
  },
  pageSubtitle: {
    fontSize: 13,
    color: '#9ca3af',
    marginBottom: 16,
  },
  filterRow: {
    display: 'flex',
    alignItems: 'flex-end',
    gap: 12,
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  filterGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
    minWidth: 160,
  },
  label: {
    fontSize: 12,
    fontWeight: 600,
  },
  select: {
    padding: '6px 8px',
    borderRadius: 8,
    border: '1px solid #d1d5db',
    fontSize: 13,
  },
  newButton: {
    padding: '8px 14px',
    borderRadius: 999,
    border: 'none',
    backgroundColor: '#004aad',
    color: '#ffffff',
    fontSize: 13,
    fontWeight: 600,
    cursor: 'pointer',
  },
  listBox: {
    borderRadius: 12,
    border: '1px solid #e5e7eb',
    overflow: 'hidden',
    backgroundColor: '#ffffff',
  },
  center: {
    padding: 24,
    textAlign: 'center',
    fontSize: 13,
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: 13,
  },
  th: {
    textAlign: 'left',
    padding: '8px 10px',
    borderBottom: '1px solid #e5e7eb',
    backgroundColor: '#f9fafb',
    fontWeight: 600,
    fontSize: 12,
  },
  td: {
    padding: '8px 10px',
    borderBottom: '1px solid #f3f4f6',
    verticalAlign: 'top',
  },
  smallButton: {
    padding: '4px 8px',
    borderRadius: 999,
    border: '1px solid #d1d5db',
    backgroundColor: '#ffffff',
    fontSize: 11,
    cursor: 'pointer',
    marginRight: 6,
  },
  smallDangerButton: {
    padding: '4px 8px',
    borderRadius: 999,
    border: '1px solid #fecaca',
    backgroundColor: '#fee2e2',
    color: '#991b1b',
    fontSize: 11,
    cursor: 'pointer',
  },
  formWrapper: {
    marginTop: 20,
    padding: 16,
    borderRadius: 12,
    border: '1px solid #e5e7eb',
    backgroundColor: '#f9fafb',
  },
  formTitle: {
    fontSize: 18,
    fontWeight: 600,
    marginBottom: 12,
  },
  formGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
    gap: 12,
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
  },
  formGroupFull: {
    gridColumn: '1 / -1',
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
  },
  input: {
    padding: '6px 8px',
    borderRadius: 8,
    border: '1px solid #d1d5db',
    fontSize: 13,
  },
  textarea: {
    padding: '6px 8px',
    borderRadius: 8,
    border: '1px solid #d1d5db',
    fontSize: 13,
    resize: 'vertical',
  },
  formActions: {
    marginTop: 16,
    display: 'flex',
    gap: 8,
  },
  saveButton: {
    padding: '8px 16px',
    borderRadius: 999,
    border: 'none',
    backgroundColor: '#004aad',
    color: '#ffffff',
    fontSize: 13,
    fontWeight: 600,
    cursor: 'pointer',
  },
  cancelButton: {
    padding: '8px 16px',
    borderRadius: 999,
    border: '1px solid #d1d5db',
    backgroundColor: '#ffffff',
    fontSize: 13,
    cursor: 'pointer',
  },
};

export default WritingAdminPage;
