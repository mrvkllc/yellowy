// src/services/firebase.ts
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Firebase config (senin konsoldan aldığın değerler)
const firebaseConfig = {
  apiKey: 'AIzaSyAR6b2iSw4D0QUralA_N3fd0M_nW2xnvpA',
  authDomain: 'yellowwhat.firebaseapp.com',
  projectId: 'yellowwhat',
  storageBucket: 'yellowwhat.firebasestorage.app',
  messagingSenderId: '230896552990',
  appId: '1:230896552990:web:51faa94133151cf5c3720f',
  measurementId: 'G-QQ7GKQ9PYB',
};

// Uygulamayı başlat
const app = initializeApp(firebaseConfig);

// Auth instance
export const auth = getAuth(app);

export const db = getFirestore(app);
