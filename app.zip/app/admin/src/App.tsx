// src/App.tsx
import { useEffect, useState } from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import { auth } from "./firebase";
import { LessonsPage } from "./pages/LessonsPage";
import { StepsPage } from "./pages/StepsPage";
import CsvImportPage from "./pages/CsvImportPage";
import ListeningAdminPage from "./pages/ListeningAdminPage";
import WritingAdminPage from "./pages/WritingAdminPage";

const ADMIN_EMAIL = "test1@yellowy.com";

// 🔹 Writing tab'i eklendi
type TabKey = "lessons" | "steps" | "listening" | "writing" | "csv";

function App() {
  const [user, setUser] = useState<any | null>(null);
  const [checking, setChecking] = useState(true);
  const [activeTab, setActiveTab] = useState<TabKey>("lessons");

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setChecking(false);
    });
    return () => unsub();
  }, []);

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="animate-pulse text-slate-300 text-sm">
          Loading admin panel…
        </div>
      </div>
    );
  }

  if (!user) return <LoginForm />;

  if (user.email !== ADMIN_EMAIL) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl px-8 py-6 shadow-xl max-w-md w-full text-center space-y-4">
          <h1 className="text-xl font-semibold text-red-400">
            Erişim yetkin yok
          </h1>
          <p className="text-sm text-slate-300">
            Bu panel sadece admin kullanıcı için.
          </p>
          <button
            onClick={() => signOut(auth)}
            className="inline-flex items-center justify-center rounded-full px-4 py-2 text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 transition"
          >
            Çıkış yap
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-tr from-yellow-400 via-amber-300 to-orange-500 flex items-center justify-center text-slate-950 font-black text-lg shadow-lg shadow-yellow-500/40">
              Y
            </div>
            <div>
              <div className="font-semibold leading-tight">
                YellowWhat Admin
              </div>
              <div className="text-xs text-slate-400 leading-tight">
                Lessons · Steps · Listening · Writing · CSV Import
              </div>
            </div>
          </div>

          {/* TAB SWITCH */}
          <div className="flex-1 flex justify-center">
            <div className="inline-flex items-center rounded-full bg-slate-900/80 border border-slate-800 p-1 text-xs">
              <button
                onClick={() => setActiveTab("lessons")}
                className={
                  "px-3 py-1.5 rounded-full transition " +
                  (activeTab === "lessons"
                    ? "bg-slate-800 text-slate-100 shadow"
                    : "text-slate-400 hover:text-slate-100")
                }
              >
                Dersler
              </button>

              <button
                onClick={() => setActiveTab("steps")}
                className={
                  "px-3 py-1.5 rounded-full transition " +
                  (activeTab === "steps"
                    ? "bg-slate-800 text-slate-100 shadow"
                    : "text-slate-400 hover:text-slate-100")
                }
              >
                Adımlar
              </button>

              <button
                onClick={() => setActiveTab("listening")}
                className={
                  "px-3 py-1.5 rounded-full transition " +
                  (activeTab === "listening"
                    ? "bg-slate-800 text-slate-100 shadow"
                    : "text-slate-400 hover:text-slate-100")
                }
              >
                Listening
              </button>

              <button
                onClick={() => setActiveTab("writing")}
                className={
                  "px-3 py-1.5 rounded-full transition " +
                  (activeTab === "writing"
                    ? "bg-slate-800 text-slate-100 shadow"
                    : "text-slate-400 hover:text-slate-100")
                }
              >
                Writing
              </button>

              <button
                onClick={() => setActiveTab("csv")}
                className={
                  "px-3 py-1.5 rounded-full transition " +
                  (activeTab === "csv"
                    ? "bg-slate-800 text-slate-100 shadow"
                    : "text-slate-400 hover:text-slate-100")
                }
              >
                CSV İçe Aktar
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400 hidden sm:inline">
              {user.email}
            </span>
            <button
              onClick={() => signOut(auth)}
              className="inline-flex items-center justify-center rounded-full px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 transition"
            >
              Çıkış
            </button>
          </div>
        </div>
      </header>

      <main className="w-full px-8 py-8 max-w-6xl mx-auto space-y-4">
        {activeTab === "lessons" && <LessonsPage />}

        {activeTab === "steps" && <StepsPage />}

        {activeTab === "listening" && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <ListeningAdminPage />
          </div>
        )}

        {activeTab === "writing" && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <WritingAdminPage />
          </div>
        )}

        {activeTab === "csv" && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <CsvImportPage />
          </div>
        )}
      </main>
    </div>
  );
}

function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      console.error(err);
      setErrorMsg("Giriş başarısız. Email / şifreyi kontrol et.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center rounded-full bg-slate-900 px-3 py-1 text-xs text-slate-300 border border-slate-800 mb-1">
            YellowWhat · Internal Tool
          </div>
          <h1 className="text-2xl font-semibold">Admin Panel Girişi</h1>
          <p className="text-sm text-slate-400">
            Bu alan sadece içerik yöneticisi için. Lütfen admin hesabınla giriş
            yap.
          </p>
        </div>

        <form
          onSubmit={handleLogin}
          className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4"
        >
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Email</label>
            <input
              className="w-full rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
              placeholder="admin@yellowwhat.com"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Şifre</label>
            <input
              className="w-full rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
              placeholder="••••••••"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          {errorMsg && (
            <div className="text-xs text-red-400 bg-red-500/10 border border-red-500/40 rounded-xl px-3 py-2">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-yellow-400 via-amber-300 to-orange-500 text-slate-950 text-sm font-semibold py-2.5 shadow-lg shadow-yellow-500/40 hover:brightness-105 transition disabled:opacity-60"
          >
            {loading ? "Giriş yapılıyor..." : "Giriş yap"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default App;
